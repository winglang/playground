"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BucketEventHandlerClient = void 0;
class BucketEventHandlerClient {
    constructor({ handler }) {
        this.handler = handler;
    }
    async handle(event) {
        try {
            const message = JSON.parse(event?.Message);
            if (message?.Event === "s3:TestEvent") {
                // aws sends a test event to the topic before of the actual one, we're ignoring it for now
                return;
            }
            return await this.handler.handle(message.Records[0].s3.object.key);
        }
        catch (error) {
            //TODO: change to some sort of warning- console.warn doesn't seems to work
            console.log("Error parsing the notification event message: ", error);
            console.log("Event: ", event);
        }
    }
}
exports.BucketEventHandlerClient = BucketEventHandlerClient;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVja2V0Lm9uZXZlbnQuaW5mbGlnaHQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdGFyZ2V0LXRmLWF3cy9idWNrZXQub25ldmVudC5pbmZsaWdodC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFFQSxNQUFhLHdCQUF3QjtJQUVuQyxZQUFZLEVBQUUsT0FBTyxFQUF1QztRQUMxRCxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztJQUN6QixDQUFDO0lBQ00sS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFVO1FBQzVCLElBQUk7WUFDRixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMzQyxJQUFJLE9BQU8sRUFBRSxLQUFLLEtBQUssY0FBYyxFQUFFO2dCQUNyQywwRkFBMEY7Z0JBQzFGLE9BQU87YUFDUjtZQUNELE9BQU8sTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDcEU7UUFBQyxPQUFPLEtBQUssRUFBRTtZQUNkLDBFQUEwRTtZQUMxRSxPQUFPLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3JFLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQy9CO0lBQ0gsQ0FBQztDQUNGO0FBbkJELDREQW1CQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElCdWNrZXRFdmVudEhhbmRsZXJDbGllbnQsIElGdW5jdGlvbkhhbmRsZXJDbGllbnQgfSBmcm9tIFwiLi4vY2xvdWRcIjtcblxuZXhwb3J0IGNsYXNzIEJ1Y2tldEV2ZW50SGFuZGxlckNsaWVudCBpbXBsZW1lbnRzIElCdWNrZXRFdmVudEhhbmRsZXJDbGllbnQge1xuICBwcml2YXRlIHJlYWRvbmx5IGhhbmRsZXI6IElGdW5jdGlvbkhhbmRsZXJDbGllbnQ7XG4gIGNvbnN0cnVjdG9yKHsgaGFuZGxlciB9OiB7IGhhbmRsZXI6IElGdW5jdGlvbkhhbmRsZXJDbGllbnQgfSkge1xuICAgIHRoaXMuaGFuZGxlciA9IGhhbmRsZXI7XG4gIH1cbiAgcHVibGljIGFzeW5jIGhhbmRsZShldmVudDogYW55KSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSBKU09OLnBhcnNlKGV2ZW50Py5NZXNzYWdlKTtcbiAgICAgIGlmIChtZXNzYWdlPy5FdmVudCA9PT0gXCJzMzpUZXN0RXZlbnRcIikge1xuICAgICAgICAvLyBhd3Mgc2VuZHMgYSB0ZXN0IGV2ZW50IHRvIHRoZSB0b3BpYyBiZWZvcmUgb2YgdGhlIGFjdHVhbCBvbmUsIHdlJ3JlIGlnbm9yaW5nIGl0IGZvciBub3dcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuaGFuZGxlci5oYW5kbGUobWVzc2FnZS5SZWNvcmRzWzBdLnMzLm9iamVjdC5rZXkpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvL1RPRE86IGNoYW5nZSB0byBzb21lIHNvcnQgb2Ygd2FybmluZy0gY29uc29sZS53YXJuIGRvZXNuJ3Qgc2VlbXMgdG8gd29ya1xuICAgICAgY29uc29sZS5sb2coXCJFcnJvciBwYXJzaW5nIHRoZSBub3RpZmljYXRpb24gZXZlbnQgbWVzc2FnZTogXCIsIGVycm9yKTtcbiAgICAgIGNvbnNvbGUubG9nKFwiRXZlbnQ6IFwiLCBldmVudCk7XG4gICAgfVxuICB9XG59XG4iXX0=