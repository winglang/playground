/**
 * Emits a log message to the console if the DEBUG environment variable is set.
 * @param args Arguments to pass to console.error.
 */
export declare function log(...args: any[]): void;
