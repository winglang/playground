export declare function readJsonSync(file: string): any;
/**
 * Normalize windows paths to be posix-like.
 */
export declare function normalPath(path: string): string;
/**
 * Just a helpful wrapper around `execFile` that returns a promise.
 */
export declare function runCommand(cmd: string, args: string[]): Promise<any>;
