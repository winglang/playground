export interface Bundle {
    entrypointPath: string;
    directory: string;
    hash: string;
}
export declare function createBundle(entrypoint: string): Bundle;
