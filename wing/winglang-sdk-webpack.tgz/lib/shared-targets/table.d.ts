import { ColumnType } from "../cloud";
import { Json } from "../std";
export declare function validateRow(row: Json, columns: {
    [key: string]: ColumnType;
}): void;
