import { Construct } from "constructs";
import { IResource, Resource } from "../std/resource";
/**
 * Global identifier for `Api`.
 */
export declare const API_FQN: string;
/**
 * Properties for `Api`.
 */
export interface ApiProps {
}
/**
 * The OpenAPI spec.
 */
export type OpenApiSpec = any;
/**
 * The OpenAPI spec extension for a route.
 * see https://spec.openapis.org/oas/v3.0.3
 * */
export type OpenApiSpecExtension = any;
/**
 * Functionality shared between all `Api` implementations.
 */
export declare abstract class Api extends Resource {
    /**
     * Creates a new cloud.Api instance through the app.
     * @internal
     */
    static _newApi(scope: Construct, id: string, props?: ApiProps): Api;
    /**
     * The base URL of the API endpoint.
     */
    abstract readonly url: string;
    private apiSpec;
    constructor(scope: Construct, id: string, props?: ApiProps);
    /**
     * Add a inflight handler to the api for GET requests on the given path.
     * @param path The path to handle GET requests for.
     * @param inflight The function to handle the request.
     * @param props Options for the route.
     */
    abstract get(path: string, inflight: IApiEndpointHandler, props?: ApiGetProps): void;
    /**
     * Add a inflight handler to the api for POST requests on the given path.
     * @param path The path to handle POST requests for.
     * @param inflight The function to handle the request.
     * @param props Options for the route.
     */
    abstract post(path: string, inflight: IApiEndpointHandler, props?: ApiPostProps): void;
    /**
     * Add a inflight handler to the api for PUT requests on the given path.
     * @param path The path to handle PUT requests for.
     * @param inflight The function to handle the request.
     * @param props Options for the route.
     */
    abstract put(path: string, inflight: IApiEndpointHandler, props?: ApiPutProps): void;
    /**
     * Add a inflight handler to the api for DELETE requests on the given path.
     * @param path The path to handle DELETE requests for.
     * @param inflight The function to handle the request.
     * @param props Options for the route.
     */
    abstract delete(path: string, inflight: IApiEndpointHandler, props?: ApiDeleteProps): void;
    /**
     * Add a inflight handler to the api for PATCH requests on the given path.
     * @param path The path to handle PATCH requests for.
     * @param inflight The function to handle the request.
     * @param props Options for the route.
     */
    abstract patch(path: string, inflight: IApiEndpointHandler, props?: ApiPatchProps): void;
    /**
     * Add a inflight handler to the api for OPTIONS requests on the given path.
     * @param path The path to handle OPTIONS requests for.
     * @param inflight The function to handle the request.
     * @param props Options for the route.
     */
    abstract options(path: string, inflight: IApiEndpointHandler, props?: ApiOptionsProps): void;
    /**
     * Add a inflight handler to the api for HEAD requests on the given path.
     * @param path The path to handle HEAD requests for.
     * @param inflight The function to handle the request.
     * @param props Options for the route.
     */
    abstract head(path: string, inflight: IApiEndpointHandler, props?: ApiHeadProps): void;
    /**
     * Add a inflight handler to the api for CONNECT requests on the given path.
     * @param path The path to handle CONNECT requests for.
     * @param inflight The function to handle the request.
     * @param props Options for the route.
     */
    abstract connect(path: string, inflight: IApiEndpointHandler, props?: ApiConnectProps): void;
    /**
     * validating path:
     * if has curly brackets pairs- the part that inside the brackets is only letter, digit or _, not empty and placed before and after "/"
     * @param path
     * @throws if the path is invalid
     * @internal
     */
    protected _validatePath(path: string): void;
    /**
     * Add a route to the api spec.
     * @param path The path to add.
     * @param method The method to add.
     * @param apiSpecExtension The extension to add to the api spec for this route and method.
     *
     * @internal
     * */
    _addToSpec(path: string, method: string, apiSpecExtension: OpenApiSpecExtension): void;
    /**
     * Return the api spec.
     * @internal */
    _getApiSpec(): OpenApiSpec;
}
/**
 * Options for Api get endpoint.
 */
export interface ApiGetProps {
}
/**
 * Options for Api post endpoint.
 */
export interface ApiPostProps {
}
/**
 * Options for Api put endpoint.
 */
export interface ApiPutProps {
}
/**
 * Options for Api put endpoint.
 */
export interface ApiDeleteProps {
}
/**
 * Options for Api patch endpoint.
 */
export interface ApiPatchProps {
}
/**
 * Options for Api patch endpoint.
 */
export interface ApiOptionsProps {
}
/**
 * Options for Api patch endpoint.
 */
export interface ApiHeadProps {
}
/**
 * Options for Api patch endpoint.
 */
export interface ApiConnectProps {
}
/**
 * Inflight methods and members of `cloud.Api`.
 */
export interface IApiClient {
}
/**
 * Allowed HTTP methods for a endpoint.
 */
export declare enum HttpMethod {
    /** Get */
    GET = "GET",
    /** Head */
    HEAD = "HEAD",
    /** Post */
    POST = "POST",
    /** Put */
    PUT = "PUT",
    /** Delete */
    DELETE = "DELETE",
    /** Connect */
    CONNECT = "CONNECT",
    /** Options */
    OPTIONS = "OPTIONS",
    /** Patch */
    PATCH = "PATCH"
}
/**
 * Shape of a request to an inflight handler.
 */
export interface ApiRequest {
    /** The request's HTTP method. */
    readonly method: HttpMethod;
    /** The request's path. */
    readonly path: string;
    /** The request's query string values. */
    readonly query: Record<string, string>;
    /** The path variables. */
    readonly vars: Record<string, string>;
    /** The request's body. */
    readonly body?: object;
    /** The request's headers. */
    readonly headers?: Record<string, string>;
}
/**
 * Shape of a response from a inflight handler.
 */
export interface ApiResponse {
    /** The response's status code. */
    readonly status: number;
    /** The response's body. */
    readonly body?: object;
    /** The response's headers. */
    readonly headers?: Record<string, string>;
}
/**
 * Represents a resource with an inflight "handle" method that can be passed to
 * one of the `Api` request preflight methods.
 *
 * @inflight `@winglang/sdk.cloud.IApiEndpointHandlerClient`
 */
export interface IApiEndpointHandler extends IResource {
}
/**
 * Inflight client for `IApiEndpointHandler`.
 */
export interface IApiEndpointHandlerClient {
    /**
     * Inflight that will be called when a request is made to the endpoint.
     * @inflight
     */
    handle(request: ApiRequest): Promise<ApiResponse>;
}
/**
 * Parse an HTTP method string to an HttpMethod enum
 * @param method HTTP method string
 * @returns HttpMethod enum
 * @throws Error if the method is not supported
 */
export declare function parseHttpMethod(method: string): HttpMethod;
/**
 * Convert an object with multi-valued parameters to a an object with
 * single-valued parameters.
 */
export declare function sanitizeParamLikeObject(obj: Record<string, string | string[] | undefined>): Record<string, string>;
