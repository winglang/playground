import { Construct } from "constructs";
import { Resource } from "../std";
/**
 * Global identifier for `Counter`.
 */
export declare const COUNTER_FQN: string;
/**
 * Properties for `Counter`.
 */
export interface CounterProps {
    /**
     * The initial value of the counter.
     * @default 0
     */
    readonly initial?: number;
}
/**
 * Represents a distributed atomic counter.
 * @inflight `@winglang/sdk.cloud.ICounterClient`
 */
export declare abstract class Counter extends Resource {
    /**
     * Create a new counter.
     * @internal
     */
    static _newCounter(scope: Construct, id: string, props?: CounterProps): Counter;
    /**
     * The initial value of the counter.
     */
    readonly initial: number;
    constructor(scope: Construct, id: string, props?: CounterProps);
}
/**
 * Inflight interface for `Counter`.
 */
export interface ICounterClient {
    /**
     * Increments the counter atomically by a certain amount and returns the previous value.
     * @param amount amount to increment (default is 1).
     * @returns the previous value of the counter.
     * @inflight
     */
    inc(amount?: number): Promise<number>;
    /**
     * Decrement the counter, returning the previous value.
     * @param amount amount to decrement (default is 1).
     * @returns the previous value of the counter.
     * @inflight
     */
    dec(amount?: number): Promise<number>;
    /**
     * Get the current value of the counter.
     * Using this API may introduce race conditions since the value can change between
     * the time it is read and the time it is used in your code.
     * @returns current value
     * @inflight
     */
    peek(): Promise<number>;
    /**
     * Reset a counter to a given value.
     * @param value value to reset (default is 0)
     * @inflight
     */
    reset(value?: number): Promise<void>;
}
/**
 * List of inflight operations available for `Counter`.
 * @internal
 */
export declare enum CounterInflightMethods {
    /** `Counter.inc` */
    INC = "inc",
    /** `Counter.dec` */
    DEC = "dec",
    /** `Counter.peek` */
    PEEK = "peek",
    /** `Counter.reset` */
    RESET = "reset"
}
