import { Construct } from "constructs";
import { Function, FunctionProps } from "./function";
import { Code } from "../core";
import { IInflightHost, IResource, Resource } from "../std";
/**
 * Global identifier for `Test`.
 */
export declare const TEST_FQN: string;
/**
 * Properties for `Test`.
 *
 * This is the type users see when constructing a cloud.Test instance.
 */
export interface TestProps extends FunctionProps {
}
/**
 * Represents a unit test.
 *
 * @inflight `@winglang/sdk.cloud.ITestClient`
 */
export declare class Test extends Resource implements IInflightHost {
    /**
     * Creates a new cloud.Test instance through the app.
     * @internal
     */
    static _newTest(scope: Construct, id: string, inflight: ITestHandler, props?: TestProps): Test;
    /** @internal */
    readonly _fn: Function;
    constructor(scope: Construct, id: string, inflight: ITestHandler, props?: TestProps);
    /** @internal */
    _toInflight(): Code;
}
/**
 * Interface with an inflight "handle" method that can be used to construct
 * a `cloud.Test`.
 *
 * @inflight `@winglang/sdk.cloud.ITestHandlerClient`
 */
export interface ITestHandler extends IResource {
}
/**
 * Inflight client for `ITestHandler`.
 */
export interface ITestHandlerClient {
    /**
     * Inflight function that will be called when the test is run.
     * @inflight
     */
    handle(): Promise<void>;
}
