import { Construct } from "constructs";
import { Test } from "./test";
import { Resource } from "../std";
/**
 * Global identifier for `TestRunner`.
 */
export declare const TEST_RUNNER_FQN: string;
/**
 * Properties for `TestRunner`.
 */
export interface TestRunnerProps {
}
/**
 * Represents a test engine.
 *
 * @inflight `@winglang/sdk.cloud.ITestRunnerClient`
 */
export declare abstract class TestRunner extends Resource {
    /**
     * Create a new test engine.
     * @internal
     */
    static _newTestRunner(scope: Construct, id: string, props?: TestRunnerProps): TestRunner;
    constructor(scope: Construct, id: string, props?: TestRunnerProps);
    /**
     * Find all tests in the construct tree.
     * @returns A list of tests.
     */
    findTests(): Test[];
}
/**
 * Inflight interface for `TestRunner`.
 */
export interface ITestRunnerClient {
    /**
     * List all tests available for this test engine.
     * @inflight
     * @returns A list of test names.
     */
    listTests(): Promise<string[]>;
    /**
     * Run a test with a given path and return the result.
     * @inflight
     */
    runTest(path: string): Promise<TestResult>;
}
/**
 * A result of a single test.
 */
export interface TestResult {
    /**
     * The path of the test.
     */
    readonly path: string;
    /**
     * Whether the test passed.
     */
    readonly pass: boolean;
    /**
     * The error message if the test failed.
     */
    readonly error?: string;
    /**
     * List of traces emitted during the test.
     */
    readonly traces: Trace[];
}
/**
 * Represents an trace emitted during simulation.
 */
export interface Trace {
    /**
     * A JSON blob with structured data.
     */
    readonly data: any;
    /**
     * The type of the source that emitted the trace.
     */
    readonly sourceType: string;
    /**
     * The path of the resource that emitted the trace.
     */
    readonly sourcePath: string;
    /**
     * The type of a trace.
     */
    readonly type: TraceType;
    /**
     * The timestamp of the event, in ISO 8601 format.
     * @example 2020-01-01T00:00:00.000Z
     */
    readonly timestamp: string;
}
/**
 * The type of a trace.
 */
export declare enum TraceType {
    /**
     * A trace representing a resource activity.
     */
    RESOURCE = "resource",
    /**
     * A trace representing a message emitted by the logger.
     */
    LOG = "log"
}
/**
 * List of inflight operations available for `TestRunner`.
 * @internal
 */
export declare enum TestRunnerInflightMethods {
    /** `TestRunner.runTest` */
    RUN_TEST = "runTest",
    /** `TestRunner.listTests` */
    LIST_TESTS = "listTests"
}
