import { Construct } from "constructs";
import { Json, Resource } from "../std";
/**
 * Global identifier for `Secret`.
 */
export declare const SECRET_FQN: string;
/**
 * Properties for `Secret`.
 */
export interface SecretProps {
    /**
     * The secret's name.
     *
     * If no name is provided then a new secret is provisioned in the target.
     * If a name is provided then the resource will reference an existing
     * secret in the target.
     *
     * @default - a new secret is provisioned with a generated name
     */
    readonly name?: string;
}
/**
 * Represents a cloud secret.
 *
 * @inflight `@winglang/sdk.cloud.ISecretClient`
 */
export declare abstract class Secret extends Resource {
    /**
     * Create a new secert.
     * @internal
     */
    static _newSecret(scope: Construct, id: string, props?: SecretProps): Secret;
    constructor(scope: Construct, id: string, props?: SecretProps);
}
/**
 * Options when getting a secret value
 */
export interface GetSecretValueOptions {
    /**
     * Whether to cache the value
     *
     * @default true
     */
    readonly cache?: boolean;
}
/**
 * Inflight interface for `Secret`.
 */
export interface ISecretClient {
    /**
     * Retrieve the value of the secret.
     * @Throws if the secret doesn't exist.
     * @Returns the secret value as string.
     * @inflight
     */
    value(options?: GetSecretValueOptions): Promise<string>;
    /**
     * Retrieve the Json value of the secret.
     * @Throws if the secret doesn't exist or cannot be parsed as Json
     * @Returns the secret value parsed as Json.
     * @inflight
     */
    valueJson(options?: GetSecretValueOptions): Promise<Json>;
}
/**
 * List of inflight operations available for `Secret`.
 * @internal
 */
export declare enum SecretInflightMethods {
    /** `Secret.value` */
    VALUE = "value",
    /** `Secret.valueJson` */
    VALUE_JSON = "valueJson"
}
