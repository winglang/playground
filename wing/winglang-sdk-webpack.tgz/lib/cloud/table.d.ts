import { Construct } from "constructs";
import { Json, Resource } from "../std";
/**
 * Global identifier for `Table`.
 */
export declare const TABLE_FQN: string;
/**
 * Table column types
 */
export declare enum ColumnType {
    /** string type */
    STRING = 0,
    /** number type */
    NUMBER = 1,
    /** bool type */
    BOOLEAN = 2,
    /** date type */
    DATE = 3,
    /** json type */
    JSON = 4
}
/**
 * Properties for `Table`.
 */
export interface TableProps {
    /**
     * The table's name.
     * @default undefined
     */
    readonly name?: string;
    /**
     * The table's columns.
     * @default undefined
     */
    readonly columns?: {
        [key: string]: ColumnType;
    };
    /**
     * The table's primary key. No two rows can have the same value for the
     * primary key.
     * @default undefined
     */
    readonly primaryKey?: string;
}
/**
 * Represents a NoSQL database table that can be used to store and query data.
 * @inflight `@winglang/sdk.cloud.ITableClient`
 */
export declare abstract class Table extends Resource {
    /**
     * Create a new `Table` instance.
     * @internal
     */
    static _newTable(scope: Construct, id: string, props?: TableProps): Table;
    /**
     * Table name
     */
    readonly name: string;
    /**
     * Table primary key name
     */
    readonly primaryKey: string;
    /**
     * Table columns
     */
    readonly columns: {
        [key: string]: ColumnType;
    };
    constructor(scope: Construct, id: string, props: TableProps);
}
/**
 * Inflight interface for `Table`.
 */
export interface ITableClient {
    /**
     * Insert a row into the table.
     * @param key primary key to insert the row.
     * @param row data to be inserted.
     * @inflight
     */
    insert(key: string, row: Json): Promise<void>;
    /**
     * Update a row in the table.
     * @param key primary key to update the row.
     * @param row data to be updated.
     * @inflight
     */
    update(key: string, row: Json): Promise<void>;
    /**
     * Delete a row from the table, by primary key.
     * @param key primary key to delete the row.
     * @inflight
     */
    delete(key: string): Promise<void>;
    /**
     * Get a row from the table, by primary key.
     * @param key primary key to search.
     * @returns get the row from table.
     * @inflight
     */
    get(key: string): Promise<Json>;
    /**
     * List all rows in the table.
     * @returns list all row.
     * @inflight
     */
    list(): Promise<Array<Json>>;
}
/**
 * List of inflight operations available for `Table`.
 * @internal
 */
export declare enum TableInflightMethods {
    /** `Table.insert` */
    INSERT = "insert",
    /** `Table.update` */
    UPDATE = "update",
    /** `Table.delete` */
    DELETE = "delete",
    /** `Table.get` */
    GET = "get",
    /** `Table.list` */
    LIST = "list"
}
