import { Construct } from "constructs";
import { Topic } from "./topic";
import { Json, IResource, Resource } from "../std";
/**
 * Global identifier for `Bucket`.
 */
export declare const BUCKET_FQN: string;
/**
 * Properties for `Bucket`.
 */
export interface BucketProps {
    /**
     * Whether the bucket's objects should be publicly accessible.
     * @default false
     */
    readonly public?: boolean;
}
/**
 * Represents a cloud object store.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare abstract class Bucket extends Resource {
    /**
     * Create a new bucket.
     * @internal
     */
    static _newBucket(scope: Construct, id: string, props?: BucketProps): Bucket;
    /** @internal */
    protected readonly _topics: Map<BucketEventType, Topic>;
    constructor(scope: Construct, id: string, props?: BucketProps);
    /**
     * Add a file to the bucket that is uploaded when the app is deployed.
     *
     * TODO: In the future this will support uploading any `Blob` type or
     * referencing a file from the local filesystem.
     */
    abstract addObject(key: string, body: string): void;
    /**
     * creates a topic for subscribing to notification events
     * @param actionType
     * @returns the created topi
     */
    protected createTopic(actionType: BucketEventType): Topic;
    /**
     * gets topic form the topics map, or creates if not exists
     * @param actionType
     * @returns
     */
    private getTopic;
    /**
     * resolves the path to the bucket.onevent.inflight file
     */
    protected eventHandlerLocation(): string;
    /**
     * creates an inflight handler from inflight code
     * @param eventType
     * @param inflight
     * @returns
     */
    private createInflightHandler;
    /**
     * creates a bucket event notifier
     * @param eventNames the events to subscribe the inflight function to
     * @param inflight the code to run upon event
     * @param opts
     */
    private createBucketEvent;
    /**
     * Run an inflight whenever a file is uploaded to the bucket.
     */
    onCreate(fn: IBucketEventHandler, opts?: BucketOnCreateProps): void;
    /**
     * Run an inflight whenever a file is deleted from the bucket.
     */
    onDelete(fn: IBucketEventHandler, opts?: BucketOnDeleteProps): void;
    /**
     * Run an inflight whenever a file is updated in the bucket.
     */
    onUpdate(fn: IBucketEventHandler, opts?: BucketOnUpdateProps): void;
    /**
     * Run an inflight whenever a file is uploaded, modified, or deleted from the bucket.
     */
    onEvent(fn: IBucketEventHandler, opts?: BucketOnEventProps): void;
}
/** Interface for delete method inside `Bucket` */
export interface BucketDeleteOptions {
    /**
     * Check failures on the method and retrieve errors if any
     * @Throws if this is `true`, an error is thrown if the file is not found (or any error case).
     * @default false
     */
    readonly mustExist?: boolean;
}
/**
 * Inflight interface for `Bucket`.
 */
export interface IBucketClient {
    /**
     * Put an object in the bucket.
     * @param key Key of the object.
     * @param body Content of the object we want to store into the bucket.
     * @inflight
     */
    put(key: string, body: string): Promise<void>;
    /**
     * Put a Json object in the bucket.
     * @param key Key of the object.
     * @param body Json object that we want to store into the bucket.
     * @inflight
     */
    putJson(key: string, body: Json): Promise<void>;
    /**
     * Retrieve an object from the bucket.
     * @param key Key of the object.
     * @Throws if no object with the given key exists.
     * @Returns the object's body.
     * @inflight
     */
    get(key: string): Promise<string>;
    /**
     * Retrieve a Json object from the bucket.
     * @param key Key of the object.
     * @Throws if no object with the given key exists.
     * @Returns the object's parsed Json.
     * @inflight
     */
    getJson(key: string): Promise<Json>;
    /**
     * Retrieve existing objects keys from the bucket.
     * @param prefix Limits the response to keys that begin with the specified prefix.
     * @returns a list of keys or an empty array if the bucket is empty.
     * @inflight
     */
    list(prefix?: string): Promise<string[]>;
    /**
     * Returns a url to the given file.
     * @Throws if the file is not public or if object does not exist.
     * @inflight
     */
    publicUrl(key: string): Promise<string>;
    /**
     * Delete an existing object using a key from the bucket
     * @param key Key of the object.
     * @param opts Options available for delete an item from a bucket.
     * @inflight
     */
    delete(key: string, opts?: BucketDeleteOptions): Promise<void>;
}
/**
 * on create event options
 */
export interface BucketOnCreateProps {
}
/**
 * on delete event options
 */
export interface BucketOnDeleteProps {
}
/**
 * on update event options
 */
export interface BucketOnUpdateProps {
}
/**
 * on any event options
 */
export interface BucketOnEventProps {
}
/**
 * Represents a resource with an inflight "handle" method that can be passed to
 * the bucket events.
 *
 * @inflight  `@winglang/sdk.cloud.IBucketEventHandlerClient`
 */
export interface IBucketEventHandler extends IResource {
}
/**
 * Represents a resource with an inflight "handle" method that can be passed to
 * the bucket events.
 *
 */
export interface IBucketEventHandlerClient {
    /**
     * Function that will be called when an event notification is fired.
     * @inflight
     */
    handle(key: string, type: BucketEventType): Promise<void>;
}
/**
 * on_event notification payload- will be in use after solving issue: https://github.com/winglang/wing/issues/1927
 */
export interface BucketEvent {
    /**
     * the bucket key that triggered the event
     */
    readonly key: string;
    /**
     * type of event
     */
    readonly type: BucketEventType;
}
/**
 * bucket events to subscribe to
 */
export declare enum BucketEventType {
    /**
     * create
     */
    CREATE = "CREATE",
    /**
     * delete
     */
    DELETE = "DELETE",
    /**
     * update
     */
    UPDATE = "UPDATE"
}
/**
 * List of inflight operations available for `Bucket`.
 * @internal
 */
export declare enum BucketInflightMethods {
    /** `Bucket.put` */
    PUT = "put",
    /** `Bucket.get` */
    GET = "get",
    /** `Bucket.list` */
    LIST = "list",
    /** `Bucket.delete` */
    DELETE = "delete",
    /** `Bucket.putJson */
    PUT_JSON = "putJson",
    /** `Bucket.getJson */
    GET_JSON = "getJson",
    /** `Bucket.publicUrl */
    PUBLIC_URL = "publicUrl"
}
