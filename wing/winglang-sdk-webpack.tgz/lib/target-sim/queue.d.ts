import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
/**
 * Simulator implementation of `cloud.Queue`.
 *
 * @inflight `@winglang/sdk.cloud.IQueueClient`
 */
export declare class Queue extends cloud.Queue implements ISimulatorResource {
    private readonly timeout;
    private readonly retentionPeriod;
    private readonly initialMessages;
    constructor(scope: Construct, id: string, props?: cloud.QueueProps);
    addConsumer(inflight: cloud.IQueueAddConsumerHandler, props?: cloud.QueueAddConsumerProps): cloud.Function;
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
