import { NodeJsCode } from "../core";
import { Duration, IInflightHost, Resource } from "../std";
/**
 * Check if a file exists for an specific path
 * @param filePath
 * @Returns Return `true` if the file exists, `false` otherwise.
 */
export declare function exists(filePath: string): Promise<boolean>;
export declare function bindSimulatorResource(filename: string, resource: Resource, host: IInflightHost): void;
export declare function makeSimulatorJsClient(filename: string, resource: Resource): NodeJsCode;
export declare function convertDurationToCronExpression(dur: Duration): string;
