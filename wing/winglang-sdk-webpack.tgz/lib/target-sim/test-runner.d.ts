import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
/**
 * Simulator implementation of `cloud.TestRunner`.
 *
 * @inflight `@winglang/sdk.cloud.ITestRunnerClient`
 */
export declare class TestRunner extends cloud.TestRunner implements ISimulatorResource {
    constructor(scope: Construct, id: string, props?: cloud.TestRunnerProps);
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _preSynthesize(): void;
    private getTestFunctionHandles;
    /** @internal */
    _toInflight(): core.Code;
}
