import { IResource } from "../std";
/**
 * Produce a token that will be replaced with the handle of a resource
 * when the simulator is started. This can be inserted to an environment variable
 * so that the real value can be used by an inflight function.
 */
export declare function simulatorHandleToken(resource: IResource): string;
/**
 * Produce a token that will be replaced with a deploy-time resource attribute
 * when the simulator is started.
 */
export declare function simulatorAttrToken(resource: IResource, attrName: string): string;
