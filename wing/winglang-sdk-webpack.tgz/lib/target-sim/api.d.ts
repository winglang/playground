import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
/**
 * Simulator implementation of `cloud.Api`.
 *
 * @inflight `@winglang/sdk.cloud.IApiClient`
 */
export declare class Api extends cloud.Api implements ISimulatorResource {
    private eventMappings;
    get url(): string;
    private createOrGetFunction;
    private addEndpoint;
    /**
     * Add a inflight to handle GET requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    get(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiGetProps | undefined): void;
    /**
     * Add a inflight to handle POST requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    post(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiPostProps | undefined): void;
    /**
     * Add a inflight to handle PUT requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    put(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiPutProps | undefined): void;
    /**
     * Add a inflight to handle DELETE requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    delete(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiDeleteProps | undefined): void;
    /**
     * Add a inflight to handle PATCH requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    patch(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiPatchProps | undefined): void;
    /**
     * Add a inflight to handle OPTIONS requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    options(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiOptionsProps | undefined): void;
    /**
     * Add a inflight to handle HEAD requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    head(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiHeadProps | undefined): void;
    /**
     * Add a inflight to handle CONNECT requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    connect(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiConnectProps | undefined): void;
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
