import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
/**
 * Simulator implementation of `cloud.Topic`
 *
 * @inflight `@winglang/sdk.cloud.ITopicClient`
 */
export declare class Topic extends cloud.Topic implements ISimulatorResource {
    constructor(scope: Construct, id: string, props?: cloud.TopicProps);
    onMessage(inflight: cloud.ITopicOnMessageHandler, props?: cloud.TopicOnMessageProps): cloud.Function;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    toSimulator(): BaseResourceSchema;
}
