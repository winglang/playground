import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import { Code } from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing";
/**
 * Simulator implementation of `cloud.Schedule`.
 *
 * @inflight `@winglang/sdk.cloud.IScheduleClient`
 */
export declare class Schedule extends cloud.Schedule implements ISimulatorResource {
    private readonly cronExpression;
    constructor(scope: Construct, id: string, props?: cloud.ScheduleProps);
    onTick(inflight: cloud.IScheduleOnTickHandler, props?: cloud.ScheduleOnTickProps): cloud.Function;
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _toInflight(): Code;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
}
