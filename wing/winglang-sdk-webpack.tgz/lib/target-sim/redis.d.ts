import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as core from "../core";
import * as redis from "../redis";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
/**
 * Simulator implementation of `redis.Redis`.
 *
 * @inflight `@winglang/sdk.redis.IRedisClient`
 */
export declare class Redis extends redis.Redis implements ISimulatorResource {
    constructor(scope: Construct, id: string);
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
