import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing";
export declare class Service extends cloud.Service implements ISimulatorResource {
    private readonly autoStart;
    private onStartHandlerToken;
    private onStopHandlerToken?;
    constructor(scope: Construct, id: string, props: cloud.ServiceProps);
    private createServiceFunction;
    toSimulator(): BaseResourceSchema;
    _bind(host: IInflightHost, ops: string[]): void;
    _toInflight(): core.Code;
}
