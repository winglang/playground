import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost, Json } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
export declare class Website extends cloud.Website implements ISimulatorResource {
    private jsonRoutes;
    constructor(scope: Construct, id: string, props: cloud.WebsiteProps);
    get url(): string;
    addJson(path: string, data: Json): string;
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
