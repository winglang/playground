import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
/**
 * Simulator implementation of `cloud.Bucket`.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare class Bucket extends cloud.Bucket implements ISimulatorResource {
    private readonly public;
    private readonly initialObjects;
    constructor(scope: Construct, id: string, props?: cloud.BucketProps);
    /**
     * Iterates over the topics and supply their sim handler
     * @returns an object of Bucket event types (keys) and their topic handlers (values)
     */
    protected convertTopicsToHandles(): Record<string, string>;
    addObject(key: string, body: string): void;
    protected eventHandlerLocation(): string;
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
