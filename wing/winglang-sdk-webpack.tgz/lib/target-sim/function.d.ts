import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
export declare const ENV_WING_SIM_INFLIGHT_RESOURCE_PATH = "WING_SIM_INFLIGHT_RESOURCE_PATH";
export declare const ENV_WING_SIM_INFLIGHT_RESOURCE_TYPE = "WING_SIM_INFLIGHT_RESOURCE_TYPE";
/**
 * Simulator implementation of `cloud.Function`.
 *
 * @inflight `@winglang/sdk.cloud.IFunctionClient`
 */
export declare class Function extends cloud.Function implements ISimulatorResource {
    private readonly timeout;
    constructor(scope: Construct, id: string, inflight: cloud.IFunctionHandler, props?: cloud.FunctionProps);
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
