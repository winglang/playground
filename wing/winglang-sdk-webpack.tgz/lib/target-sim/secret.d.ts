import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { BaseResourceSchema } from "../testing/simulator";
/**
 * Simulator implementation of `cloud.Secret`
 *
 * @inflight `@winglang/sdk.cloud.ISecretClient`
 */
export declare class Secret extends cloud.Secret implements ISimulatorResource {
    private readonly name;
    constructor(scope: Construct, id: string, props?: cloud.SecretProps);
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    toSimulator(): BaseResourceSchema;
}
