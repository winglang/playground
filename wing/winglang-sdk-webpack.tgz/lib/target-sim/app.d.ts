import { Construct } from "constructs";
import { TestRunner } from "./test-runner";
import * as core from "../core";
/**
 * Path of the simulator configuration file in every .wsim tarball.
 */
export declare const SIMULATOR_FILE_PATH = "simulator.json";
/**
 * A construct that knows how to synthesize simulator resources into a
 * Wing simulator (.wsim) file.
 */
export declare class App extends core.App {
    readonly outdir: string;
    readonly isTestEnvironment: boolean;
    /**
     * The test runner for this app.
     */
    protected readonly testRunner: TestRunner;
    private synthed;
    constructor(props: core.AppProps);
    protected tryNew(fqn: string, scope: Construct, id: string, ...args: any[]): any;
    /**
     * Synthesize the app. This creates a tree.json file and a .wsim file in the
     * app's outdir, and returns a path to the .wsim directory.
     */
    synth(): string;
    private synthSimulatorFile;
}
