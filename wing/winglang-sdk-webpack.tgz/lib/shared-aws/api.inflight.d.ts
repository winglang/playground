import { IApiClient } from "../cloud";
export declare class ApiClient implements IApiClient {
    readonly url: string;
    constructor(url: string);
}
