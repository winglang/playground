import { SecretsManagerClient } from "@aws-sdk/client-secrets-manager";
import { GetSecretValueOptions, ISecretClient } from "../cloud";
import { Json } from "../std";
export declare class SecretClient implements ISecretClient {
    private readonly secretArn;
    private readonly client;
    private secretValue?;
    constructor(secretArn: string, client?: SecretsManagerClient);
    value(options?: GetSecretValueOptions): Promise<string>;
    valueJson(options?: GetSecretValueOptions): Promise<Json>;
}
