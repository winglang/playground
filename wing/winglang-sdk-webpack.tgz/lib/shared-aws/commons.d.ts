export declare const COUNTER_HASH_KEY = "id";
