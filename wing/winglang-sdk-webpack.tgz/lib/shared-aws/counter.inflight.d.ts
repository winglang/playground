import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import type { ICounterClient } from "../cloud";
export declare class CounterClient implements ICounterClient {
    private readonly tableName;
    private readonly initial;
    private readonly client;
    constructor(tableName: string, initial?: number, client?: DynamoDBClient);
    inc(amount?: number): Promise<number>;
    dec(amount?: number): Promise<number>;
    peek(): Promise<number>;
    reset(value?: number): Promise<void>;
}
