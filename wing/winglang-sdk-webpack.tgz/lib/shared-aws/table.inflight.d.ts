import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { ITableClient } from "../cloud";
import { Json } from "../std";
export declare class TableClient implements ITableClient {
    private readonly tableName;
    private readonly primaryKey;
    private readonly columns;
    private readonly client;
    constructor(tableName: string, primaryKey: string, columns: string, client?: DynamoDBClient);
    insert(key: string, row: Json): Promise<void>;
    update(key: String, row: Json): Promise<void>;
    delete(key: string): Promise<void>;
    get(key: string): Promise<Json>;
    list(): Promise<Array<Json>>;
}
