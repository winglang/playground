import type { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
import { IApiEndpointHandlerClient } from "../cloud/api";
export declare class ApiOnRequestHandlerClient {
    private readonly handler;
    constructor({ handler }: {
        handler: IApiEndpointHandlerClient;
    });
    handle(request: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
}
