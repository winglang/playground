import { S3Client } from "@aws-sdk/client-s3";
import { BucketDeleteOptions, IBucketClient } from "../cloud";
import { Duration, Json } from "../std";
export declare class BucketClient implements IBucketClient {
    private readonly bucketName;
    private readonly _public;
    private readonly s3Client;
    constructor(bucketName: string, _public?: boolean, s3Client?: S3Client);
    put(key: string, body: string): Promise<void>;
    putJson(key: string, body: Json): Promise<void>;
    get(key: string): Promise<string>;
    getJson(key: string): Promise<Json>;
    private exists;
    private getLocation;
    /**
     * Returns a url to the given file.
     * @Throws if the file is not public or if object does not exist.
     */
    publicUrl(key: string): Promise<string>;
    /**
     * Returns a signed url to the given file. This URL can be used by anyone to
     * access the file until the link expires (defaults to 24 hours).
     * @param key The key to reach
     * @param duration Time until expires
     */
    signed_url(key: string, duration?: Duration): Promise<string>;
    /**
     * List all keys in the bucket.
     * @param prefix Limits the response to keys that begin with the specified prefix
     * TODO - add pagination support, currently returns all existing keys in the bucket
     * https://github.com/winglang/wing/issues/315
     */
    list(prefix?: string): Promise<string[]>;
    /**
     * Delete an existing object using a key from the bucket
     * @param key Key of the object.
     * @param opts Option object supporting additional strategies to delete an item from a bucket
     */
    delete(key: string, opts?: BucketDeleteOptions): Promise<void>;
}
