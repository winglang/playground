import { PolicyStatement } from "./types";
export declare function calculateTopicPermissions(arn: string, ops: string[]): PolicyStatement[];
export declare function calculateQueuePermissions(arn: string, ops: string[]): PolicyStatement[];
export declare function calculateCounterPermissions(arn: string, ops: string[]): PolicyStatement[];
export declare function calculateBucketPermissions(arn: string, ops: string[]): PolicyStatement[];
export declare function calculateSecretPermissions(arn: string, ops: string[]): PolicyStatement[];
