import { IWebsiteClient } from "../cloud";
export declare class WebsiteInflight implements IWebsiteClient {
    constructor();
}
