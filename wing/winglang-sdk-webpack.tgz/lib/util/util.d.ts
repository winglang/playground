/**
 * Utility functions.
 */
export declare class Util {
    /**
     * Returns the value of an environment variable. Throws if not found or empty.
     * @param name The name of the environment variable.
     */
    static env(name: string): string;
    /**
     * Returns the value of an environment variable. Returns `nil` if not found or empty.
     * @param name The name of the environment variable.
     * @returns The value of the environment variable or `nil`.
     */
    static tryEnv(name: string): string | undefined;
}
