import { Construct } from "constructs";
/**
 * Props for all `App` classes.
 */
export interface AppProps {
    /**
     * Directory where artifacts are synthesized to.
     * @default - current working directory
     */
    readonly outdir?: string;
    /**
     * The name of the app.
     * @default "app"
     */
    readonly name?: string;
    /**
     * The path to a state file which will track all synthesized files. If a
     * statefile is not specified, we won't be able to remove extrenous files.
     * @default - no state file
     */
    readonly stateFile?: string;
    /**
     * Absolute paths to plugin javascript files.
     * @default - [] no plugins
     */
    readonly plugins?: string[];
    /**
     * Whether or not this app is being synthesized into a test environment.
     * @default false
     */
    readonly isTestEnvironment?: boolean;
}
/**
 * A Wing application.
 */
export declare abstract class App extends Construct {
    /**
     * Returns the root app.
     */
    static of(scope: Construct): App;
    /**
     * Loads the `App` class for the given target.
     * @param target one of the supported targets
     * @returns an `App` class constructor
     */
    static for(target: string): any;
    /**
     * The output directory.
     */
    abstract readonly outdir: string;
    /**
     * Whether or not this app is being synthesized into a test environment.
     */
    abstract readonly isTestEnvironment: boolean;
    /**
     * The ".wing" directory, which is where the compiler emits its output. We are taking an implicit
     * assumption here that it is always set to be `$outdir/.wing` which is currently hard coded into
     * the `cli/compile.ts` file.
     */
    get workdir(): string;
    /**
     * Synthesize the app into an artifact.
     */
    abstract synth(): string;
    /**
     * Creates a new object of the given FQN.
     * @param fqn the fqn of the class to instantiate
     * @param ctor the constructor of the class to instantiate (undefined for abstract classes)
     * @param scope the scope of the resource
     * @param id the id of the resource
     * @param args the arguments to pass to the resource
     * @returns the new instance
     * @throws if the FQN is not supported
     */
    new(fqn: string, ctor: any, scope: Construct, id: string, ...args: any[]): any;
    /**
     * Creates a new object of the given abstract class FQN.
     */
    newAbstract(fqn: string, scope: Construct, id: string, ...args: any[]): any;
    /**
     * Can be overridden by derived classes to inject dependencies.
     *
     * @param fqn The fully qualified name of the class to instantiate (jsii).
     * @param scope The construct scope.
     * @param id The construct id.
     * @param args The arguments to pass to the constructor.
     */
    protected tryNew(fqn: string, scope: Construct, id: string, ...args: any[]): any;
}
export declare function preSynthesizeAllConstructs(app: App): void;
