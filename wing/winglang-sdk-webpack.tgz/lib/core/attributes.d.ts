export declare const WING_ATTRIBUTE_RESOURCE_CONNECTIONS = "wing:resource:connections";
