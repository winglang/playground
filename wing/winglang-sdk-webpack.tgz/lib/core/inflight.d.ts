/**
 * Reference to a piece of code.
 */
export declare abstract class Code {
    /**
     * The language of the code.
     */
    abstract readonly language: Language;
    /**
     * The code.
     */
    abstract readonly text: string;
    /**
     * Generate a hash of the code contents.
     */
    get hash(): string;
}
/**
 * The language of a piece of code.
 */
export declare enum Language {
    /** Node.js */
    NODE_JS = "nodejs"
}
/**
 * Reference to a piece of Node.js code.
 */
export declare class NodeJsCode extends Code {
    /**
     * Reference code from a file path.
     */
    static fromFile(path: string): NodeJsCode;
    /**
     * Reference code directly from a string.
     */
    static fromInline(text: string): NodeJsCode;
    readonly language = Language.NODE_JS;
    readonly text: string;
    private constructor();
}
export type InflightBindings = Record<string, InflightBinding>;
/**
 * Props for `Inflight`.
 */
export interface InflightProps {
    /**
     * Reference to the inflight code. Only JavaScript code is currently
     * supported.
     *
     * The JavaScript code needs be in the form `async handle(event) { ... }`, and
     * all references to resources must be made through `this.<resource>`.
     */
    readonly code: Code;
    /**
     * Data and resource binding information.
     * @default - no bindings
     */
    readonly bindings?: InflightBindings;
}
/**
 * An inflight binding.
 */
export interface InflightBinding {
    /**
     * The resource or capturable value.
     */
    readonly obj: any;
    /**
     * The list of operations used on the resource.
     */
    readonly ops?: string[];
}
/**
 * Utility class with functions about inflight clients.
 */
export declare class InflightClient {
    /**
     * Creates a `Code` instance with code for creating an inflight client.
     */
    static for(dirname: string, filename: string, clientClass: string, args: string[]): Code;
    private constructor();
}
