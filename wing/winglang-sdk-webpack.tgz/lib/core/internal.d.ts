export declare function serializeImmutableData(obj: any): string;
