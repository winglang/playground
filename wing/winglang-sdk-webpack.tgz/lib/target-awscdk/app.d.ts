import { Construct } from "constructs";
import { App as CoreApp, AppProps } from "../core";
/**
 * AWS-CDK App props
 */
export interface CdkAppProps extends AppProps {
    /**
     * CDK Stack Name
     * @default - undefined
     */
    readonly stackName?: string;
}
/**
 * An app that knows how to synthesize constructs into CDK configuration.
 */
export declare class App extends CoreApp {
    readonly outdir: string;
    readonly isTestEnvironment: boolean;
    private readonly cdkApp;
    private readonly cdkStack;
    private readonly pluginManager;
    private synthed;
    private synthedOutput;
    constructor(props: CdkAppProps);
    /**
     * Synthesize the app into CDK configuration in a `cdk.out` directory.
     *
     * This method returns a cleaned snapshot of the resulting CDK template
     * for unit testing.
     */
    synth(): string;
    protected tryNew(fqn: string, scope: Construct, id: string, ...args: any[]): any;
}
