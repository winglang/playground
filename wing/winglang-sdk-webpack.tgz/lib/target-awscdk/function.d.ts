import { Function as CdkFunction, IEventSource } from "aws-cdk-lib/aws-lambda";
import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
import { PolicyStatement } from "../shared-aws";
/**
 * AWS implementation of `cloud.Function`.
 *
 * @inflight `@winglang/sdk.cloud.IFunctionClient`
 */
export declare class Function extends cloud.Function {
    private readonly function;
    /** Function ARN */
    readonly arn: string;
    constructor(scope: Construct, id: string, inflight: cloud.IFunctionHandler, props?: cloud.FunctionProps);
    /** @internal */
    _toInflight(): core.Code;
    /**
     * Add environment variable to the function.
     */
    addEnvironment(name: string, value: string): void;
    /**
     * Add a policy statement to the Lambda role.
     */
    addPolicyStatements(...statements: PolicyStatement[]): void;
    /** @internal */
    get _functionName(): string;
    /** @internal */
    get _function(): CdkFunction;
    /** @internal */
    _addEventSource(eventSource: IEventSource): void;
    private envName;
}
