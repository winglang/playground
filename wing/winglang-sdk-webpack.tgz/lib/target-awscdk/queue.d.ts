import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
/**
 * AWS implementation of `cloud.Queue`.
 *
 * @inflight `@winglang/sdk.cloud.IQueueClient`
 */
export declare class Queue extends cloud.Queue {
    private readonly queue;
    constructor(scope: Construct, id: string, props?: cloud.QueueProps);
    addConsumer(inflight: cloud.IQueueAddConsumerHandler, props?: cloud.QueueAddConsumerProps): cloud.Function;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
}
