import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
/**
 * AWS Implementation of `cloud.Topic`.
 *
 * @inflight `@winglang/sdk.cloud.ITopicClient`
 */
export declare class Topic extends cloud.Topic {
    private readonly topic;
    constructor(scope: Construct, id: string, props?: cloud.TopicProps);
    /**
     * topic's arn
     */
    get arn(): string;
    onMessage(inflight: cloud.ITopicOnMessageHandler, props?: cloud.TopicOnMessageProps): cloud.Function;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
}
