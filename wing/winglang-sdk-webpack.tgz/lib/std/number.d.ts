import { Json } from "./json";
/**
 * Number
 */
export declare class Number {
    /**
     * Parse a number from Json.
     *
     * @macro ((args) => { if (typeof args !== "number") {throw new Error("unable to parse " + typeof args + " " + args + " as a number")}; return JSON.parse(JSON.stringify(args)) })($args$)
     *
     * @param json to parse number from.
     * @returns a number.
     */
    static fromJson(json: Json): number;
    /**
     * Parse a number from string.
     *
     * @macro ((args) => { if (isNaN(args)) {throw new Error("unable to parse \"" + args + "\" as a number")}; return parseInt(args) })($args$)
     *
     * @param str to parse number from.
     * @returns a number.
     */
    static fromStr(str: string): number;
}
