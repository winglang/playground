import { T1 } from "./util";
/**
 * Immutable Array
 *
 * @typeparam T1
 */
export declare class ImmutableArray {
    /**
     * The length of the array
     * @returns the length of the array
     */
    get length(): number;
    /**
     * Get the value at the given index
     * @param index index of the value to get
     * @returns the value at the given index
     */
    at(index: number): T1;
    /**
     * Merge arr to the end of this array
     * @param arr array to merge
     *
     * @returns a new ImmutableArray with the values of this array followed by the values of arr
     */
    concat(arr: ImmutableArray): ImmutableArray;
    /**
     * Checks if this array includes searchElement.
     *
     * @macro $self$.includes($args$)
     *
     * @param searchElement to search for.
     * @returns true if this array includes searchElement.
     */
    contains(searchElement: T1): boolean;
    /**
     * Create a mutable shallow copy of this array
     *
     * @macro [...($self$)]
     *
     * @returns a MutableArray with the same values as this array
     */
    copyMut(): MutableArray;
    /**
     * Returns the index of the first occurrence of searchElement found.
     *
     * @macro $self$.indexOf($args$)
     *
     * @param searchElement to search for.
     * @returns the index of the first occurrence of searchElement found, or -1 if not found.
     */
    indexOf(searchElement: T1): number;
    /**
     * Returns a new string containing the concatenated values in this array,
     * separated by commas or a specified separator string. If the array has only
     * one item, then that item will be returned without using the separator.
     *
     * @returns a string containing the concatenated values in this array,
     * separated by commas or a specified separator string.
     */
    join(separator?: string): string;
    /**
     * Returns the index of the last occurrence of searchElement found.
     *
     * @macro $self$.lastIndexOf($args$)
     *
     * @param searchElement to search for.
     * @returns the index of the last occurrence of searchElement found, or -1 if not found.
     */
    lastIndexOf(searchElement: T1): number;
}
/**
 * Mutable Array
 *
 * @typeparam T1
 */
export declare class MutableArray {
    /**
     * The length of the array
     * @returns the length of the array
     */
    get length(): number;
    /**
     * Get the value at the given index
     * @param index index of the value to get
     * @returns the value at the given index
     */
    at(index: number): T1;
    /**
     * Merge arr to the end of this array
     * @param arr array to merge
     *
     * @returns a new MutableArray with the values of this array followed by the values of arr
     */
    concat(arr: MutableArray): MutableArray;
    /**
     * Checks if this array includes searchElement.
     *
     * @macro $self$.includes($args$)
     *
     * @param searchElement to search for.
     * @returns true if this array includes searchElement.
     */
    contains(searchElement: T1): boolean;
    /**
     * Create an immutable shallow copy of this array
     *
     * @macro Object.freeze([...($self$)])
     *
     * @returns an ImmutableArray with the same values as this array
     */
    copy(): ImmutableArray;
    /**
     * Returns the index of the first occurrence of searchElement found.
     *
     * @macro $self$.indexOf($args$)
     *
     * @param searchElement to search for.
     * @returns the index of the first occurrence of searchElement found, or -1 if not found.
     */
    indexOf(searchElement: T1): number;
    /**
     * Returns a new string containing the concatenated values in this array,
     * separated by commas or a specified separator string. If the array has only
     * one item, then that item will be returned without using the separator.
     *
     * @returns a string containing the concatenated values in this array,
     * separated by commas or a specified separator string.
     */
    join(separator?: string): string;
    /**
     * Returns the index of the last occurrence of searchElement found.
     *
     * @macro $self$.lastIndexOf($args$)
     *
     * @param searchElement to search for.
     * @returns the index of the last occurrence of searchElement found, or -1 if not found.
     */
    lastIndexOf(searchElement: T1): number;
    /**
     * Add value to end of array
     * @param value value to add
     */
    push(value: T1): void;
    /**
     * Remove value from end of array
     * @returns the value removed
     */
    pop(): T1;
}
