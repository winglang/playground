import { ImmutableArray } from "./array";
import { T1 } from "./util";
/**
 * Immutable Map
 *
 * @typeparam T1
 */
export declare class ImmutableMap {
    /**
     * Returns the number of elements in the map.
     *
     * TODO: For now this has to be a method rather than a getter as macros only work on methods https://github.com/winglang/wing/issues/1658
     * @macro Object.keys($self$).length
     *
     * @returns The number of elements in map
     */
    size(): number;
    /**
     * Returns a specified element from the map.
     *
     * If the value that is associated to the provided key is an object, then you will get a reference
     * to that object and any change made to that object will effectively modify it inside the map.
     *
     * @macro ($self$)[$args$]
     *
     * @param key The key of the element to return.
     * @returns The element associated with the specified key, or undefined if the key can't be found
     */
    get(key: string): T1;
    /**
     * Returns a boolean indicating whether an element with the specified key exists or not.
     *
     * @macro ($args$ in ($self$))
     *
     * @param key The key of the element to test for presence
     * @returns true if an element with the specified key exists in the map; otherwise false.
     */
    has(key: string): boolean;
    /**
     * Create a mutable shallow copy of this map
     *
     * @macro {...($self$)}
     *
     * @returns a MutableMap with the same values as this map
     */
    copyMut(): MutableMap;
    /**
     * Returns the keys of this map
     *
     * @macro Object.keys($self$)
     *
     * @returns an array containing the keys of this map
     */
    keys(): ImmutableArray;
}
/**
 * Mutable Map
 *
 * @typeparam T1
 */
export declare class MutableMap {
    /**
     * Returns the number of elements in the map.
     *
     * TODO: For now this has to be a method rather than a getter as macros only work on methods https://github.com/winglang/wing/issues/1658
     * @macro Object.keys($self$).length
     *
     * @returns The number of elements in map
     */
    size(): number;
    /**
     * Removes all elements
     *
     * @macro ((map) => { for(const k in map){delete map[k]}; })($self$)
     */
    clear(): void;
    /**
     * Create an immutable shallow copy of this map
     *
     * @macro Object.freeze({...($self$)})
     *
     * @returns an ImmutableMap with the same values as this map
     */
    copy(): ImmutableMap;
    /**
     * Removes the specified element from a map.
     *
     * @macro (delete ($self$)[$args$])
     *
     * @param key The key
     * @returns true if the given key is no longer present
     */
    delete(key: string): boolean;
    /**
     * Returns a specified element from the map.
     *
     * If the value that is associated to the provided key is an object, then you will get a reference
     * to that object and any change made to that object will effectively modify it inside the map.
     *
     * @macro ($self$)[$args$]
     *
     * @param key The key of the element to return.
     * @returns The element associated with the specified key, or undefined if the key can't be found
     */
    get(key: string): T1;
    /**
     * Returns a boolean indicating whether an element with the specified key exists or not.
     *
     * @macro ($args$ in ($self$))
     *
     * @param key The key of the element to test for presence
     * @returns true if an element with the specified key exists in the map; otherwise false.
     */
    has(key: string): boolean;
    /**
     * Adds or updates an entry in a Map object with a specified key and a value.
     *
     * TODO: revisit this macro after we support indexed args https://github.com/winglang/wing/issues/1659
     * @macro ((obj, args) => { obj[args[0]] = args[1]; })($self$, [$args$])
     *
     * @param key The key of the element to add
     * @param value The value of the element to add
     */
    set(key: string, value: T1): void;
}
