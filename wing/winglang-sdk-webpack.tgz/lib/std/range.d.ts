/**
 * Range
 */
export declare class Range {
    /**
     * Generate a range of numbers.
     *
     * @param start lower bound of the range.
     * @param end upper bound of the range.
     * @param inclusive if true, the upper bound value is included.
     * @returns a iterator.
     */
    static of(start: number, end: number, inclusive?: boolean): Array<number>;
}
