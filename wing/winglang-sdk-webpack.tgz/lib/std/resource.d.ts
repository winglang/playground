import { Construct, IConstruct } from "constructs";
import { Code } from "../core/inflight";
import { IInspectable, TreeInspector } from "../core/tree";
/**
 * A resource that can run inflight code.
 */
export interface IInflightHost extends IResource {
}
/**
 * Abstract interface for `Resource`.
 */
export interface IResource extends IInspectable, IConstruct {
    /**
     * List of inbound and outbound connections to other resources.
     * @internal
     */
    _connections: Connection[];
    /**
     * Information on how to display a resource in the UI.
     */
    readonly display: Display;
    /**
     * Binds the resource to the host so that it can be used by inflight code.
     *
     * If `ops` contains any operations not supported by the resource, it should throw an
     * error.
     *
     * @internal
     */
    _bind(host: IInflightHost, ops: string[]): void;
    /**
     * Register that the resource needs to be bound to the host for the given
     * operations. This means that the resource's `_bind` method will be called
     * during pre-synthesis.
     *
     * @internal
     */
    _registerBind(host: IInflightHost, ops: string[]): void;
    /**
     * Return a code snippet that can be used to reference this resource inflight.
     * Note this code snippet may by async code, so it's unsafe to run it in a
     * constructor or other sync context.
     * @internal
     */
    _toInflight(): Code;
    /**
     * A hook for performing operations after the tree of resources has been
     * created, but before they are synthesized.
     *
     * Currently used for binding resources to hosts.
     *
     * @internal
     */
    _preSynthesize(): void;
}
/**
 * Shared behavior between all Wing SDK resources.
 */
export declare abstract class Resource extends Construct implements IResource {
    /**
     * Adds a connection between two resources. A connection is a piece of
     * metadata describing how one resource is related to another resource. This
     * metadata is recorded in the tree.json file.
     *
     * @experimental
     */
    static addConnection(props: AddConnectionProps): void;
    private readonly bindMap;
    /** @internal */
    readonly _connections: Connection[];
    /**
     * A list of all inflight operations that are supported by this resource.
     */
    private readonly inflightOps;
    /**
     * Information on how to display a resource in the UI.
     */
    readonly display: Display;
    /**
     * Record that this resource supports the given inflight operation.
     *
     * This is used to give better error messages if the compiler attempts to bind
     * a resource with an operation that is not supported.
     *
     * @internal
     */
    _addInflightOps(...ops: string[]): void;
    /**
     * Binds the resource to the host so that it can be used by inflight code.
     *
     * You can override this method to perform additional logic like granting
     * IAM permissions to the host based on what methods are being called. But
     * you must call `super._bind(host, ops)` to ensure that the resource is
     * actually bound.
     *
     * @internal
     */
    _bind(host: IInflightHost, ops: string[]): void;
    /**
     * Register that the resource needs to be bound to the host for the given
     * operations. This means that the resource's `_bind` method will be called
     * during pre-synthesis.
     *
     * @internal
     */
    _registerBind(host: IInflightHost, ops: string[]): void;
    /**
     * Register a binding between an object (either data or resource) and a host.
     *
     * - Primitives and Duration objects are ignored.
     * - Arrays, sets and maps and structs (Objects) are recursively bound.
     * - Resources are bound to the host by calling their _bind() method.
     *
     * @param obj The object to bind.
     * @param host The host to bind to
     * @param ops The set of operations that may access the object (use "?" to indicate that we don't
     * know the operation)
     *
     * @internal
     */
    protected _registerBindObject(obj: any, host: IResource, ops?: string[]): void;
    /**
     * A hook for performing operations after the tree of resources has been
     * created, but before they are synthesized.
     *
     * Currently used for binding resources to hosts.
     *
     * @internal
     */
    _preSynthesize(): void;
    /**
     * Return a code snippet that can be used to reference this resource inflight.
     *
     * TODO: support passing an InflightRuntime enum to indicate which language
     * runtime we're targeting.
     *
     * @internal
     */
    abstract _toInflight(): Code;
    /**
     * @internal
     */
    _inspect(inspector: TreeInspector): void;
    /**
     * "Lifts" a value into an inflight context. If the value is a resource (i.e. has a `_toInflight`
     * method), this method will be called and the result will be returned. Otherwise, the value is
     * returned as-is.
     *
     * @param value The value to lift.
     * @returns a string representation of the value in an inflight context.
     * @internal
     */
    protected _lift(value: any): string;
}
/**
 * The direction of a connection.
 *
 * Visually speaking, if a resource A has an outbound connection with resource B,
 * the arrow would point from A to B, and vice versa for inbound connections.
 */
export declare enum Direction {
    /**
     * Indicates that this resource calls, triggers, or references
     * the resource it is connected to.
     */
    OUTBOUND = "outbound",
    /**
     * Indicates that this resource is called, triggered, or referenced by
     * the resource it is connected to.
     */
    INBOUND = "inbound"
}
/**
 * Props for `Resource.addConnection`.
 */
export interface AddConnectionProps {
    /**
     * The resource creating the connection to `to`.
     */
    readonly from: IResource;
    /**
     * The resource `from` is connecting to.
     */
    readonly to: IResource;
    /**
     * The type of relationship between the resources.
     */
    readonly relationship: string;
    /**
     * Whether the relationship is implicit, i.e. it is not explicitly
     * defined by the user.
     * @default false
     */
    readonly implicit?: boolean;
}
/**
 * A connection between two resources.
 */
export interface Connection {
    /**
     * The resource this connection is to.
     */
    readonly resource: IResource;
    /**
     * The type of relationship with the resource.
     */
    readonly relationship: string;
    /**
     * The direction of the connection.
     */
    readonly direction: Direction;
    /**
     * Whether the relationship is implicit, i.e. it is not explicitly
     * defined by the user.
     */
    readonly implicit: boolean;
}
/**
 * Annotations about what resources an inflight operation may access.
 *
 * The following example says that the operation may call "put" on a resource
 * at "this.inner", or it may call "get" on a resource passed as an argument named
 * "other".
 * @example
 * { "this.inner": { ops: ["put"] }, "other": { ops: ["get"] } }
 *
 * @internal
 */
export interface OperationAnnotation {
    [resource: string]: {
        ops: string[];
    };
}
/**
 * Properties for the Display class.
 */
export interface DisplayProps {
    /**
     * Title of the resource.
     * @default - No title.
     */
    readonly title?: string;
    /**
     * Description of the resource.
     * @default - No description.
     */
    readonly description?: string;
    /**
     * Whether the resource should be hidden from the UI.
     * @default - Undefined
     */
    readonly hidden?: boolean;
}
/**
 * Information on how to display a resource in the UI.
 */
export declare class Display {
    /**
     * Title of the resource.
     */
    title?: string;
    /**
     * Description of the resource.
     */
    description?: string;
    /**
     * Whether the resource should be hidden from the UI.
     */
    hidden?: boolean;
    constructor(props?: DisplayProps);
}
