import { Construct } from "constructs";
import { StorageContainer } from "../.gen/providers/azurerm/storage-container";
import * as cloud from "../cloud";
import { BucketOnDeleteProps, BucketOnEventProps, BucketOnUpdateProps, BucketOnCreateProps, IBucketEventHandler } from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
/**
 * Azure bult-in storage account permissions.
 */
export declare enum StorageAccountPermissions {
    /** Read only permission */
    READ = "Storage Blob Data Reader",
    /** Read write permission */
    READ_WRITE = "Storage Blob Data Contributor"
}
/**
 * Azure implementation of `cloud.Bucket`.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare class Bucket extends cloud.Bucket {
    /** Storage container */
    readonly storageContainer: StorageContainer;
    private readonly public;
    private readonly storageAccount;
    constructor(scope: Construct, id: string, props?: cloud.BucketProps);
    addObject(key: string, body: string): void;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /**
     * Run an inflight whenever a file is uploaded to the bucket.
     */
    onCreate(fn: IBucketEventHandler, opts?: BucketOnCreateProps): void;
    /**
     * Run an inflight whenever a file is deleted from the bucket.
     */
    onDelete(fn: IBucketEventHandler, opts?: BucketOnDeleteProps): void;
    /**
     * Run an inflight whenever a file is updated in the bucket.
     */
    onUpdate(fn: IBucketEventHandler, opts?: BucketOnUpdateProps): void;
    /**
     * Run an inflight whenever a file is uploaded, modified, or deleted from the bucket.
     */
    onEvent(fn: IBucketEventHandler, opts?: BucketOnEventProps): void;
    /** @internal */
    _toInflight(): core.Code;
    private isPublicEnvName;
    private envName;
    private envStorageAccountName;
}
