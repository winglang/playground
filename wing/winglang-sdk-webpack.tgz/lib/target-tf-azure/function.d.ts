import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
import { IResource } from "../std";
/**
 * Azure scoped role assignment.
 */
export interface ScopedRoleAssignment {
    /** The azure scope ie. /subscription/xxxxx/yyyyy/zzz */
    readonly scope: string;
    /** Role definition to assign */
    readonly roleDefinitionName: string;
}
/**
 * Azure implementation of `cloud.Function`.
 *
 * @inflight `@winglang/wingsdk.cloud.IFunctionClient`
 */
export declare class Function extends cloud.Function {
    private readonly function;
    private readonly servicePlan;
    private readonly storageAccount;
    private readonly resourceGroup;
    private permissions?;
    constructor(scope: Construct, id: string, inflight: cloud.IFunctionHandler, props?: cloud.FunctionProps);
    /**
     *  Adds role to function for given azure scope
     *
     * @param scopedResource - The resource to which the role assignment will be scoped.
     * @param scopedRoleAssignment - The mapping of azure scope to role definition name.
     */
    addPermission(scopedResource: IResource, scopedRoleAssignment: ScopedRoleAssignment): void;
    /** @internal */
    _toInflight(): core.Code;
}
