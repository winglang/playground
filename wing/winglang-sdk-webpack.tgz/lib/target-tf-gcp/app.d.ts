import { Construct } from "constructs";
import { AppProps as CdktfAppProps } from "../core";
import { CdktfApp } from "../shared-tf/app";
/**
 * GCP App props.
 */
export interface AppProps extends CdktfAppProps {
    /**
     * The Google Cloud project ID.
     */
    readonly projectId: string;
    /**
     * The Google Cloud storage location, used for all storage resources.
     * @see https://cloud.google.com/storage/docs/locations
     */
    readonly storageLocation: string;
}
/**
 * An app that knows how to synthesize constructs into a Terraform configuration
 * for GCP resources.
 */
export declare class App extends CdktfApp {
    /**
     * The Google Cloud project ID.
     */
    readonly projectId: string;
    /**
     * The Google Cloud storage location, used for all storage resources.
     */
    readonly storageLocation: string;
    constructor(props: AppProps);
    protected tryNew(fqn: string, scope: Construct, id: string, ...args: any[]): any;
}
