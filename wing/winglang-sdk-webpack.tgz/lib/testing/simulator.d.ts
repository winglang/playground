import { Tree } from "./tree";
import { Trace } from "../cloud";
/**
 * Props for `Simulator`.
 */
export interface SimulatorProps {
    /**
     * Path to a Wing simulator output directory (.wsim).
     */
    readonly simfile: string;
    /**
     * The factory that produces resource simulations.
     *
     * @default - a factory that produces simulations for built-in Wing SDK
     * resources
     */
    readonly factory?: ISimulatorFactory;
}
/**
 * A collection of callbacks that are invoked at key lifecycle events of the
 * simulator.
 */
export interface ISimulatorLifecycleHooks {
    /**
     * A function to run whenever a trace is emitted.
     */
    onTrace?(event: Trace): void;
}
/**
 * Props for `ISimulatorContext.withTrace`.
 */
export interface IWithTraceProps {
    /**
     * The trace message.
     */
    readonly message: any;
    /**
     * A function to run as part of the trace.
     */
    activity(): Promise<any>;
}
/**
 * Context that is passed to individual resource simulations.
 */
export interface ISimulatorContext {
    /**
     * This directory where the compilation output is
     */
    readonly simdir: string;
    /**
     * The path of the resource that is being simulated.
     */
    readonly resourcePath: string;
    /**
     * Find a resource simulation by its handle. Throws if the handle isn't valid.
     */
    findInstance(handle: string): ISimulatorResourceInstance;
    /**
     * Add a trace. Traces are breadcrumbs of information about resource
     * operations that occurred during simulation, useful for understanding how
     * resources interact or debugging an application.
     */
    addTrace(trace: Trace): void;
    /**
     * Register a trace associated with a resource activity. The activity will be
     * run, and the trace will be populated with the result's success or failure.
     */
    withTrace(trace: IWithTraceProps): Promise<any>;
    /**
     * Get a list of all traces until this point.
     */
    listTraces(): Trace[];
}
/**
 * A subscriber that can listen for traces emitted by the simulator.
 */
export interface ITraceSubscriber {
    /**
     * Called when a trace is emitted.
     */
    callback(event: Trace): void;
}
/**
 * A simulator that can be used to test your application locally.
 */
export declare class Simulator {
    private readonly _factory;
    private _config;
    private readonly simdir;
    private _running;
    private readonly _handles;
    private _traces;
    private readonly _traceSubscribers;
    private _tree;
    constructor(props: SimulatorProps);
    private _loadApp;
    /**
     * Start the simulator.
     */
    start(): Promise<void>;
    /**
     * Stop the simulation and clean up all resources.
     */
    stop(): Promise<void>;
    /**
     * Stop the simulation, reload the simulation tree from the latest version of
     * the app file, and restart the simulation.
     */
    reload(): Promise<void>;
    /**
     * Get a list of all resource paths.
     */
    listResources(): string[];
    /**
     * Get a list of all traces from the most recent simulation run.
     */
    listTraces(): Trace[];
    /**
     * Get a simulated resource instance.
     * @returns the resource
     */
    getResource(path: string): any;
    /**
     * Get a simulated resource instance.
     * @returns The resource of undefined if not found
     */
    tryGetResource(path: string): any | undefined;
    /**
     * Obtain a resource's configuration, including its type, props, and attrs.
     * @returns The resource configuration or undefined if not found
     */
    tryGetResourceConfig(path: string): BaseResourceSchema | undefined;
    /**
     * Obtain a resource's configuration, including its type, props, and attrs.
     * @param path The resource path
     * @returns The resource configuration
     */
    getResourceConfig(path: string): BaseResourceSchema;
    /**
     * Register a subscriber that will be notified when a trace is emitted by
     * the simulator.
     */
    onTrace(subscriber: ITraceSubscriber): void;
    /**
     * Obtain information about the application's resource tree.
     */
    tree(): Tree;
    private _addTrace;
    /**
     * Return an object with all tokens in it resolved to their appropriate
     * values.
     *
     * A token can be a string like "${app/my_bucket#attrs.handle}". This token
     * would be resolved to the "handle" attribute of the resource at path
     * "app/my_bucket". If that attribute does not exist at the time of resolution
     * (for example, if my_bucket is not being simulated yet), an error will be
     * thrown.
     *
     * Tokens can also be nested, like "${app/my_bucket#attrs.handle}/foo/bar".
     *
     * @param obj The object to resolve tokens in.
     * @param source The path of the resource that requested the token to be resolved.
     */
    private resolveTokens;
}
/**
 * A factory that can turn resource descriptions into (inflight) resource simulations.
 */
export interface ISimulatorFactory {
    /**
     * Resolve the parameters needed for creating a specific resource simulation.
     */
    resolve(type: string, props: any, context: ISimulatorContext): ISimulatorResourceInstance;
}
/**
 * Shared interface for resource simulations.
 */
export interface ISimulatorResourceInstance {
    /**
     * Perform any async initialization required by the resource. Return a map of
     * the resource's runtime attributes.
     */
    init(): Promise<Record<string, any>>;
    /**
     * Stop the resource and clean up any physical resources it may have created
     * (files, ports, etc).
     */
    cleanup(): Promise<void>;
}
/** Schema for simulator.json */
export interface WingSimulatorSchema {
    /** The list of resources. */
    readonly resources: BaseResourceSchema[];
    /** The version of the Wing SDK used to synthesize the .wsim file. */
    readonly sdkVersion: string;
}
/** Schema for individual resources */
export interface BaseResourceSchema {
    /** The resource path from the app's construct tree. */
    readonly path: string;
    /** The type of the resource. */
    readonly type: string;
    /** The resource-specific properties needed to create this resource. */
    readonly props: {
        [key: string]: any;
    };
    /** The resource-specific attributes that are set after the resource is created. */
    readonly attrs: Record<string, any>;
}
/** Schema for resource attributes */
export interface BaseResourceAttributes {
    /** The resource's simulator-unique id. */
    readonly handle: string;
}
