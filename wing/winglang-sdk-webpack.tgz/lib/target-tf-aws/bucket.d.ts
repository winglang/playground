import { Construct } from "constructs";
import { S3Bucket } from "../.gen/providers/aws/s3-bucket";
import * as cloud from "../cloud";
import { BucketEventType, Topic } from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
import { NameOptions } from "../utils/resource-names";
/**
 * Bucket prefix provided to Terraform must be between 3 and 37 characters.
 *
 * Bucket names are allowed to contain lowercase alphanumeric characters and
 * dashes (-). We generate names without dots (.) to avoid some partial
 * restrictions on bucket names with dots.
 */
export declare const BUCKET_PREFIX_OPTS: NameOptions;
/**
 * AWS implementation of `cloud.Bucket`.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare class Bucket extends cloud.Bucket {
    private readonly bucket;
    private readonly public;
    constructor(scope: Construct, id: string, props?: cloud.BucketProps);
    addObject(key: string, body: string): void;
    protected eventHandlerLocation(): string;
    protected createTopic(actionType: BucketEventType): Topic;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private isPublicEnvName;
    private envName;
}
export declare function createEncryptedBucket(scope: Construct, isPublic: boolean, name?: string): S3Bucket;
