import { Construct } from "constructs";
import { TestRunner } from "./test-runner";
import { S3Bucket } from "../.gen/providers/aws/s3-bucket";
import { Subnet } from "../.gen/providers/aws/subnet";
import { Vpc } from "../.gen/providers/aws/vpc";
import { AppProps } from "../core";
import { CdktfApp } from "../shared-tf/app";
/**
 * An app that knows how to synthesize constructs into a Terraform configuration
 * for AWS resources.
 */
export declare class App extends CdktfApp {
    /**
     * The test runner for this app.
     */
    protected readonly testRunner: TestRunner;
    private awsRegionProvider?;
    private awsAccountIdProvider?;
    private _vpc?;
    private _codeBucket?;
    /** Subnets shared across app */
    subnets: {
        [key: string]: Subnet;
    };
    constructor(props?: AppProps);
    protected tryNew(fqn: string, scope: Construct, id: string, ...args: any[]): any;
    /**
     * The AWS account ID of the App
     */
    get accountId(): string;
    /**
     * The AWS region of the App
     */
    get region(): string;
    get codeBucket(): S3Bucket;
    /**
     * Returns the VPC for this app. Will create a new VPC if one does not exist.
     */
    get vpc(): Vpc;
}
