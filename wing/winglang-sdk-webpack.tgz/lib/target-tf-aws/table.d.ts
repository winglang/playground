import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
/**
 * AWS implementation of `cloud.Table`.
 *
 * @inflight `@winglang/sdk.cloud.ITableClient`
 */
export declare class Table extends cloud.Table {
    private readonly table;
    constructor(scope: Construct, id: string, props?: cloud.TableProps);
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
    private primaryKeyEnvName;
    private columnsEnvName;
}
