import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
/**
 * AWS implementation of `cloud.Secret`
 *
 * @inflight `@winglang/sdk.cloud.ISecretClient`
 */
export declare class Secret extends cloud.Secret {
    private readonly secret;
    constructor(scope: Construct, id: string, props?: cloud.SecretProps);
    /**
     * Secret's arn
     */
    get arn(): string;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
}
