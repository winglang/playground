import { Construct } from "constructs";
import { LambdaPermission } from "../.gen/providers/aws/lambda-permission";
import * as cloud from "../cloud";
import * as core from "../core";
import { PolicyStatement } from "../shared-aws";
import { IInflightHost, Resource } from "../std";
/**
 * Function network configuration
 * used to hold data on subnets and security groups
 * that should be used when a function is deployed within a VPC.
 */
export interface FunctionNetworkConfig {
    /** list of subnets to attach on function */
    readonly subnetIds: string[];
    /** list of security groups to place function in */
    readonly securityGroupIds: string[];
}
/**
 * options for granting invoke permissions to the current function
 */
export interface FunctionPermissionsOptions {
    /**
     * used for keeping function's versioning.
     */
    readonly qualifier?: string;
}
/**
 * AWS implementation of `cloud.Function`.
 *
 * @inflight `@winglang/sdk.cloud.IFunctionClient`
 */
export declare class Function extends cloud.Function {
    private readonly function;
    private readonly role;
    private policyStatements?;
    private subnets?;
    private securityGroups?;
    /**
     * Unqualified Function ARN
     * @returns Unqualified ARN of the function
     */
    readonly arn: string;
    /**
     * Qualified Function ARN
     * @returns Qualified ARN of the function
     */
    readonly qualifiedArn: string;
    /** Function INVOKE_ARN */
    readonly invokeArn: string;
    /** Permissions  */
    permissions: LambdaPermission;
    constructor(scope: Construct, id: string, inflight: cloud.IFunctionHandler, props?: cloud.FunctionProps);
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    /**
     * Add VPC configurations to lambda function
     */
    addNetworkConfig(vpcConfig: FunctionNetworkConfig): void;
    /**
     * Add a policy statement to the Lambda role.
     */
    addPolicyStatements(...statements: PolicyStatement[]): void;
    /**
     * Grants the given identity permissions to invoke this function.
     * @param principal The AWS principal to grant invoke permissions to (e.g. "s3.amazonaws.com", "events.amazonaws.com", "sns.amazonaws.com")
     */
    addPermissionToInvoke(source: Resource, principal: string, sourceArn: string, options?: FunctionPermissionsOptions): void;
    /** @internal */
    get _functionName(): string;
    private envName;
}
