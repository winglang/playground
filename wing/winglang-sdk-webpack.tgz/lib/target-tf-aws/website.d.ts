import { Construct } from "constructs";
import { core } from "..";
import * as cloud from "../cloud";
import { Json } from "../std";
/**
 * AWS implementation of `cloud.Website`.
 *
 * @inflight `@winglang/sdk.cloud.IWebsiteClient`
 */
export declare class Website extends cloud.Website {
    private readonly bucket;
    private readonly _url;
    constructor(scope: Construct, id: string, props: cloud.WebsiteProps);
    get url(): string;
    addJson(path: string, data: Json): string;
    private uploadFile;
    private uploadFiles;
    private formatPath;
    /** @internal */
    _toInflight(): core.Code;
}
