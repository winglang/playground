import { Construct } from "constructs";
import * as cloud from "../cloud";
import { Code } from "../core/inflight";
import { IInflightHost } from "../std";
/**
 * AWS Implementation of `cloud.Api`.
 */
export declare class Api extends cloud.Api {
    private readonly api;
    constructor(scope: Construct, id: string, props?: cloud.ApiProps);
    get url(): string;
    /**
     * Add a inflight to handle GET requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    get(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiGetProps): void;
    /**
     * Add a inflight to handle POST requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    post(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiPostProps): void;
    /**
     * Add a inflight to handle PUT requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    put(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiPutProps): void;
    /**
     * Add a inflight to handle DELETE requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    delete(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiDeleteProps): void;
    /**
     * Add a inflight to handle PATCH requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    patch(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiPatchProps): void;
    /**
     * Add a inflight to handle OPTIONS requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    options(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiOptionsProps): void;
    /**
     * Add a inflight to handle HEAD requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    head(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiHeadProps): void;
    /**
     * Add a inflight to handle CONNECT requests to a path.
     * @param path path to add
     * @param inflight Inflight to handle request
     * @param props Additional props
     */
    connect(path: string, inflight: cloud.IApiEndpointHandler, props?: cloud.ApiConnectProps): void;
    /**
     * Add a inflight handler to the stack
     * @param inflight Inflight to add to the API
     * @param props Endpoint props
     * @returns AWS Lambda Function
     */
    private addHandler;
    /**
     * Check if a inflight handler already exists, if not create it.
     * This ensures that we don't create duplicate inflight handlers.
     * @param inflight
     * @returns
     */
    private getExistingOrAddInflightHandler;
    /**
     * Find an existing inflight handler
     * @param inflight Inflight to find
     * @returns
     */
    private findExistingInflightHandler;
    /**
     * Add an inflight handler to the stack
     * @param inflight Inflight to add to the API
     * @returns Inflight handler as a AWS Lambda Function
     */
    private addInflightHandler;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): Code;
    private urlEnvName;
}
