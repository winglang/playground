import { Construct } from "constructs";
import { Code } from "../core";
import * as redis from "../redis";
import { IInflightHost } from "../std";
export declare class Redis extends redis.Redis {
    private readonly clusterId;
    private readonly clusterArn;
    private readonly securityGroup;
    private readonly subnet;
    constructor(scope: Construct, id: string);
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): Code;
    private envName;
}
