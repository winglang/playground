import { ElastiCacheClient } from "@aws-sdk/client-elasticache";
import { RedisClientBase } from "../redis";
export declare class RedisClient extends RedisClientBase {
    private readonly clusterId;
    private connection?;
    private readonly elasticacheClient;
    private connectionUrl?;
    constructor(clusterId: string, connection?: any, elasticacheClient?: ElastiCacheClient);
    /**
     * The Redis cluster endpoint is not available to inject from the cdktf resource,
     * therefore we need to query the AWS API to get it. This is a helper function that will
     * use the cluster id to get the endpoint.
     *
     * @returns The Redis cluster endpoint
     */
    private getEndpoint;
    rawClient(): Promise<any>;
    url(): Promise<string>;
}
