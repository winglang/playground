import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * AWS implementation of `cloud.Schedule`.
 *
 * @inflight `@winglang/sdk.cloud.IScheduleClient`
 */
export declare class Schedule extends cloud.Schedule {
    private readonly scheduleExpression;
    private readonly rule;
    constructor(scope: Construct, id: string, props?: cloud.ScheduleProps);
    onTick(inflight: cloud.IScheduleOnTickHandler, props?: cloud.ScheduleOnTickProps): cloud.Function;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
}
