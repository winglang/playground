import { ITestRunnerClient, TestResult } from "../cloud";
export declare class TestRunnerClient implements ITestRunnerClient {
    private readonly tests;
    constructor(tests: string);
    listTests(): Promise<string[]>;
    runTest(path: string): Promise<TestResult>;
}
