import { Construct } from "constructs";
import { SnsTopicPolicy } from "../.gen/providers/aws/sns-topic-policy";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost, Resource } from "../std";
/**
 * AWS Implementation of `cloud.Topic`.
 *
 * @inflight `@winglang/sdk.cloud.ITopicClient`
 */
export declare class Topic extends cloud.Topic {
    private readonly topic;
    /**
     * topic's publishing permissions. can be use as a dependency of another resource.
     * (the one that got the permissions to publish)
     * */
    permissions: SnsTopicPolicy;
    constructor(scope: Construct, id: string, props?: cloud.TopicProps);
    /**
     * topic's arn
     */
    get arn(): string;
    onMessage(inflight: cloud.ITopicOnMessageHandler, props?: cloud.TopicOnMessageProps): cloud.Function;
    /**
     * Grants the given identity permissions to publish this topic.
     * @param source the resource that will publish to the topic
     * @param principal The AWS principal to grant publish permissions to (e.g. "s3.amazonaws.com", "events.amazonaws.com", "sns.amazonaws.com")
     * @param sourceArn source arn
     */
    addPermissionToPublish(source: Resource, principal: string, sourceArn: string): void;
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
}
