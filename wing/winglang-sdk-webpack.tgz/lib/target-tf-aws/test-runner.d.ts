import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
import { IInflightHost } from "../std";
/**
 * AWS implementation of `cloud.TestRunner`.
 *
 * @inflight `@winglang/sdk.cloud.ITestRunnerClient`
 */
export declare class TestRunner extends cloud.TestRunner {
    constructor(scope: Construct, id: string, props?: cloud.TestRunnerProps);
    /** @internal */
    _bind(host: IInflightHost, ops: string[]): void;
    /** @internal */
    _preSynthesize(): void;
    private getTestFunctionArns;
    /** @internal */
    _toInflight(): core.Code;
    private envTestFunctionArns;
}
