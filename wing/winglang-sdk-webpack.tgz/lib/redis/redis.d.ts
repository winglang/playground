import { Construct } from "constructs";
import { Resource } from "../std";
/**
 * Global identifier for `Bucket`.
 */
export declare const REDIS_FQN: string;
/**
 * Represents a cloud redis db.
 *
 * @inflight `@winglang/sdk.redis.IRedisClient`
 */
export declare abstract class Redis extends Resource {
    /**
     * Create a new redis.
     * @internal
     */
    static _newRedis(scope: Construct, id: string): Redis;
    constructor(scope: Construct, id: string);
}
/**
 * Inflight interface for `Redis`.
 */
export interface IRedisClient {
    /**
     * Get raw redis client (currently IoRedis).
     * @inflight
     */
    rawClient(): Promise<any>;
    /**
     * Get url of redis server.
     * @inflight
     */
    url(): Promise<string>;
    /**
     * Set key value pair.
     *
     * @param key the key to set
     * @param value the value to store at given key
     * @inflight
     */
    set(key: string, value: string): Promise<void>;
    /**
     * Get value at given key.
     * @param key the key to get
     * @inflight
     */
    get(key: string): Promise<string | undefined>;
    /**
     * Sets the specified field to respective value in the hash stored at key
     *
     * @param key key to set
     * @param field field in key to set
     * @param value value to set at field in key
     * @inflight
     */
    hset(key: string, field: string, value: string): Promise<number>;
    /**
     * Returns the value associated with field in the hash stored at key
     *
     * @param key the key
     * @param field the field at given key
     * @inflight
     */
    hget(key: string, field: string): Promise<string | undefined>;
    /**
     * Add the specified members to the set stored at key
     * @param key the key
     * @param value the value to add to the set at given key
     * @inflight
     */
    sadd(key: string, value: string): Promise<number>;
    /**
     * Returns all the members of the set value stored at key
     *
     * @param key the key
     * @inflight
     */
    smembers(key: string): Promise<string[]>;
    /**
     * Removes the specified key
     *
     * @param key the key
     * @inflight
     */
    del(key: string): Promise<number>;
}
/**
 * List of inflight operations available for `Redis`.
 * @internal
 */
export declare enum RedisInflightMethods {
    /** `Redis.rawClient` */
    RAW_CLIENT = "rawClient",
    /** `Redis.url` */
    URL = "url",
    /** `Redis.set` */
    SET = "set",
    /** `Redis.get` */
    GET = "get",
    /** `Redis.hset` */
    HSET = "hset",
    /** `Redis.hget` */
    HGET = "hget",
    /** `Redis.sadd` */
    SADD = "sadd",
    /** `Redis.smembers` */
    SMEMBERS = "smembers",
    /** `Redis.del` */
    DEL = "del"
}
/**
 * Base class for `Redis` Client.
 */
export declare abstract class RedisClientBase implements IRedisClient {
    abstract rawClient(): Promise<any>;
    abstract url(): Promise<string>;
    set(key: string, value: string): Promise<void>;
    get(key: string): Promise<string | undefined>;
    hset(key: string, field: string, value: string): Promise<number>;
    hget(key: string, field: string): Promise<string | undefined>;
    sadd(key: string, value: string): Promise<number>;
    smembers(key: string): Promise<string[]>;
    del(key: string): Promise<number>;
}
