import { ServiceAttributes, ServiceSchema } from "./schema-resources";
import { IServiceClient } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing";
export declare class Service implements IServiceClient, ISimulatorResourceInstance {
    private readonly context;
    private readonly onStartHandler;
    private readonly onStopHandler?;
    private readonly autoStart;
    private running;
    constructor(props: ServiceSchema["props"], context: ISimulatorContext);
    init(): Promise<ServiceAttributes>;
    cleanup(): Promise<void>;
    start(): Promise<void>;
    stop(): Promise<void>;
}
