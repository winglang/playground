"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Secret = void 0;
const fs = __importStar(require("fs"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
const schema_resources_1 = require("./schema-resources");
const cloud_1 = require("../cloud");
class Secret {
    constructor(props, context) {
        this.context = context;
        this.secretsFile = path.join(os.homedir(), ".wing", "secrets.json");
        if (!fs.existsSync(this.secretsFile)) {
            throw new Error(`No secrets file found at ${this.secretsFile} while looking for secret ${props.name}`);
        }
        this.name = props.name;
    }
    async init() {
        return {};
    }
    async cleanup() { }
    async value() {
        this.context.addTrace({
            data: {
                message: "Get value",
            },
            sourcePath: this.context.resourcePath,
            sourceType: schema_resources_1.SECRET_TYPE,
            type: cloud_1.TraceType.RESOURCE,
            timestamp: new Date().toISOString(),
        });
        const secrets = JSON.parse(fs.readFileSync(this.secretsFile, "utf-8"));
        if (!secrets[this.name]) {
            throw new Error(`No secret value for secret ${this.name}`);
        }
        return secrets[this.name];
    }
    async valueJson() {
        return JSON.parse(await this.value());
    }
}
exports.Secret = Secret;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VjcmV0LmluZmxpZ2h0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3RhcmdldC1zaW0vc2VjcmV0LmluZmxpZ2h0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdUNBQXlCO0FBQ3pCLHVDQUF5QjtBQUN6QiwyQ0FBNkI7QUFDN0IseURBSTRCO0FBQzVCLG9DQUFvRDtBQU9wRCxNQUFhLE1BQU07SUFLakIsWUFBWSxLQUE0QixFQUFFLE9BQTBCO1FBQ2xFLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBRXZCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUUsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNwQyxNQUFNLElBQUksS0FBSyxDQUNiLDRCQUE0QixJQUFJLENBQUMsV0FBVyw2QkFBNkIsS0FBSyxDQUFDLElBQUksRUFBRSxDQUN0RixDQUFDO1NBQ0g7UUFFRCxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7SUFDekIsQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJO1FBQ2YsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0lBRU0sS0FBSyxDQUFDLE9BQU8sS0FBbUIsQ0FBQztJQUVqQyxLQUFLLENBQUMsS0FBSztRQUNoQixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztZQUNwQixJQUFJLEVBQUU7Z0JBQ0osT0FBTyxFQUFFLFdBQVc7YUFDckI7WUFDRCxVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO1lBQ3JDLFVBQVUsRUFBRSw4QkFBVztZQUN2QixJQUFJLEVBQUUsaUJBQVMsQ0FBQyxRQUFRO1lBQ3hCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtTQUNwQyxDQUFDLENBQUM7UUFFSCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRXZFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3ZCLE1BQU0sSUFBSSxLQUFLLENBQUMsOEJBQThCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1NBQzVEO1FBRUQsT0FBTyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFFTSxLQUFLLENBQUMsU0FBUztRQUNwQixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUN4QyxDQUFDO0NBQ0Y7QUEvQ0Qsd0JBK0NDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgZnMgZnJvbSBcImZzXCI7XG5pbXBvcnQgKiBhcyBvcyBmcm9tIFwib3NcIjtcbmltcG9ydCAqIGFzIHBhdGggZnJvbSBcInBhdGhcIjtcbmltcG9ydCB7XG4gIFNFQ1JFVF9UWVBFLFxuICBTZWNyZXRBdHRyaWJ1dGVzLFxuICBTZWNyZXRTY2hlbWEsXG59IGZyb20gXCIuL3NjaGVtYS1yZXNvdXJjZXNcIjtcbmltcG9ydCB7IElTZWNyZXRDbGllbnQsIFRyYWNlVHlwZSB9IGZyb20gXCIuLi9jbG91ZFwiO1xuaW1wb3J0IHsgSnNvbiB9IGZyb20gXCIuLi9zdGRcIjtcbmltcG9ydCB7XG4gIElTaW11bGF0b3JDb250ZXh0LFxuICBJU2ltdWxhdG9yUmVzb3VyY2VJbnN0YW5jZSxcbn0gZnJvbSBcIi4uL3Rlc3Rpbmcvc2ltdWxhdG9yXCI7XG5cbmV4cG9ydCBjbGFzcyBTZWNyZXQgaW1wbGVtZW50cyBJU2VjcmV0Q2xpZW50LCBJU2ltdWxhdG9yUmVzb3VyY2VJbnN0YW5jZSB7XG4gIHByaXZhdGUgcmVhZG9ubHkgY29udGV4dDogSVNpbXVsYXRvckNvbnRleHQ7XG4gIHByaXZhdGUgcmVhZG9ubHkgc2VjcmV0c0ZpbGU6IHN0cmluZztcbiAgcHJpdmF0ZSByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IocHJvcHM6IFNlY3JldFNjaGVtYVtcInByb3BzXCJdLCBjb250ZXh0OiBJU2ltdWxhdG9yQ29udGV4dCkge1xuICAgIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG5cbiAgICB0aGlzLnNlY3JldHNGaWxlID0gcGF0aC5qb2luKG9zLmhvbWVkaXIoKSwgXCIud2luZ1wiLCBcInNlY3JldHMuanNvblwiKTtcbiAgICBpZiAoIWZzLmV4aXN0c1N5bmModGhpcy5zZWNyZXRzRmlsZSkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYE5vIHNlY3JldHMgZmlsZSBmb3VuZCBhdCAke3RoaXMuc2VjcmV0c0ZpbGV9IHdoaWxlIGxvb2tpbmcgZm9yIHNlY3JldCAke3Byb3BzLm5hbWV9YFxuICAgICAgKTtcbiAgICB9XG5cbiAgICB0aGlzLm5hbWUgPSBwcm9wcy5uYW1lO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGluaXQoKTogUHJvbWlzZTxTZWNyZXRBdHRyaWJ1dGVzPiB7XG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGNsZWFudXAoKTogUHJvbWlzZTx2b2lkPiB7fVxuXG4gIHB1YmxpYyBhc3luYyB2YWx1ZSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIHRoaXMuY29udGV4dC5hZGRUcmFjZSh7XG4gICAgICBkYXRhOiB7XG4gICAgICAgIG1lc3NhZ2U6IFwiR2V0IHZhbHVlXCIsXG4gICAgICB9LFxuICAgICAgc291cmNlUGF0aDogdGhpcy5jb250ZXh0LnJlc291cmNlUGF0aCxcbiAgICAgIHNvdXJjZVR5cGU6IFNFQ1JFVF9UWVBFLFxuICAgICAgdHlwZTogVHJhY2VUeXBlLlJFU09VUkNFLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSk7XG5cbiAgICBjb25zdCBzZWNyZXRzID0gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmModGhpcy5zZWNyZXRzRmlsZSwgXCJ1dGYtOFwiKSk7XG5cbiAgICBpZiAoIXNlY3JldHNbdGhpcy5uYW1lXSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBObyBzZWNyZXQgdmFsdWUgZm9yIHNlY3JldCAke3RoaXMubmFtZX1gKTtcbiAgICB9XG5cbiAgICByZXR1cm4gc2VjcmV0c1t0aGlzLm5hbWVdO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIHZhbHVlSnNvbigpOiBQcm9taXNlPEpzb24+IHtcbiAgICByZXR1cm4gSlNPTi5wYXJzZShhd2FpdCB0aGlzLnZhbHVlKCkpO1xuICB9XG59XG4iXX0=