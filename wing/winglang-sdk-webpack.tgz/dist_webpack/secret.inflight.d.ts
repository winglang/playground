import { SecretAttributes, SecretSchema } from "./schema-resources";
import { ISecretClient } from "../cloud";
import { Json } from "../std";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Secret implements ISecretClient, ISimulatorResourceInstance {
    private readonly context;
    private readonly secretsFile;
    private readonly name;
    constructor(props: SecretSchema["props"], context: ISimulatorContext);
    init(): Promise<SecretAttributes>;
    cleanup(): Promise<void>;
    value(): Promise<string>;
    valueJson(): Promise<Json>;
}
