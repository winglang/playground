"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Redis = void 0;
const ioredis_1 = __importDefault(require("ioredis"));
const uuid_1 = require("uuid");
const redis_1 = require("../redis");
const misc_1 = require("../utils/misc");
class Redis extends redis_1.RedisClientBase {
    constructor(_props, context) {
        super();
        this.WING_REDIS_IMAGE = process.env.WING_REDIS_IMAGE ??
            // Redis version 7.0.9
            "redis@sha256:e50c7e23f79ae81351beacb20e004720d4bed657415e68c2b1a2b5557c075ce0";
        this.connection_url = undefined;
        this.context = context;
        this.container_name = `wing-sim-redis-${this.context.resourcePath.replace(/\//g, ".")}-${(0, uuid_1.v4)()}`;
    }
    async init() {
        try {
            // Pull docker image
            await (0, misc_1.runCommand)("docker", ["pull", `${this.WING_REDIS_IMAGE}`]);
            // Run the container and allow docker to assign a host port dynamically
            await (0, misc_1.runCommand)("docker", [
                "run",
                "--detach",
                "--name",
                `${this.container_name}`,
                "-p",
                "6379",
                `${this.WING_REDIS_IMAGE}`,
            ]);
            // Inspect the container to get the host port
            const out = await (0, misc_1.runCommand)("docker", [
                "inspect",
                `${this.container_name}`,
            ]);
            const hostPort = JSON.parse(out)[0].NetworkSettings.Ports["6379/tcp"][0].HostPort;
            // redis url based on host port
            this.connection_url = `redis://0.0.0.0:${hostPort}`;
            return {};
        }
        catch (e) {
            throw Error(`Error setting up Redis resource simulation (${e})
      - Make sure you have docker installed and running`);
        }
    }
    async cleanup() {
        // disconnect from the redis server
        await this.connection?.disconnect();
        // stop the redis container
        await (0, misc_1.runCommand)("docker", ["rm", "-f", `${this.container_name}`]);
    }
    async rawClient() {
        if (this.connection) {
            return this.connection;
        }
        if (this.connection_url) {
            this.connection = new ioredis_1.default(this.connection_url);
            return this.connection;
        }
        throw new Error("Redis server not initialized");
    }
    async url() {
        if (this.connection_url != undefined) {
            return this.connection_url;
        }
        else {
            throw new Error("Redis server not initialized");
        }
    }
}
exports.Redis = Redis;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVkaXMuaW5mbGlnaHQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdGFyZ2V0LXNpbS9yZWRpcy5pbmZsaWdodC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxzREFBOEI7QUFDOUIsK0JBQW9DO0FBRXBDLG9DQUEyQztBQUszQyx3Q0FBMkM7QUFFM0MsTUFBYSxLQUNYLFNBQVEsdUJBQWU7SUFhdkIsWUFBbUIsTUFBNEIsRUFBRSxPQUEwQjtRQUN6RSxLQUFLLEVBQUUsQ0FBQztRQVZPLHFCQUFnQixHQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQjtZQUM1QixzQkFBc0I7WUFDdEIsK0VBQStFLENBQUM7UUFHMUUsbUJBQWMsR0FBWSxTQUFTLENBQUM7UUFLMUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxrQkFBa0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUN2RSxLQUFLLEVBQ0wsR0FBRyxDQUNKLElBQUksSUFBQSxTQUFNLEdBQUUsRUFBRSxDQUFDO0lBQ2xCLENBQUM7SUFFTSxLQUFLLENBQUMsSUFBSTtRQUNmLElBQUk7WUFDRixvQkFBb0I7WUFDcEIsTUFBTSxJQUFBLGlCQUFVLEVBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRWpFLHVFQUF1RTtZQUN2RSxNQUFNLElBQUEsaUJBQVUsRUFBQyxRQUFRLEVBQUU7Z0JBQ3pCLEtBQUs7Z0JBQ0wsVUFBVTtnQkFDVixRQUFRO2dCQUNSLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRTtnQkFDeEIsSUFBSTtnQkFDSixNQUFNO2dCQUNOLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFO2FBQzNCLENBQUMsQ0FBQztZQUVILDZDQUE2QztZQUM3QyxNQUFNLEdBQUcsR0FBRyxNQUFNLElBQUEsaUJBQVUsRUFBQyxRQUFRLEVBQUU7Z0JBQ3JDLFNBQVM7Z0JBQ1QsR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFO2FBQ3pCLENBQUMsQ0FBQztZQUNILE1BQU0sUUFBUSxHQUNaLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7WUFFbkUsK0JBQStCO1lBQy9CLElBQUksQ0FBQyxjQUFjLEdBQUcsbUJBQW1CLFFBQVEsRUFBRSxDQUFDO1lBQ3BELE9BQU8sRUFBRSxDQUFDO1NBQ1g7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNWLE1BQU0sS0FBSyxDQUFDLCtDQUErQyxDQUFDO3dEQUNWLENBQUMsQ0FBQztTQUNyRDtJQUNILENBQUM7SUFFTSxLQUFLLENBQUMsT0FBTztRQUNsQixtQ0FBbUM7UUFDbkMsTUFBTSxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxDQUFDO1FBQ3BDLDJCQUEyQjtRQUMzQixNQUFNLElBQUEsaUJBQVUsRUFBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRU0sS0FBSyxDQUFDLFNBQVM7UUFDcEIsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ25CLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztTQUN4QjtRQUVELElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksaUJBQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDbkQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO1NBQ3hCO1FBRUQsTUFBTSxJQUFJLEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFTSxLQUFLLENBQUMsR0FBRztRQUNkLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLEVBQUU7WUFDcEMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDO1NBQzVCO2FBQU07WUFDTCxNQUFNLElBQUksS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUM7U0FDakQ7SUFDSCxDQUFDO0NBQ0Y7QUFuRkQsc0JBbUZDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IElvUmVkaXMgZnJvbSBcImlvcmVkaXNcIjtcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gXCJ1dWlkXCI7XG5pbXBvcnQgeyBSZWRpc0F0dHJpYnV0ZXMsIFJlZGlzU2NoZW1hIH0gZnJvbSBcIi4vc2NoZW1hLXJlc291cmNlc1wiO1xuaW1wb3J0IHsgUmVkaXNDbGllbnRCYXNlIH0gZnJvbSBcIi4uL3JlZGlzXCI7XG5pbXBvcnQge1xuICBJU2ltdWxhdG9yQ29udGV4dCxcbiAgSVNpbXVsYXRvclJlc291cmNlSW5zdGFuY2UsXG59IGZyb20gXCIuLi90ZXN0aW5nL3NpbXVsYXRvclwiO1xuaW1wb3J0IHsgcnVuQ29tbWFuZCB9IGZyb20gXCIuLi91dGlscy9taXNjXCI7XG5cbmV4cG9ydCBjbGFzcyBSZWRpc1xuICBleHRlbmRzIFJlZGlzQ2xpZW50QmFzZVxuICBpbXBsZW1lbnRzIElTaW11bGF0b3JSZXNvdXJjZUluc3RhbmNlXG57XG4gIHByaXZhdGUgY29udGFpbmVyX25hbWU6IHN0cmluZztcbiAgcHJpdmF0ZSByZWFkb25seSBXSU5HX1JFRElTX0lNQUdFID1cbiAgICBwcm9jZXNzLmVudi5XSU5HX1JFRElTX0lNQUdFID8/XG4gICAgLy8gUmVkaXMgdmVyc2lvbiA3LjAuOVxuICAgIFwicmVkaXNAc2hhMjU2OmU1MGM3ZTIzZjc5YWU4MTM1MWJlYWNiMjBlMDA0NzIwZDRiZWQ2NTc0MTVlNjhjMmIxYTJiNTU1N2MwNzVjZTBcIjtcbiAgcHJpdmF0ZSByZWFkb25seSBjb250ZXh0OiBJU2ltdWxhdG9yQ29udGV4dDtcblxuICBwcml2YXRlIGNvbm5lY3Rpb25fdXJsPzogc3RyaW5nID0gdW5kZWZpbmVkO1xuICBwcml2YXRlIGNvbm5lY3Rpb24/OiBhbnk7XG5cbiAgcHVibGljIGNvbnN0cnVjdG9yKF9wcm9wczogUmVkaXNTY2hlbWFbXCJwcm9wc1wiXSwgY29udGV4dDogSVNpbXVsYXRvckNvbnRleHQpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG4gICAgdGhpcy5jb250YWluZXJfbmFtZSA9IGB3aW5nLXNpbS1yZWRpcy0ke3RoaXMuY29udGV4dC5yZXNvdXJjZVBhdGgucmVwbGFjZShcbiAgICAgIC9cXC8vZyxcbiAgICAgIFwiLlwiXG4gICAgKX0tJHt1dWlkdjQoKX1gO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGluaXQoKTogUHJvbWlzZTxSZWRpc0F0dHJpYnV0ZXM+IHtcbiAgICB0cnkge1xuICAgICAgLy8gUHVsbCBkb2NrZXIgaW1hZ2VcbiAgICAgIGF3YWl0IHJ1bkNvbW1hbmQoXCJkb2NrZXJcIiwgW1wicHVsbFwiLCBgJHt0aGlzLldJTkdfUkVESVNfSU1BR0V9YF0pO1xuXG4gICAgICAvLyBSdW4gdGhlIGNvbnRhaW5lciBhbmQgYWxsb3cgZG9ja2VyIHRvIGFzc2lnbiBhIGhvc3QgcG9ydCBkeW5hbWljYWxseVxuICAgICAgYXdhaXQgcnVuQ29tbWFuZChcImRvY2tlclwiLCBbXG4gICAgICAgIFwicnVuXCIsXG4gICAgICAgIFwiLS1kZXRhY2hcIixcbiAgICAgICAgXCItLW5hbWVcIixcbiAgICAgICAgYCR7dGhpcy5jb250YWluZXJfbmFtZX1gLFxuICAgICAgICBcIi1wXCIsXG4gICAgICAgIFwiNjM3OVwiLFxuICAgICAgICBgJHt0aGlzLldJTkdfUkVESVNfSU1BR0V9YCxcbiAgICAgIF0pO1xuXG4gICAgICAvLyBJbnNwZWN0IHRoZSBjb250YWluZXIgdG8gZ2V0IHRoZSBob3N0IHBvcnRcbiAgICAgIGNvbnN0IG91dCA9IGF3YWl0IHJ1bkNvbW1hbmQoXCJkb2NrZXJcIiwgW1xuICAgICAgICBcImluc3BlY3RcIixcbiAgICAgICAgYCR7dGhpcy5jb250YWluZXJfbmFtZX1gLFxuICAgICAgXSk7XG4gICAgICBjb25zdCBob3N0UG9ydCA9XG4gICAgICAgIEpTT04ucGFyc2Uob3V0KVswXS5OZXR3b3JrU2V0dGluZ3MuUG9ydHNbXCI2Mzc5L3RjcFwiXVswXS5Ib3N0UG9ydDtcblxuICAgICAgLy8gcmVkaXMgdXJsIGJhc2VkIG9uIGhvc3QgcG9ydFxuICAgICAgdGhpcy5jb25uZWN0aW9uX3VybCA9IGByZWRpczovLzAuMC4wLjA6JHtob3N0UG9ydH1gO1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHRocm93IEVycm9yKGBFcnJvciBzZXR0aW5nIHVwIFJlZGlzIHJlc291cmNlIHNpbXVsYXRpb24gKCR7ZX0pXG4gICAgICAtIE1ha2Ugc3VyZSB5b3UgaGF2ZSBkb2NrZXIgaW5zdGFsbGVkIGFuZCBydW5uaW5nYCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGFzeW5jIGNsZWFudXAoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgLy8gZGlzY29ubmVjdCBmcm9tIHRoZSByZWRpcyBzZXJ2ZXJcbiAgICBhd2FpdCB0aGlzLmNvbm5lY3Rpb24/LmRpc2Nvbm5lY3QoKTtcbiAgICAvLyBzdG9wIHRoZSByZWRpcyBjb250YWluZXJcbiAgICBhd2FpdCBydW5Db21tYW5kKFwiZG9ja2VyXCIsIFtcInJtXCIsIFwiLWZcIiwgYCR7dGhpcy5jb250YWluZXJfbmFtZX1gXSk7XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgcmF3Q2xpZW50KCk6IFByb21pc2U8YW55PiB7XG4gICAgaWYgKHRoaXMuY29ubmVjdGlvbikge1xuICAgICAgcmV0dXJuIHRoaXMuY29ubmVjdGlvbjtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5jb25uZWN0aW9uX3VybCkge1xuICAgICAgdGhpcy5jb25uZWN0aW9uID0gbmV3IElvUmVkaXModGhpcy5jb25uZWN0aW9uX3VybCk7XG4gICAgICByZXR1cm4gdGhpcy5jb25uZWN0aW9uO1xuICAgIH1cblxuICAgIHRocm93IG5ldyBFcnJvcihcIlJlZGlzIHNlcnZlciBub3QgaW5pdGlhbGl6ZWRcIik7XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgdXJsKCk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgaWYgKHRoaXMuY29ubmVjdGlvbl91cmwgIT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gdGhpcy5jb25uZWN0aW9uX3VybDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUmVkaXMgc2VydmVyIG5vdCBpbml0aWFsaXplZFwiKTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==