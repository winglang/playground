"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefaultSimulatorFactory = void 0;
const api_inflight_1 = require("./api.inflight");
const bucket_inflight_1 = require("./bucket.inflight");
const counter_inflight_1 = require("./counter.inflight");
const event_mapping_inflight_1 = require("./event-mapping.inflight");
const function_inflight_1 = require("./function.inflight");
const queue_inflight_1 = require("./queue.inflight");
const redis_inflight_1 = require("./redis.inflight");
const schedule_inflight_1 = require("./schedule.inflight");
const schema_resources_1 = require("./schema-resources");
const secret_inflight_1 = require("./secret.inflight");
const service_inflight_1 = require("./service.inflight");
const table_inflight_1 = require("./table.inflight");
const test_runner_inflight_1 = require("./test-runner.inflight");
const topic_inflight_1 = require("./topic.inflight");
const website_inflight_1 = require("./website.inflight");
class DefaultSimulatorFactory {
    /**
     * Creates a new simulator runtime resource
     * @param type type id
     * @param props resource properties
     * @param context simulator context
     * @returns a new instance
     */
    resolve(type, props, context) {
        switch (type) {
            case schema_resources_1.API_TYPE:
                return new api_inflight_1.Api(props, context);
            case schema_resources_1.BUCKET_TYPE:
                return new bucket_inflight_1.Bucket(props, context);
            case schema_resources_1.FUNCTION_TYPE:
                return new function_inflight_1.Function(props, context);
            case schema_resources_1.QUEUE_TYPE:
                return new queue_inflight_1.Queue(props, context);
            case schema_resources_1.COUNTER_TYPE:
                return new counter_inflight_1.Counter(props, context);
            case schema_resources_1.TABLE_TYPE:
                return new table_inflight_1.Table(props, context);
            case schema_resources_1.TOPIC_TYPE:
                return new topic_inflight_1.Topic(props, context);
            case schema_resources_1.TEST_RUNNER_TYPE:
                return new test_runner_inflight_1.TestRunnerClient(props, context);
            case schema_resources_1.REDIS_TYPE:
                return new redis_inflight_1.Redis(props, context);
            case schema_resources_1.WEBSITE_TYPE:
                return new website_inflight_1.Website(props, context);
            case schema_resources_1.SECRET_TYPE:
                return new secret_inflight_1.Secret(props, context);
            case schema_resources_1.EVENT_MAPPING_TYPE:
                return new event_mapping_inflight_1.EventMapping(props, context);
            case schema_resources_1.SCHEDULE_TYPE:
                return new schedule_inflight_1.Schedule(props, context);
            case schema_resources_1.SERVICE_TYPE:
                return new service_inflight_1.Service(props, context);
            default:
                throw new Error(`Type ${type} not implemented by the simulator.`);
        }
    }
}
exports.DefaultSimulatorFactory = DefaultSimulatorFactory;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmFjdG9yeS5pbmZsaWdodC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy90YXJnZXQtc2ltL2ZhY3RvcnkuaW5mbGlnaHQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsaURBQXFDO0FBQ3JDLHVEQUEyQztBQUMzQyx5REFBNkM7QUFDN0MscUVBQXdEO0FBQ3hELDJEQUErQztBQUMvQyxxREFBeUM7QUFDekMscURBQXlDO0FBQ3pDLDJEQUErQztBQUMvQyx5REFlNEI7QUFDNUIsdURBQTJDO0FBQzNDLHlEQUE2QztBQUM3QyxxREFBeUM7QUFDekMsaUVBQTBEO0FBQzFELHFEQUF5QztBQUN6Qyx5REFBNkM7QUFPN0MsTUFBYSx1QkFBdUI7SUFDbEM7Ozs7OztPQU1HO0lBQ0ksT0FBTyxDQUNaLElBQVksRUFDWixLQUFVLEVBQ1YsT0FBMEI7UUFFMUIsUUFBUSxJQUFJLEVBQUU7WUFDWixLQUFLLDJCQUFRO2dCQUNYLE9BQU8sSUFBSSxrQkFBRyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNqQyxLQUFLLDhCQUFXO2dCQUNkLE9BQU8sSUFBSSx3QkFBTSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNwQyxLQUFLLGdDQUFhO2dCQUNoQixPQUFPLElBQUksNEJBQVEsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDdEMsS0FBSyw2QkFBVTtnQkFDYixPQUFPLElBQUksc0JBQUssQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDbkMsS0FBSywrQkFBWTtnQkFDZixPQUFPLElBQUksMEJBQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDckMsS0FBSyw2QkFBVTtnQkFDYixPQUFPLElBQUksc0JBQUssQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDbkMsS0FBSyw2QkFBVTtnQkFDYixPQUFPLElBQUksc0JBQUssQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDbkMsS0FBSyxtQ0FBZ0I7Z0JBQ25CLE9BQU8sSUFBSSx1Q0FBZ0IsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDOUMsS0FBSyw2QkFBVTtnQkFDYixPQUFPLElBQUksc0JBQUssQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDbkMsS0FBSywrQkFBWTtnQkFDZixPQUFPLElBQUksMEJBQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDckMsS0FBSyw4QkFBVztnQkFDZCxPQUFPLElBQUksd0JBQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDcEMsS0FBSyxxQ0FBa0I7Z0JBQ3JCLE9BQU8sSUFBSSxxQ0FBWSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMxQyxLQUFLLGdDQUFhO2dCQUNoQixPQUFPLElBQUksNEJBQVEsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDdEMsS0FBSywrQkFBWTtnQkFDZixPQUFPLElBQUksMEJBQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDckM7Z0JBQ0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxRQUFRLElBQUksb0NBQW9DLENBQUMsQ0FBQztTQUNyRTtJQUNILENBQUM7Q0FDRjtBQTlDRCwwREE4Q0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcGkgfSBmcm9tIFwiLi9hcGkuaW5mbGlnaHRcIjtcbmltcG9ydCB7IEJ1Y2tldCB9IGZyb20gXCIuL2J1Y2tldC5pbmZsaWdodFwiO1xuaW1wb3J0IHsgQ291bnRlciB9IGZyb20gXCIuL2NvdW50ZXIuaW5mbGlnaHRcIjtcbmltcG9ydCB7IEV2ZW50TWFwcGluZyB9IGZyb20gXCIuL2V2ZW50LW1hcHBpbmcuaW5mbGlnaHRcIjtcbmltcG9ydCB7IEZ1bmN0aW9uIH0gZnJvbSBcIi4vZnVuY3Rpb24uaW5mbGlnaHRcIjtcbmltcG9ydCB7IFF1ZXVlIH0gZnJvbSBcIi4vcXVldWUuaW5mbGlnaHRcIjtcbmltcG9ydCB7IFJlZGlzIH0gZnJvbSBcIi4vcmVkaXMuaW5mbGlnaHRcIjtcbmltcG9ydCB7IFNjaGVkdWxlIH0gZnJvbSBcIi4vc2NoZWR1bGUuaW5mbGlnaHRcIjtcbmltcG9ydCB7XG4gIEFQSV9UWVBFLFxuICBCVUNLRVRfVFlQRSxcbiAgQ09VTlRFUl9UWVBFLFxuICBGVU5DVElPTl9UWVBFLFxuICBRVUVVRV9UWVBFLFxuICBUQUJMRV9UWVBFLFxuICBURVNUX1JVTk5FUl9UWVBFLFxuICBUT1BJQ19UWVBFLFxuICBSRURJU19UWVBFLFxuICBXRUJTSVRFX1RZUEUsXG4gIFNFQ1JFVF9UWVBFLFxuICBFVkVOVF9NQVBQSU5HX1RZUEUsXG4gIFNDSEVEVUxFX1RZUEUsXG4gIFNFUlZJQ0VfVFlQRSxcbn0gZnJvbSBcIi4vc2NoZW1hLXJlc291cmNlc1wiO1xuaW1wb3J0IHsgU2VjcmV0IH0gZnJvbSBcIi4vc2VjcmV0LmluZmxpZ2h0XCI7XG5pbXBvcnQgeyBTZXJ2aWNlIH0gZnJvbSBcIi4vc2VydmljZS5pbmZsaWdodFwiO1xuaW1wb3J0IHsgVGFibGUgfSBmcm9tIFwiLi90YWJsZS5pbmZsaWdodFwiO1xuaW1wb3J0IHsgVGVzdFJ1bm5lckNsaWVudCB9IGZyb20gXCIuL3Rlc3QtcnVubmVyLmluZmxpZ2h0XCI7XG5pbXBvcnQgeyBUb3BpYyB9IGZyb20gXCIuL3RvcGljLmluZmxpZ2h0XCI7XG5pbXBvcnQgeyBXZWJzaXRlIH0gZnJvbSBcIi4vd2Vic2l0ZS5pbmZsaWdodFwiO1xuaW1wb3J0IHtcbiAgSVNpbXVsYXRvckZhY3RvcnksXG4gIElTaW11bGF0b3JDb250ZXh0LFxuICBJU2ltdWxhdG9yUmVzb3VyY2VJbnN0YW5jZSxcbn0gZnJvbSBcIi4uL3Rlc3Rpbmcvc2ltdWxhdG9yXCI7XG5cbmV4cG9ydCBjbGFzcyBEZWZhdWx0U2ltdWxhdG9yRmFjdG9yeSBpbXBsZW1lbnRzIElTaW11bGF0b3JGYWN0b3J5IHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgc2ltdWxhdG9yIHJ1bnRpbWUgcmVzb3VyY2VcbiAgICogQHBhcmFtIHR5cGUgdHlwZSBpZFxuICAgKiBAcGFyYW0gcHJvcHMgcmVzb3VyY2UgcHJvcGVydGllc1xuICAgKiBAcGFyYW0gY29udGV4dCBzaW11bGF0b3IgY29udGV4dFxuICAgKiBAcmV0dXJucyBhIG5ldyBpbnN0YW5jZVxuICAgKi9cbiAgcHVibGljIHJlc29sdmUoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHByb3BzOiBhbnksXG4gICAgY29udGV4dDogSVNpbXVsYXRvckNvbnRleHRcbiAgKTogSVNpbXVsYXRvclJlc291cmNlSW5zdGFuY2Uge1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSBBUElfVFlQRTpcbiAgICAgICAgcmV0dXJuIG5ldyBBcGkocHJvcHMsIGNvbnRleHQpO1xuICAgICAgY2FzZSBCVUNLRVRfVFlQRTpcbiAgICAgICAgcmV0dXJuIG5ldyBCdWNrZXQocHJvcHMsIGNvbnRleHQpO1xuICAgICAgY2FzZSBGVU5DVElPTl9UWVBFOlxuICAgICAgICByZXR1cm4gbmV3IEZ1bmN0aW9uKHByb3BzLCBjb250ZXh0KTtcbiAgICAgIGNhc2UgUVVFVUVfVFlQRTpcbiAgICAgICAgcmV0dXJuIG5ldyBRdWV1ZShwcm9wcywgY29udGV4dCk7XG4gICAgICBjYXNlIENPVU5URVJfVFlQRTpcbiAgICAgICAgcmV0dXJuIG5ldyBDb3VudGVyKHByb3BzLCBjb250ZXh0KTtcbiAgICAgIGNhc2UgVEFCTEVfVFlQRTpcbiAgICAgICAgcmV0dXJuIG5ldyBUYWJsZShwcm9wcywgY29udGV4dCk7XG4gICAgICBjYXNlIFRPUElDX1RZUEU6XG4gICAgICAgIHJldHVybiBuZXcgVG9waWMocHJvcHMsIGNvbnRleHQpO1xuICAgICAgY2FzZSBURVNUX1JVTk5FUl9UWVBFOlxuICAgICAgICByZXR1cm4gbmV3IFRlc3RSdW5uZXJDbGllbnQocHJvcHMsIGNvbnRleHQpO1xuICAgICAgY2FzZSBSRURJU19UWVBFOlxuICAgICAgICByZXR1cm4gbmV3IFJlZGlzKHByb3BzLCBjb250ZXh0KTtcbiAgICAgIGNhc2UgV0VCU0lURV9UWVBFOlxuICAgICAgICByZXR1cm4gbmV3IFdlYnNpdGUocHJvcHMsIGNvbnRleHQpO1xuICAgICAgY2FzZSBTRUNSRVRfVFlQRTpcbiAgICAgICAgcmV0dXJuIG5ldyBTZWNyZXQocHJvcHMsIGNvbnRleHQpO1xuICAgICAgY2FzZSBFVkVOVF9NQVBQSU5HX1RZUEU6XG4gICAgICAgIHJldHVybiBuZXcgRXZlbnRNYXBwaW5nKHByb3BzLCBjb250ZXh0KTtcbiAgICAgIGNhc2UgU0NIRURVTEVfVFlQRTpcbiAgICAgICAgcmV0dXJuIG5ldyBTY2hlZHVsZShwcm9wcywgY29udGV4dCk7XG4gICAgICBjYXNlIFNFUlZJQ0VfVFlQRTpcbiAgICAgICAgcmV0dXJuIG5ldyBTZXJ2aWNlKHByb3BzLCBjb250ZXh0KTtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgVHlwZSAke3R5cGV9IG5vdCBpbXBsZW1lbnRlZCBieSB0aGUgc2ltdWxhdG9yLmApO1xuICAgIH1cbiAgfVxufVxuIl19