import { IBucketEventHandlerClient, IFunctionHandlerClient } from "../cloud";
export declare class BucketEventHandlerClient implements IBucketEventHandlerClient {
    private readonly handler;
    constructor({ handler }: {
        handler: IFunctionHandlerClient;
    });
    handle(event: string): Promise<void>;
}
