import { IEventPublisher } from "./event-mapping";
import { ApiAttributes, ApiSchema, EventSubscription } from "./schema-resources";
import { IApiClient } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Api implements IApiClient, ISimulatorResourceInstance, IEventPublisher {
    private readonly routes;
    private readonly context;
    private readonly app;
    private server;
    private url;
    constructor(props: ApiSchema["props"], context: ISimulatorContext);
    addEventSubscription(subscriber: string, subscriptionProps: EventSubscription): Promise<void>;
    private populateRoute;
    init(): Promise<ApiAttributes>;
    cleanup(): Promise<void>;
    private addTrace;
}
