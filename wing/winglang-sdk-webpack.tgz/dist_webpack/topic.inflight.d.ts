import { IEventPublisher } from "./event-mapping";
import { TopicAttributes, TopicSchema, EventSubscription, FunctionHandle } from "./schema-resources";
import { ITopicClient } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Topic implements ITopicClient, ISimulatorResourceInstance, IEventPublisher {
    private readonly subscribers;
    private readonly context;
    constructor(props: TopicSchema["props"], context: ISimulatorContext);
    init(): Promise<TopicAttributes>;
    cleanup(): Promise<void>;
    private publishMessage;
    addEventSubscription(subscriber: FunctionHandle, subscriptionProps: EventSubscription): Promise<void>;
    publish(message: string): Promise<void>;
}
