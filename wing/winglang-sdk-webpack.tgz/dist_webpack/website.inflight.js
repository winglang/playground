"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Website = void 0;
const express_1 = __importDefault(require("express"));
const schema_resources_1 = require("./schema-resources");
const cloud_1 = require("../cloud");
const LOCALHOST_ADDRESS = "127.0.0.1";
class Website {
    constructor(props, context) {
        this.context = context;
        // Set up an express server that handles the routes.
        this.app = (0, express_1.default)();
        // Use static directory
        this.app.use(express_1.default.static(props.staticFilesPath));
        this.initiateJsonRoutes(props.jsonRoutes);
    }
    initiateJsonRoutes(routes) {
        for (const path in routes) {
            this.app.get(`/${path}`, (_, res) => {
                res.json(routes[path]);
            });
        }
    }
    async init() {
        // `server.address()` returns `null` until the server is listening
        // on a port. We use a promise to wait for the server to start
        // listening before returning the URL.
        const addrInfo = await new Promise((resolve, reject) => {
            this.server = this.app.listen(0, LOCALHOST_ADDRESS, () => {
                const addr = this.server?.address();
                if (addr && typeof addr === "object" && addr.port) {
                    resolve(addr);
                }
                else {
                    reject(new Error("No address found"));
                }
            });
        });
        this.url = `http://${addrInfo.address}:${addrInfo.port}`;
        this.addTrace(`Website Server listening on ${this.url}`);
        return {
            url: this.url,
        };
    }
    async cleanup() {
        this.addTrace(`Closing server on ${this.url}`);
        this.server?.close();
    }
    addTrace(message) {
        this.context.addTrace({
            type: cloud_1.TraceType.RESOURCE,
            data: {
                message,
            },
            sourcePath: this.context.resourcePath,
            sourceType: schema_resources_1.WEBSITE_TYPE,
            timestamp: new Date().toISOString(),
        });
    }
}
exports.Website = Website;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2Vic2l0ZS5pbmZsaWdodC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy90YXJnZXQtc2ltL3dlYnNpdGUuaW5mbGlnaHQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsc0RBQThCO0FBQzlCLHlEQUFnRjtBQUNoRixvQ0FBcUQ7QUFPckQsTUFBTSxpQkFBaUIsR0FBRyxXQUFXLENBQUM7QUFFdEMsTUFBYSxPQUFPO0lBTWxCLFlBQVksS0FBNkIsRUFBRSxPQUEwQjtRQUNuRSxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUV2QixvREFBb0Q7UUFDcEQsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFBLGlCQUFPLEdBQUUsQ0FBQztRQUVyQix1QkFBdUI7UUFDdkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRU8sa0JBQWtCLENBQUMsTUFBNEI7UUFDckQsS0FBSyxNQUFNLElBQUksSUFBSSxNQUFNLEVBQUU7WUFDekIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRTtnQkFDbEMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN6QixDQUFDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJO1FBQ2Ysa0VBQWtFO1FBQ2xFLDhEQUE4RDtRQUM5RCxzQ0FBc0M7UUFDdEMsTUFBTSxRQUFRLEdBQWdCLE1BQU0sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDbEUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsaUJBQWlCLEVBQUUsR0FBRyxFQUFFO2dCQUN2RCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDO2dCQUNwQyxJQUFJLElBQUksSUFBSSxPQUFPLElBQUksS0FBSyxRQUFRLElBQUssSUFBb0IsQ0FBQyxJQUFJLEVBQUU7b0JBQ2xFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDZjtxQkFBTTtvQkFDTCxNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO2lCQUN2QztZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsR0FBRyxHQUFHLFVBQVUsUUFBUSxDQUFDLE9BQU8sSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7UUFFekQsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQkFBK0IsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFekQsT0FBTztZQUNMLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRztTQUNkLENBQUM7SUFDSixDQUFDO0lBRU0sS0FBSyxDQUFDLE9BQU87UUFDbEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRU8sUUFBUSxDQUFDLE9BQWU7UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7WUFDcEIsSUFBSSxFQUFFLGlCQUFTLENBQUMsUUFBUTtZQUN4QixJQUFJLEVBQUU7Z0JBQ0osT0FBTzthQUNSO1lBQ0QsVUFBVSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtZQUNyQyxVQUFVLEVBQUUsK0JBQVk7WUFDeEIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1NBQ3BDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQWhFRCwwQkFnRUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTZXJ2ZXIgfSBmcm9tIFwiaHR0cFwiO1xuaW1wb3J0IHsgQWRkcmVzc0luZm8gfSBmcm9tIFwibmV0XCI7XG5pbXBvcnQgZXhwcmVzcyBmcm9tIFwiZXhwcmVzc1wiO1xuaW1wb3J0IHsgQXBpQXR0cmlidXRlcywgV2Vic2l0ZVNjaGVtYSwgV0VCU0lURV9UWVBFIH0gZnJvbSBcIi4vc2NoZW1hLXJlc291cmNlc1wiO1xuaW1wb3J0IHsgVHJhY2VUeXBlLCBJV2Vic2l0ZUNsaWVudCB9IGZyb20gXCIuLi9jbG91ZFwiO1xuaW1wb3J0IHsgSnNvbiB9IGZyb20gXCIuLi9zdGRcIjtcbmltcG9ydCB7XG4gIElTaW11bGF0b3JDb250ZXh0LFxuICBJU2ltdWxhdG9yUmVzb3VyY2VJbnN0YW5jZSxcbn0gZnJvbSBcIi4uL3Rlc3Rpbmcvc2ltdWxhdG9yXCI7XG5cbmNvbnN0IExPQ0FMSE9TVF9BRERSRVNTID0gXCIxMjcuMC4wLjFcIjtcblxuZXhwb3J0IGNsYXNzIFdlYnNpdGUgaW1wbGVtZW50cyBJV2Vic2l0ZUNsaWVudCwgSVNpbXVsYXRvclJlc291cmNlSW5zdGFuY2Uge1xuICBwcml2YXRlIHJlYWRvbmx5IGNvbnRleHQ6IElTaW11bGF0b3JDb250ZXh0O1xuICBwcml2YXRlIHJlYWRvbmx5IGFwcDogZXhwcmVzcy5BcHBsaWNhdGlvbjtcbiAgcHJpdmF0ZSBzZXJ2ZXI/OiBTZXJ2ZXI7XG4gIHByaXZhdGUgdXJsPzogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHByb3BzOiBXZWJzaXRlU2NoZW1hW1wicHJvcHNcIl0sIGNvbnRleHQ6IElTaW11bGF0b3JDb250ZXh0KSB7XG4gICAgdGhpcy5jb250ZXh0ID0gY29udGV4dDtcblxuICAgIC8vIFNldCB1cCBhbiBleHByZXNzIHNlcnZlciB0aGF0IGhhbmRsZXMgdGhlIHJvdXRlcy5cbiAgICB0aGlzLmFwcCA9IGV4cHJlc3MoKTtcblxuICAgIC8vIFVzZSBzdGF0aWMgZGlyZWN0b3J5XG4gICAgdGhpcy5hcHAudXNlKGV4cHJlc3Muc3RhdGljKHByb3BzLnN0YXRpY0ZpbGVzUGF0aCkpO1xuICAgIHRoaXMuaW5pdGlhdGVKc29uUm91dGVzKHByb3BzLmpzb25Sb3V0ZXMpO1xuICB9XG5cbiAgcHJpdmF0ZSBpbml0aWF0ZUpzb25Sb3V0ZXMocm91dGVzOiBSZWNvcmQ8c3RyaW5nLCBKc29uPikge1xuICAgIGZvciAoY29uc3QgcGF0aCBpbiByb3V0ZXMpIHtcbiAgICAgIHRoaXMuYXBwLmdldChgLyR7cGF0aH1gLCAoXywgcmVzKSA9PiB7XG4gICAgICAgIHJlcy5qc29uKHJvdXRlc1twYXRoXSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgaW5pdCgpOiBQcm9taXNlPEFwaUF0dHJpYnV0ZXM+IHtcbiAgICAvLyBgc2VydmVyLmFkZHJlc3MoKWAgcmV0dXJucyBgbnVsbGAgdW50aWwgdGhlIHNlcnZlciBpcyBsaXN0ZW5pbmdcbiAgICAvLyBvbiBhIHBvcnQuIFdlIHVzZSBhIHByb21pc2UgdG8gd2FpdCBmb3IgdGhlIHNlcnZlciB0byBzdGFydFxuICAgIC8vIGxpc3RlbmluZyBiZWZvcmUgcmV0dXJuaW5nIHRoZSBVUkwuXG4gICAgY29uc3QgYWRkckluZm86IEFkZHJlc3NJbmZvID0gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5zZXJ2ZXIgPSB0aGlzLmFwcC5saXN0ZW4oMCwgTE9DQUxIT1NUX0FERFJFU1MsICgpID0+IHtcbiAgICAgICAgY29uc3QgYWRkciA9IHRoaXMuc2VydmVyPy5hZGRyZXNzKCk7XG4gICAgICAgIGlmIChhZGRyICYmIHR5cGVvZiBhZGRyID09PSBcIm9iamVjdFwiICYmIChhZGRyIGFzIEFkZHJlc3NJbmZvKS5wb3J0KSB7XG4gICAgICAgICAgcmVzb2x2ZShhZGRyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZWplY3QobmV3IEVycm9yKFwiTm8gYWRkcmVzcyBmb3VuZFwiKSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHRoaXMudXJsID0gYGh0dHA6Ly8ke2FkZHJJbmZvLmFkZHJlc3N9OiR7YWRkckluZm8ucG9ydH1gO1xuXG4gICAgdGhpcy5hZGRUcmFjZShgV2Vic2l0ZSBTZXJ2ZXIgbGlzdGVuaW5nIG9uICR7dGhpcy51cmx9YCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgdXJsOiB0aGlzLnVybCxcbiAgICB9O1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGNsZWFudXAoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy5hZGRUcmFjZShgQ2xvc2luZyBzZXJ2ZXIgb24gJHt0aGlzLnVybH1gKTtcbiAgICB0aGlzLnNlcnZlcj8uY2xvc2UoKTtcbiAgfVxuXG4gIHByaXZhdGUgYWRkVHJhY2UobWVzc2FnZTogc3RyaW5nKTogdm9pZCB7XG4gICAgdGhpcy5jb250ZXh0LmFkZFRyYWNlKHtcbiAgICAgIHR5cGU6IFRyYWNlVHlwZS5SRVNPVVJDRSxcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgbWVzc2FnZSxcbiAgICAgIH0sXG4gICAgICBzb3VyY2VQYXRoOiB0aGlzLmNvbnRleHQucmVzb3VyY2VQYXRoLFxuICAgICAgc291cmNlVHlwZTogV0VCU0lURV9UWVBFLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==