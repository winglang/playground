import type { IFunctionHandlerClient, IServiceOnEventClient } from "../cloud";
export declare class ServiceOnEventHandler implements IServiceOnEventClient {
    private readonly handler;
    constructor({ handler }: {
        handler: IFunctionHandlerClient;
    });
    handle(): Promise<void>;
}
