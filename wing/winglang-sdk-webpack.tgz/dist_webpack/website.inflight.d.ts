import { ApiAttributes, WebsiteSchema } from "./schema-resources";
import { IWebsiteClient } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Website implements IWebsiteClient, ISimulatorResourceInstance {
    private readonly context;
    private readonly app;
    private server?;
    private url?;
    constructor(props: WebsiteSchema["props"], context: ISimulatorContext);
    private initiateJsonRoutes;
    init(): Promise<ApiAttributes>;
    cleanup(): Promise<void>;
    private addTrace;
}
