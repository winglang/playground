"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Function = void 0;
const path = __importStar(require("path"));
const util = __importStar(require("util"));
const vm2_1 = require("vm2");
const schema_resources_1 = require("./schema-resources");
const cloud_1 = require("../cloud");
class Function {
    constructor(props, context) {
        if (props.sourceCodeLanguage !== "javascript") {
            throw new Error("Only JavaScript is supported");
        }
        this.filename = path.resolve(context.simdir, props.sourceCodeFile);
        this.env = props.environmentVariables ?? {};
        this.context = context;
        this.timeout = props.timeout;
    }
    async init() {
        return {};
    }
    async cleanup() {
        return;
    }
    async invoke(payload) {
        return this.context.withTrace({
            message: `Invoke (payload=${JSON.stringify(payload)}).`,
            activity: async () => {
                const vm = new vm2_1.NodeVM({
                    console: "redirect",
                    require: {
                        external: true,
                        builtin: ["*"],
                        context: "sandbox", // require inside the sandbox (addresses #1871)
                    },
                    sandbox: {
                        $simulator: this.context,
                    },
                    env: {
                        ...process.env,
                        ...this.env,
                    },
                    timeout: this.timeout,
                });
                // see https://github.com/patriksimek/vm2/blob/master/lib/nodevm.js#L89
                const levels = [
                    "debug",
                    "info",
                    "log",
                    "warn",
                    "error",
                    "dir",
                    "trace",
                ];
                for (const level of levels) {
                    vm.on(`console.${level}`, (...args) => {
                        const message = util.format(...args);
                        this.context.addTrace({
                            data: { message },
                            type: cloud_1.TraceType.LOG,
                            sourcePath: this.context.resourcePath,
                            sourceType: schema_resources_1.FUNCTION_TYPE,
                            timestamp: new Date().toISOString(),
                        });
                    });
                }
                const index = vm.runFile(this.filename);
                return index.handler(payload);
            },
        });
    }
}
exports.Function = Function;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVuY3Rpb24uaW5mbGlnaHQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdGFyZ2V0LXNpbS9mdW5jdGlvbi5pbmZsaWdodC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDJDQUE2QjtBQUM3QiwyQ0FBNkI7QUFDN0IsNkJBQTZCO0FBQzdCLHlEQUk0QjtBQUM1QixvQ0FBc0Q7QUFNdEQsTUFBYSxRQUFRO0lBTW5CLFlBQVksS0FBOEIsRUFBRSxPQUEwQjtRQUNwRSxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsS0FBSyxZQUFZLEVBQUU7WUFDN0MsTUFBTSxJQUFJLEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1NBQ2pEO1FBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ25FLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDLG9CQUFvQixJQUFJLEVBQUUsQ0FBQztRQUM1QyxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUN2QixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUM7SUFDL0IsQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJO1FBQ2YsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0lBRU0sS0FBSyxDQUFDLE9BQU87UUFDbEIsT0FBTztJQUNULENBQUM7SUFFTSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQWU7UUFDakMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUM1QixPQUFPLEVBQUUsbUJBQW1CLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDdkQsUUFBUSxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUNuQixNQUFNLEVBQUUsR0FBRyxJQUFJLFlBQU0sQ0FBQztvQkFDcEIsT0FBTyxFQUFFLFVBQVU7b0JBQ25CLE9BQU8sRUFBRTt3QkFDUCxRQUFRLEVBQUUsSUFBSTt3QkFDZCxPQUFPLEVBQUUsQ0FBQyxHQUFHLENBQUM7d0JBQ2QsT0FBTyxFQUFFLFNBQVMsRUFBRSwrQ0FBK0M7cUJBQ3BFO29CQUNELE9BQU8sRUFBRTt3QkFDUCxVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU87cUJBQ3pCO29CQUNELEdBQUcsRUFBRTt3QkFDSCxHQUFHLE9BQU8sQ0FBQyxHQUFHO3dCQUNkLEdBQUcsSUFBSSxDQUFDLEdBQUc7cUJBQ1o7b0JBQ0QsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2lCQUN0QixDQUFDLENBQUM7Z0JBRUgsdUVBQXVFO2dCQUN2RSxNQUFNLE1BQU0sR0FBRztvQkFDYixPQUFPO29CQUNQLE1BQU07b0JBQ04sS0FBSztvQkFDTCxNQUFNO29CQUNOLE9BQU87b0JBQ1AsS0FBSztvQkFDTCxPQUFPO2lCQUNSLENBQUM7Z0JBRUYsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNLEVBQUU7b0JBQzFCLEVBQUUsQ0FBQyxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFBRSxDQUFDLEdBQUcsSUFBSSxFQUFFLEVBQUU7d0JBQ3BDLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQzt3QkFDckMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7NEJBQ3BCLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRTs0QkFDakIsSUFBSSxFQUFFLGlCQUFTLENBQUMsR0FBRzs0QkFDbkIsVUFBVSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTs0QkFDckMsVUFBVSxFQUFFLGdDQUFhOzRCQUN6QixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7eUJBQ3BDLENBQUMsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztpQkFDSjtnQkFFRCxNQUFNLEtBQUssR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDeEMsT0FBTyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hDLENBQUM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUExRUQsNEJBMEVDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgcGF0aCBmcm9tIFwicGF0aFwiO1xuaW1wb3J0ICogYXMgdXRpbCBmcm9tIFwidXRpbFwiO1xuaW1wb3J0IHsgTm9kZVZNIH0gZnJvbSBcInZtMlwiO1xuaW1wb3J0IHtcbiAgRnVuY3Rpb25BdHRyaWJ1dGVzLFxuICBGdW5jdGlvblNjaGVtYSxcbiAgRlVOQ1RJT05fVFlQRSxcbn0gZnJvbSBcIi4vc2NoZW1hLXJlc291cmNlc1wiO1xuaW1wb3J0IHsgSUZ1bmN0aW9uQ2xpZW50LCBUcmFjZVR5cGUgfSBmcm9tIFwiLi4vY2xvdWRcIjtcbmltcG9ydCB7XG4gIElTaW11bGF0b3JDb250ZXh0LFxuICBJU2ltdWxhdG9yUmVzb3VyY2VJbnN0YW5jZSxcbn0gZnJvbSBcIi4uL3Rlc3Rpbmcvc2ltdWxhdG9yXCI7XG5cbmV4cG9ydCBjbGFzcyBGdW5jdGlvbiBpbXBsZW1lbnRzIElGdW5jdGlvbkNsaWVudCwgSVNpbXVsYXRvclJlc291cmNlSW5zdGFuY2Uge1xuICBwcml2YXRlIHJlYWRvbmx5IGZpbGVuYW1lOiBzdHJpbmc7XG4gIHByaXZhdGUgcmVhZG9ubHkgZW52OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICBwcml2YXRlIHJlYWRvbmx5IGNvbnRleHQ6IElTaW11bGF0b3JDb250ZXh0O1xuICBwcml2YXRlIHJlYWRvbmx5IHRpbWVvdXQ6IG51bWJlcjtcblxuICBjb25zdHJ1Y3Rvcihwcm9wczogRnVuY3Rpb25TY2hlbWFbXCJwcm9wc1wiXSwgY29udGV4dDogSVNpbXVsYXRvckNvbnRleHQpIHtcbiAgICBpZiAocHJvcHMuc291cmNlQ29kZUxhbmd1YWdlICE9PSBcImphdmFzY3JpcHRcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiT25seSBKYXZhU2NyaXB0IGlzIHN1cHBvcnRlZFwiKTtcbiAgICB9XG4gICAgdGhpcy5maWxlbmFtZSA9IHBhdGgucmVzb2x2ZShjb250ZXh0LnNpbWRpciwgcHJvcHMuc291cmNlQ29kZUZpbGUpO1xuICAgIHRoaXMuZW52ID0gcHJvcHMuZW52aXJvbm1lbnRWYXJpYWJsZXMgPz8ge307XG4gICAgdGhpcy5jb250ZXh0ID0gY29udGV4dDtcbiAgICB0aGlzLnRpbWVvdXQgPSBwcm9wcy50aW1lb3V0O1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGluaXQoKTogUHJvbWlzZTxGdW5jdGlvbkF0dHJpYnV0ZXM+IHtcbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgY2xlYW51cCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgaW52b2tlKHBheWxvYWQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgcmV0dXJuIHRoaXMuY29udGV4dC53aXRoVHJhY2Uoe1xuICAgICAgbWVzc2FnZTogYEludm9rZSAocGF5bG9hZD0ke0pTT04uc3RyaW5naWZ5KHBheWxvYWQpfSkuYCxcbiAgICAgIGFjdGl2aXR5OiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHZtID0gbmV3IE5vZGVWTSh7XG4gICAgICAgICAgY29uc29sZTogXCJyZWRpcmVjdFwiLCAvLyB3ZSBoaWphY2sgYGNvbnNvbGUueHh4YCBpbiBgY2xvdWQvZnVuY3Rpb24udHNgXG4gICAgICAgICAgcmVxdWlyZToge1xuICAgICAgICAgICAgZXh0ZXJuYWw6IHRydWUsXG4gICAgICAgICAgICBidWlsdGluOiBbXCIqXCJdLCAvLyBhbGxvdyB1c2luZyBhbGwgbm9kZSBtb2R1bGVzXG4gICAgICAgICAgICBjb250ZXh0OiBcInNhbmRib3hcIiwgLy8gcmVxdWlyZSBpbnNpZGUgdGhlIHNhbmRib3ggKGFkZHJlc3NlcyAjMTg3MSlcbiAgICAgICAgICB9LFxuICAgICAgICAgIHNhbmRib3g6IHtcbiAgICAgICAgICAgICRzaW11bGF0b3I6IHRoaXMuY29udGV4dCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGVudjoge1xuICAgICAgICAgICAgLi4ucHJvY2Vzcy5lbnYsXG4gICAgICAgICAgICAuLi50aGlzLmVudixcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRpbWVvdXQ6IHRoaXMudGltZW91dCxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9wYXRyaWtzaW1lay92bTIvYmxvYi9tYXN0ZXIvbGliL25vZGV2bS5qcyNMODlcbiAgICAgICAgY29uc3QgbGV2ZWxzID0gW1xuICAgICAgICAgIFwiZGVidWdcIixcbiAgICAgICAgICBcImluZm9cIixcbiAgICAgICAgICBcImxvZ1wiLFxuICAgICAgICAgIFwid2FyblwiLFxuICAgICAgICAgIFwiZXJyb3JcIixcbiAgICAgICAgICBcImRpclwiLFxuICAgICAgICAgIFwidHJhY2VcIixcbiAgICAgICAgXTtcblxuICAgICAgICBmb3IgKGNvbnN0IGxldmVsIG9mIGxldmVscykge1xuICAgICAgICAgIHZtLm9uKGBjb25zb2xlLiR7bGV2ZWx9YCwgKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSB1dGlsLmZvcm1hdCguLi5hcmdzKTtcbiAgICAgICAgICAgIHRoaXMuY29udGV4dC5hZGRUcmFjZSh7XG4gICAgICAgICAgICAgIGRhdGE6IHsgbWVzc2FnZSB9LFxuICAgICAgICAgICAgICB0eXBlOiBUcmFjZVR5cGUuTE9HLFxuICAgICAgICAgICAgICBzb3VyY2VQYXRoOiB0aGlzLmNvbnRleHQucmVzb3VyY2VQYXRoLFxuICAgICAgICAgICAgICBzb3VyY2VUeXBlOiBGVU5DVElPTl9UWVBFLFxuICAgICAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaW5kZXggPSB2bS5ydW5GaWxlKHRoaXMuZmlsZW5hbWUpO1xuICAgICAgICByZXR1cm4gaW5kZXguaGFuZGxlcihwYXlsb2FkKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==