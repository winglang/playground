"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Schedule = void 0;
const cron_parser_1 = require("cron-parser");
const schema_resources_1 = require("./schema-resources");
const cloud_1 = require("../cloud");
class Schedule {
    constructor(props, context) {
        this.tasks = new Array();
        this.context = context;
        this.interval = (0, cron_parser_1.parseExpression)(props.cronExpression);
        this.scheduleFunction();
    }
    // Calculate the delay for the next execution
    nextDelay(interval) {
        return interval.next().toDate().getTime() - Date.now();
    }
    // Recursively schedule the function to be executed
    scheduleFunction() {
        this.intervalTimeout = setTimeout(() => {
            this.runTasks();
            this.scheduleFunction();
        }, this.nextDelay(this.interval));
    }
    async init() {
        return {};
    }
    async cleanup() {
        clearTimeout(this.intervalTimeout);
    }
    async addEventSubscription(subscriber, subscriptionProps) {
        const task = {
            functionHandle: subscriber,
            ...subscriptionProps,
        };
        this.tasks.push(task);
    }
    runTasks() {
        for (const task of this.tasks) {
            const fnClient = this.context.findInstance(task.functionHandle);
            if (!fnClient) {
                throw new Error("No function client found for task.");
            }
            this.context.addTrace({
                type: cloud_1.TraceType.RESOURCE,
                data: {
                    message: `Running task with function handle: ${task.functionHandle}.`,
                },
                sourcePath: this.context.resourcePath,
                sourceType: schema_resources_1.SCHEDULE_TYPE,
                timestamp: new Date().toISOString(),
            });
            void fnClient.invoke("").catch((err) => {
                this.context.addTrace({
                    data: {
                        message: `Schedule error: ${err}`,
                    },
                    sourcePath: this.context.resourcePath,
                    sourceType: schema_resources_1.SCHEDULE_TYPE,
                    timestamp: new Date().toISOString(),
                    type: cloud_1.TraceType.RESOURCE,
                });
            });
        }
    }
}
exports.Schedule = Schedule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2NoZWR1bGUuaW5mbGlnaHQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdGFyZ2V0LXNpbS9zY2hlZHVsZS5pbmZsaWdodC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw2Q0FBOEQ7QUFFOUQseURBTTRCO0FBQzVCLG9DQUF1RTtBQUd2RSxNQUFhLFFBQVE7SUFRbkIsWUFBWSxLQUE4QixFQUFFLE9BQTBCO1FBSjlELFVBQUssR0FBRyxJQUFJLEtBQUssRUFBZ0IsQ0FBQztRQUt4QyxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUEsNkJBQWUsRUFBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDdEQsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELDZDQUE2QztJQUNyQyxTQUFTLENBQUMsUUFBd0I7UUFDeEMsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ3pELENBQUM7SUFFRCxtREFBbUQ7SUFDM0MsZ0JBQWdCO1FBQ3RCLElBQUksQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNyQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDaEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUIsQ0FBQyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJO1FBQ2YsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0lBRU0sS0FBSyxDQUFDLE9BQU87UUFDbEIsWUFBWSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRU0sS0FBSyxDQUFDLG9CQUFvQixDQUMvQixVQUFrQixFQUNsQixpQkFBb0M7UUFFcEMsTUFBTSxJQUFJLEdBQUc7WUFDWCxjQUFjLEVBQUUsVUFBVTtZQUMxQixHQUFHLGlCQUFpQjtTQUNMLENBQUM7UUFDbEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQUVPLFFBQVE7UUFDZCxLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDN0IsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQ3hDLElBQUksQ0FBQyxjQUFlLENBQzJCLENBQUM7WUFDbEQsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDYixNQUFNLElBQUksS0FBSyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7YUFDdkQ7WUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztnQkFDcEIsSUFBSSxFQUFFLGlCQUFTLENBQUMsUUFBUTtnQkFDeEIsSUFBSSxFQUFFO29CQUNKLE9BQU8sRUFBRSxzQ0FBc0MsSUFBSSxDQUFDLGNBQWMsR0FBRztpQkFDdEU7Z0JBQ0QsVUFBVSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtnQkFDckMsVUFBVSxFQUFFLGdDQUFhO2dCQUN6QixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7YUFDcEMsQ0FBQyxDQUFDO1lBRUgsS0FBSyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUNyQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztvQkFDcEIsSUFBSSxFQUFFO3dCQUNKLE9BQU8sRUFBRSxtQkFBbUIsR0FBRyxFQUFFO3FCQUNsQztvQkFDRCxVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO29CQUNyQyxVQUFVLEVBQUUsZ0NBQWE7b0JBQ3pCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtvQkFDbkMsSUFBSSxFQUFFLGlCQUFTLENBQUMsUUFBUTtpQkFDekIsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FDSjtJQUNILENBQUM7Q0FDRjtBQTlFRCw0QkE4RUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDcm9uRXhwcmVzc2lvbiwgcGFyc2VFeHByZXNzaW9uIH0gZnJvbSBcImNyb24tcGFyc2VyXCI7XG5pbXBvcnQgeyBJRXZlbnRQdWJsaXNoZXIgfSBmcm9tIFwiLi9ldmVudC1tYXBwaW5nXCI7XG5pbXBvcnQge1xuICBFdmVudFN1YnNjcmlwdGlvbixcbiAgU0NIRURVTEVfVFlQRSxcbiAgU2NoZWR1bGVBdHRyaWJ1dGVzLFxuICBTY2hlZHVsZVNjaGVtYSxcbiAgU2NoZWR1bGVUYXNrLFxufSBmcm9tIFwiLi9zY2hlbWEtcmVzb3VyY2VzXCI7XG5pbXBvcnQgeyBJRnVuY3Rpb25DbGllbnQsIElTY2hlZHVsZUNsaWVudCwgVHJhY2VUeXBlIH0gZnJvbSBcIi4uL2Nsb3VkXCI7XG5pbXBvcnQgeyBJU2ltdWxhdG9yQ29udGV4dCwgSVNpbXVsYXRvclJlc291cmNlSW5zdGFuY2UgfSBmcm9tIFwiLi4vdGVzdGluZ1wiO1xuXG5leHBvcnQgY2xhc3MgU2NoZWR1bGVcbiAgaW1wbGVtZW50cyBJU2NoZWR1bGVDbGllbnQsIElTaW11bGF0b3JSZXNvdXJjZUluc3RhbmNlLCBJRXZlbnRQdWJsaXNoZXJcbntcbiAgcHJpdmF0ZSByZWFkb25seSBjb250ZXh0OiBJU2ltdWxhdG9yQ29udGV4dDtcbiAgcHJpdmF0ZSB0YXNrcyA9IG5ldyBBcnJheTxTY2hlZHVsZVRhc2s+KCk7XG4gIHByaXZhdGUgaW50ZXJ2YWw6IENyb25FeHByZXNzaW9uO1xuICBwcml2YXRlIGludGVydmFsVGltZW91dD86IE5vZGVKUy5UaW1lb3V0O1xuXG4gIGNvbnN0cnVjdG9yKHByb3BzOiBTY2hlZHVsZVNjaGVtYVtcInByb3BzXCJdLCBjb250ZXh0OiBJU2ltdWxhdG9yQ29udGV4dCkge1xuICAgIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG4gICAgdGhpcy5pbnRlcnZhbCA9IHBhcnNlRXhwcmVzc2lvbihwcm9wcy5jcm9uRXhwcmVzc2lvbik7XG4gICAgdGhpcy5zY2hlZHVsZUZ1bmN0aW9uKCk7XG4gIH1cblxuICAvLyBDYWxjdWxhdGUgdGhlIGRlbGF5IGZvciB0aGUgbmV4dCBleGVjdXRpb25cbiAgcHJpdmF0ZSBuZXh0RGVsYXkoaW50ZXJ2YWw6IENyb25FeHByZXNzaW9uKSB7XG4gICAgcmV0dXJuIGludGVydmFsLm5leHQoKS50b0RhdGUoKS5nZXRUaW1lKCkgLSBEYXRlLm5vdygpO1xuICB9XG5cbiAgLy8gUmVjdXJzaXZlbHkgc2NoZWR1bGUgdGhlIGZ1bmN0aW9uIHRvIGJlIGV4ZWN1dGVkXG4gIHByaXZhdGUgc2NoZWR1bGVGdW5jdGlvbigpIHtcbiAgICB0aGlzLmludGVydmFsVGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5ydW5UYXNrcygpO1xuICAgICAgdGhpcy5zY2hlZHVsZUZ1bmN0aW9uKCk7XG4gICAgfSwgdGhpcy5uZXh0RGVsYXkodGhpcy5pbnRlcnZhbCkpO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGluaXQoKTogUHJvbWlzZTxTY2hlZHVsZUF0dHJpYnV0ZXM+IHtcbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgY2xlYW51cCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjbGVhclRpbWVvdXQodGhpcy5pbnRlcnZhbFRpbWVvdXQpO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGFkZEV2ZW50U3Vic2NyaXB0aW9uKFxuICAgIHN1YnNjcmliZXI6IHN0cmluZyxcbiAgICBzdWJzY3JpcHRpb25Qcm9wczogRXZlbnRTdWJzY3JpcHRpb25cbiAgKSB7XG4gICAgY29uc3QgdGFzayA9IHtcbiAgICAgIGZ1bmN0aW9uSGFuZGxlOiBzdWJzY3JpYmVyLFxuICAgICAgLi4uc3Vic2NyaXB0aW9uUHJvcHMsXG4gICAgfSBhcyBTY2hlZHVsZVRhc2s7XG4gICAgdGhpcy50YXNrcy5wdXNoKHRhc2spO1xuICB9XG5cbiAgcHJpdmF0ZSBydW5UYXNrcygpIHtcbiAgICBmb3IgKGNvbnN0IHRhc2sgb2YgdGhpcy50YXNrcykge1xuICAgICAgY29uc3QgZm5DbGllbnQgPSB0aGlzLmNvbnRleHQuZmluZEluc3RhbmNlKFxuICAgICAgICB0YXNrLmZ1bmN0aW9uSGFuZGxlIVxuICAgICAgKSBhcyBJRnVuY3Rpb25DbGllbnQgJiBJU2ltdWxhdG9yUmVzb3VyY2VJbnN0YW5jZTtcbiAgICAgIGlmICghZm5DbGllbnQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gZnVuY3Rpb24gY2xpZW50IGZvdW5kIGZvciB0YXNrLlwiKTtcbiAgICAgIH1cblxuICAgICAgdGhpcy5jb250ZXh0LmFkZFRyYWNlKHtcbiAgICAgICAgdHlwZTogVHJhY2VUeXBlLlJFU09VUkNFLFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgbWVzc2FnZTogYFJ1bm5pbmcgdGFzayB3aXRoIGZ1bmN0aW9uIGhhbmRsZTogJHt0YXNrLmZ1bmN0aW9uSGFuZGxlfS5gLFxuICAgICAgICB9LFxuICAgICAgICBzb3VyY2VQYXRoOiB0aGlzLmNvbnRleHQucmVzb3VyY2VQYXRoLFxuICAgICAgICBzb3VyY2VUeXBlOiBTQ0hFRFVMRV9UWVBFLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIH0pO1xuXG4gICAgICB2b2lkIGZuQ2xpZW50Lmludm9rZShcIlwiKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIHRoaXMuY29udGV4dC5hZGRUcmFjZSh7XG4gICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgbWVzc2FnZTogYFNjaGVkdWxlIGVycm9yOiAke2Vycn1gLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgc291cmNlUGF0aDogdGhpcy5jb250ZXh0LnJlc291cmNlUGF0aCxcbiAgICAgICAgICBzb3VyY2VUeXBlOiBTQ0hFRFVMRV9UWVBFLFxuICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIHR5cGU6IFRyYWNlVHlwZS5SRVNPVVJDRSxcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==