import { IEventPublisher } from "./event-mapping";
import { EventSubscription, ScheduleAttributes, ScheduleSchema } from "./schema-resources";
import { IScheduleClient } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing";
export declare class Schedule implements IScheduleClient, ISimulatorResourceInstance, IEventPublisher {
    private readonly context;
    private tasks;
    private interval;
    private intervalTimeout?;
    constructor(props: ScheduleSchema["props"], context: ISimulatorContext);
    private nextDelay;
    private scheduleFunction;
    init(): Promise<ScheduleAttributes>;
    cleanup(): Promise<void>;
    addEventSubscription(subscriber: string, subscriptionProps: EventSubscription): Promise<void>;
    private runTasks;
}
