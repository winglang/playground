"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Topic = void 0;
const schema_resources_1 = require("./schema-resources");
const cloud_1 = require("../cloud");
class Topic {
    constructor(props, context) {
        this.subscribers = new Array();
        this.context = context;
        props;
    }
    async init() {
        return {};
    }
    async cleanup() { }
    async publishMessage(message) {
        for (const subscriber of this.subscribers) {
            const fnClient = this.context.findInstance(subscriber.functionHandle);
            if (!fnClient) {
                throw new Error("No function client found!");
            }
            this.context.addTrace({
                type: cloud_1.TraceType.RESOURCE,
                data: {
                    message: `Sending message (message=${message}, subscriber=${subscriber.functionHandle}).`,
                },
                sourcePath: this.context.resourcePath,
                sourceType: schema_resources_1.TOPIC_TYPE,
                timestamp: new Date().toISOString(),
            });
            await fnClient.invoke(message).catch((err) => {
                this.context.addTrace({
                    data: {
                        message: `Subscriber error: ${err}`,
                    },
                    sourcePath: this.context.resourcePath,
                    sourceType: schema_resources_1.TOPIC_TYPE,
                    type: cloud_1.TraceType.RESOURCE,
                    timestamp: new Date().toISOString(),
                });
            });
        }
    }
    async addEventSubscription(subscriber, subscriptionProps) {
        let s = {
            functionHandle: subscriber,
            ...subscriptionProps,
        };
        this.subscribers.push(s);
    }
    async publish(message) {
        this.context.addTrace({
            data: {
                message: `Publish (message=${message}).`,
            },
            sourcePath: this.context.resourcePath,
            sourceType: schema_resources_1.TOPIC_TYPE,
            type: cloud_1.TraceType.RESOURCE,
            timestamp: new Date().toISOString(),
        });
        return this.publishMessage(message);
    }
}
exports.Topic = Topic;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9waWMuaW5mbGlnaHQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdGFyZ2V0LXNpbS90b3BpYy5pbmZsaWdodC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSx5REFPNEI7QUFDNUIsb0NBQW9FO0FBTXBFLE1BQWEsS0FBSztJQU1oQixZQUFZLEtBQTJCLEVBQUUsT0FBMEI7UUFIbEQsZ0JBQVcsR0FBRyxJQUFJLEtBQUssRUFBbUIsQ0FBQztRQUkxRCxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUN2QixLQUFLLENBQUM7SUFDUixDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUk7UUFDZixPQUFPLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFTSxLQUFLLENBQUMsT0FBTyxLQUFtQixDQUFDO0lBRWhDLEtBQUssQ0FBQyxjQUFjLENBQUMsT0FBZTtRQUMxQyxLQUFLLE1BQU0sVUFBVSxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDekMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQ3hDLFVBQVUsQ0FBQyxjQUFlLENBQ3FCLENBQUM7WUFFbEQsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDYixNQUFNLElBQUksS0FBSyxDQUFDLDJCQUEyQixDQUFDLENBQUM7YUFDOUM7WUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztnQkFDcEIsSUFBSSxFQUFFLGlCQUFTLENBQUMsUUFBUTtnQkFDeEIsSUFBSSxFQUFFO29CQUNKLE9BQU8sRUFBRSw0QkFBNEIsT0FBTyxnQkFBZ0IsVUFBVSxDQUFDLGNBQWMsSUFBSTtpQkFDMUY7Z0JBQ0QsVUFBVSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtnQkFDckMsVUFBVSxFQUFFLDZCQUFVO2dCQUN0QixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7YUFDcEMsQ0FBQyxDQUFDO1lBRUgsTUFBTSxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUMzQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztvQkFDcEIsSUFBSSxFQUFFO3dCQUNKLE9BQU8sRUFBRSxxQkFBcUIsR0FBRyxFQUFFO3FCQUNwQztvQkFDRCxVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO29CQUNyQyxVQUFVLEVBQUUsNkJBQVU7b0JBQ3RCLElBQUksRUFBRSxpQkFBUyxDQUFDLFFBQVE7b0JBQ3hCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtpQkFDcEMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FDSjtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsb0JBQW9CLENBQ3hCLFVBQTBCLEVBQzFCLGlCQUFvQztRQUVwQyxJQUFJLENBQUMsR0FBRztZQUNOLGNBQWMsRUFBRSxVQUFVO1lBQzFCLEdBQUcsaUJBQWlCO1NBQ0YsQ0FBQztRQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBRUQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFlO1FBQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO1lBQ3BCLElBQUksRUFBRTtnQkFDSixPQUFPLEVBQUUsb0JBQW9CLE9BQU8sSUFBSTthQUN6QztZQUNELFVBQVUsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVk7WUFDckMsVUFBVSxFQUFFLDZCQUFVO1lBQ3RCLElBQUksRUFBRSxpQkFBUyxDQUFDLFFBQVE7WUFDeEIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1NBQ3BDLENBQUMsQ0FBQztRQUVILE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN0QyxDQUFDO0NBQ0Y7QUEzRUQsc0JBMkVDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUV2ZW50UHVibGlzaGVyIH0gZnJvbSBcIi4vZXZlbnQtbWFwcGluZ1wiO1xuaW1wb3J0IHtcbiAgVG9waWNBdHRyaWJ1dGVzLFxuICBUb3BpY1NjaGVtYSxcbiAgVG9waWNTdWJzY3JpYmVyLFxuICBUT1BJQ19UWVBFLFxuICBFdmVudFN1YnNjcmlwdGlvbixcbiAgRnVuY3Rpb25IYW5kbGUsXG59IGZyb20gXCIuL3NjaGVtYS1yZXNvdXJjZXNcIjtcbmltcG9ydCB7IElGdW5jdGlvbkNsaWVudCwgSVRvcGljQ2xpZW50LCBUcmFjZVR5cGUgfSBmcm9tIFwiLi4vY2xvdWRcIjtcbmltcG9ydCB7XG4gIElTaW11bGF0b3JDb250ZXh0LFxuICBJU2ltdWxhdG9yUmVzb3VyY2VJbnN0YW5jZSxcbn0gZnJvbSBcIi4uL3Rlc3Rpbmcvc2ltdWxhdG9yXCI7XG5cbmV4cG9ydCBjbGFzcyBUb3BpY1xuICBpbXBsZW1lbnRzIElUb3BpY0NsaWVudCwgSVNpbXVsYXRvclJlc291cmNlSW5zdGFuY2UsIElFdmVudFB1Ymxpc2hlclxue1xuICBwcml2YXRlIHJlYWRvbmx5IHN1YnNjcmliZXJzID0gbmV3IEFycmF5PFRvcGljU3Vic2NyaWJlcj4oKTtcbiAgcHJpdmF0ZSByZWFkb25seSBjb250ZXh0OiBJU2ltdWxhdG9yQ29udGV4dDtcblxuICBjb25zdHJ1Y3Rvcihwcm9wczogVG9waWNTY2hlbWFbXCJwcm9wc1wiXSwgY29udGV4dDogSVNpbXVsYXRvckNvbnRleHQpIHtcbiAgICB0aGlzLmNvbnRleHQgPSBjb250ZXh0O1xuICAgIHByb3BzO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGluaXQoKTogUHJvbWlzZTxUb3BpY0F0dHJpYnV0ZXM+IHtcbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgY2xlYW51cCgpOiBQcm9taXNlPHZvaWQ+IHt9XG5cbiAgcHJpdmF0ZSBhc3luYyBwdWJsaXNoTWVzc2FnZShtZXNzYWdlOiBzdHJpbmcpIHtcbiAgICBmb3IgKGNvbnN0IHN1YnNjcmliZXIgb2YgdGhpcy5zdWJzY3JpYmVycykge1xuICAgICAgY29uc3QgZm5DbGllbnQgPSB0aGlzLmNvbnRleHQuZmluZEluc3RhbmNlKFxuICAgICAgICBzdWJzY3JpYmVyLmZ1bmN0aW9uSGFuZGxlIVxuICAgICAgKSBhcyBJRnVuY3Rpb25DbGllbnQgJiBJU2ltdWxhdG9yUmVzb3VyY2VJbnN0YW5jZTtcblxuICAgICAgaWYgKCFmbkNsaWVudCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBmdW5jdGlvbiBjbGllbnQgZm91bmQhXCIpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLmNvbnRleHQuYWRkVHJhY2Uoe1xuICAgICAgICB0eXBlOiBUcmFjZVR5cGUuUkVTT1VSQ0UsXG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICBtZXNzYWdlOiBgU2VuZGluZyBtZXNzYWdlIChtZXNzYWdlPSR7bWVzc2FnZX0sIHN1YnNjcmliZXI9JHtzdWJzY3JpYmVyLmZ1bmN0aW9uSGFuZGxlfSkuYCxcbiAgICAgICAgfSxcbiAgICAgICAgc291cmNlUGF0aDogdGhpcy5jb250ZXh0LnJlc291cmNlUGF0aCxcbiAgICAgICAgc291cmNlVHlwZTogVE9QSUNfVFlQRSxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9KTtcblxuICAgICAgYXdhaXQgZm5DbGllbnQuaW52b2tlKG1lc3NhZ2UpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgdGhpcy5jb250ZXh0LmFkZFRyYWNlKHtcbiAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICBtZXNzYWdlOiBgU3Vic2NyaWJlciBlcnJvcjogJHtlcnJ9YCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHNvdXJjZVBhdGg6IHRoaXMuY29udGV4dC5yZXNvdXJjZVBhdGgsXG4gICAgICAgICAgc291cmNlVHlwZTogVE9QSUNfVFlQRSxcbiAgICAgICAgICB0eXBlOiBUcmFjZVR5cGUuUkVTT1VSQ0UsXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgYWRkRXZlbnRTdWJzY3JpcHRpb24oXG4gICAgc3Vic2NyaWJlcjogRnVuY3Rpb25IYW5kbGUsXG4gICAgc3Vic2NyaXB0aW9uUHJvcHM6IEV2ZW50U3Vic2NyaXB0aW9uXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGxldCBzID0ge1xuICAgICAgZnVuY3Rpb25IYW5kbGU6IHN1YnNjcmliZXIsXG4gICAgICAuLi5zdWJzY3JpcHRpb25Qcm9wcyxcbiAgICB9IGFzIFRvcGljU3Vic2NyaWJlcjtcbiAgICB0aGlzLnN1YnNjcmliZXJzLnB1c2gocyk7XG4gIH1cblxuICBhc3luYyBwdWJsaXNoKG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRoaXMuY29udGV4dC5hZGRUcmFjZSh7XG4gICAgICBkYXRhOiB7XG4gICAgICAgIG1lc3NhZ2U6IGBQdWJsaXNoIChtZXNzYWdlPSR7bWVzc2FnZX0pLmAsXG4gICAgICB9LFxuICAgICAgc291cmNlUGF0aDogdGhpcy5jb250ZXh0LnJlc291cmNlUGF0aCxcbiAgICAgIHNvdXJjZVR5cGU6IFRPUElDX1RZUEUsXG4gICAgICB0eXBlOiBUcmFjZVR5cGUuUkVTT1VSQ0UsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9KTtcblxuICAgIHJldHVybiB0aGlzLnB1Ymxpc2hNZXNzYWdlKG1lc3NhZ2UpO1xuICB9XG59XG4iXX0=