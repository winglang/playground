import { TableAttributes, TableSchema } from "./schema-resources";
import { ITableClient } from "../cloud";
import { Json } from "../std";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Table implements ITableClient, ISimulatorResourceInstance {
    private name;
    private columns;
    private primaryKey;
    private table;
    private readonly context;
    constructor(props: TableSchema["props"], context: ISimulatorContext);
    init(): Promise<TableAttributes>;
    cleanup(): Promise<void>;
    insert(key: string, row: Json): Promise<void>;
    update(key: string, row: Json): Promise<void>;
    delete(key: string): Promise<void>;
    get(key: string): Promise<Json>;
    list(): Promise<Array<Json>>;
}
