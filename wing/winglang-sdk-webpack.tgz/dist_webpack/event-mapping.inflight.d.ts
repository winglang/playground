import { EventMappingAttributes, EventMappingSchema } from "./schema-resources";
import { ISimulatorContext } from "../testing";
import { ISimulatorResourceInstance } from "../testing/simulator";
export declare class EventMapping implements ISimulatorResourceInstance {
    private readonly publisher;
    private readonly subscriber;
    private readonly eventSubscription;
    private readonly context;
    constructor(props: EventMappingSchema["props"], context: ISimulatorContext);
    init(): Promise<EventMappingAttributes>;
    cleanup(): Promise<void>;
}
