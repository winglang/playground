import { IEventPublisher } from "./event-mapping";
import { QueueAttributes, QueueSchema, EventSubscription, FunctionHandle } from "./schema-resources";
import { IQueueClient } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Queue implements IQueueClient, ISimulatorResourceInstance, IEventPublisher {
    private readonly messages;
    private readonly subscribers;
    private readonly intervalId;
    private readonly context;
    private readonly timeout;
    private readonly retentionPeriod;
    constructor(props: QueueSchema["props"], context: ISimulatorContext);
    init(): Promise<QueueAttributes>;
    cleanup(): Promise<void>;
    addEventSubscription(subscriber: FunctionHandle, subscriptionProps: EventSubscription): Promise<void>;
    push(message: string): Promise<void>;
    purge(): Promise<void>;
    approxSize(): Promise<number>;
    private processMessages;
    pushMessagesBackToQueue(messages: Array<QueueMessage>): Promise<void>;
}
declare class QueueMessage {
    retentionTimeout: Date;
    payload: string;
    constructor(retentionPeriod: number, message: string);
}
export {};
