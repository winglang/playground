import { RedisAttributes, RedisSchema } from "./schema-resources";
import { RedisClientBase } from "../redis";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Redis extends RedisClientBase implements ISimulatorResourceInstance {
    private container_name;
    private readonly WING_REDIS_IMAGE;
    private readonly context;
    private connection_url?;
    private connection?;
    constructor(_props: RedisSchema["props"], context: ISimulatorContext);
    init(): Promise<RedisAttributes>;
    cleanup(): Promise<void>;
    rawClient(): Promise<any>;
    url(): Promise<string>;
}
