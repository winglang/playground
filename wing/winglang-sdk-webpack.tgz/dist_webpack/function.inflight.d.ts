import { FunctionAttributes, FunctionSchema } from "./schema-resources";
import { IFunctionClient } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Function implements IFunctionClient, ISimulatorResourceInstance {
    private readonly filename;
    private readonly env;
    private readonly context;
    private readonly timeout;
    constructor(props: FunctionSchema["props"], context: ISimulatorContext);
    init(): Promise<FunctionAttributes>;
    cleanup(): Promise<void>;
    invoke(payload: string): Promise<string>;
}
