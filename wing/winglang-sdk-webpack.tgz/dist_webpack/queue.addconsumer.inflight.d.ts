import type { IFunctionHandlerClient, IQueueAddConsumerHandlerClient } from "../cloud";
export declare class QueueAddConsumerHandlerClient implements IQueueAddConsumerHandlerClient {
    private readonly handler;
    constructor({ handler }: {
        handler: IFunctionHandlerClient;
    });
    handle(event: string): Promise<void>;
}
