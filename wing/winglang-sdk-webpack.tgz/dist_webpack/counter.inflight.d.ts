import { CounterAttributes, CounterSchema } from "./schema-resources";
import { ICounterClient } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Counter implements ICounterClient, ISimulatorResourceInstance {
    private value;
    private readonly context;
    constructor(props: CounterSchema["props"], context: ISimulatorContext);
    init(): Promise<CounterAttributes>;
    cleanup(): Promise<void>;
    inc(amount?: number): Promise<number>;
    dec(amount?: number): Promise<number>;
    peek(): Promise<number>;
    reset(reset_value?: number): Promise<void>;
}
