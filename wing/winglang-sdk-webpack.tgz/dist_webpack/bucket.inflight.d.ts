import { BucketAttributes, BucketSchema } from "./schema-resources";
import { BucketDeleteOptions, IBucketClient } from "../cloud";
import { Json } from "../std";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing/simulator";
export declare class Bucket implements IBucketClient, ISimulatorResourceInstance {
    private readonly objectKeys;
    private readonly fileDir;
    private readonly context;
    private readonly initialObjects;
    private readonly _public;
    private readonly topicHandlers;
    constructor(props: BucketSchema["props"], context: ISimulatorContext);
    init(): Promise<BucketAttributes>;
    cleanup(): Promise<void>;
    private notifyListeners;
    private fileExists;
    put(key: string, value: string): Promise<void>;
    putJson(key: string, body: Json): Promise<void>;
    get(key: string): Promise<string>;
    getJson(key: string): Promise<Json>;
    list(prefix?: string): Promise<string[]>;
    publicUrl(key: string): Promise<string>;
    delete(key: string, opts?: BucketDeleteOptions): Promise<void>;
    private addFile;
    private hashKey;
}
