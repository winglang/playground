import { TestRunnerAttributes, TestRunnerSchema } from "./schema-resources";
import { ITestRunnerClient, TestResult } from "../cloud";
import { ISimulatorContext, ISimulatorResourceInstance } from "../testing";
export declare class TestRunnerClient implements ITestRunnerClient, ISimulatorResourceInstance {
    private readonly tests;
    private readonly context;
    constructor(props: TestRunnerSchema["props"], context: ISimulatorContext);
    init(): Promise<TestRunnerAttributes>;
    cleanup(): Promise<void>;
    listTests(): Promise<string[]>;
    runTest(path: string): Promise<TestResult>;
}
