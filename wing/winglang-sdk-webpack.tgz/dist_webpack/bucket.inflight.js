"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bucket = void 0;
const crypto = __importStar(require("crypto"));
const fs = __importStar(require("fs"));
const os = __importStar(require("os"));
const path_1 = require("path");
const cloud_1 = require("../cloud");
class Bucket {
    constructor(props, context) {
        this.objectKeys = new Set();
        this.fileDir = fs.mkdtempSync((0, path_1.join)(os.tmpdir(), "wing-sim-"));
        this.context = context;
        this.initialObjects = props.initialObjects ?? {};
        this._public = props.public ?? false;
        this.topicHandlers = props.topics;
    }
    async init() {
        for (const [key, value] of Object.entries(this.initialObjects)) {
            await this.context.withTrace({
                message: `Adding object from preflight (key=${key}).`,
                activity: async () => {
                    return this.addFile(key, value);
                },
            });
        }
        return {};
    }
    async cleanup() {
        await fs.promises.rm(this.fileDir, { recursive: true, force: true });
    }
    async notifyListeners(actionType, key) {
        if (!this.topicHandlers[actionType]) {
            return;
        }
        const topicClient = this.context.findInstance(this.topicHandlers[actionType]);
        return topicClient.publish(key);
    }
    async fileExists(key) {
        return fs.promises
            .access((0, path_1.join)(this.fileDir, key))
            .then(() => true)
            .catch(() => false);
    }
    async put(key, value) {
        return this.context.withTrace({
            message: `Put (key=${key}).`,
            activity: async () => {
                return this.addFile(key, value);
            },
        });
    }
    async putJson(key, body) {
        return this.context.withTrace({
            message: `Put Json (key=${key}).`,
            activity: async () => {
                const actionType = (await this.fileExists(key))
                    ? cloud_1.BucketEventType.UPDATE
                    : cloud_1.BucketEventType.CREATE;
                await this.addFile(key, JSON.stringify(body, null, 2));
                await this.notifyListeners(actionType, key);
            },
        });
    }
    async get(key) {
        return this.context.withTrace({
            message: `Get (key=${key}).`,
            activity: async () => {
                const hash = this.hashKey(key);
                const filename = (0, path_1.join)(this.fileDir, hash);
                try {
                    return await fs.promises.readFile(filename, "utf8");
                }
                catch (e) {
                    throw new Error(`Object does not exist (key=${key}): ${e.stack}`);
                }
            },
        });
    }
    async getJson(key) {
        return this.context.withTrace({
            message: `Get Json (key=${key}).`,
            activity: async () => {
                const hash = this.hashKey(key);
                const filename = (0, path_1.join)(this.fileDir, hash);
                return JSON.parse(await fs.promises.readFile(filename, "utf8"));
            },
        });
    }
    async list(prefix) {
        return this.context.withTrace({
            message: `List (prefix=${prefix ?? "null"}).`,
            activity: async () => {
                return Array.from(this.objectKeys.values()).filter((key) => {
                    if (prefix) {
                        return key.startsWith(prefix);
                    }
                    else {
                        return true;
                    }
                });
            },
        });
    }
    async publicUrl(key) {
        if (!this._public) {
            throw new Error("Cannot provide public url for a non-public bucket");
        }
        return this.context.withTrace({
            message: `Public URL (key=${key}).`,
            activity: async () => {
                const filePath = (0, path_1.join)(this.fileDir, key);
                if (!this.objectKeys.has(key)) {
                    throw new Error(`Cannot provide public url for an non-existent key (key=${key})`);
                }
                return filePath;
            },
        });
    }
    async delete(key, opts) {
        return this.context.withTrace({
            message: `Delete (key=${key}).`,
            activity: async () => {
                const mustExist = opts?.mustExist ?? false;
                if (!this.objectKeys.has(key) && mustExist) {
                    throw new Error(`Object does not exist (key=${key}).`);
                }
                if (!this.objectKeys.has(key)) {
                    return;
                }
                const hash = this.hashKey(key);
                const filename = (0, path_1.join)(this.fileDir, hash);
                await fs.promises.unlink(filename);
                this.objectKeys.delete(key);
                await this.notifyListeners(cloud_1.BucketEventType.DELETE, key);
            },
        });
    }
    async addFile(key, value) {
        const actionType = this.objectKeys.has(key)
            ? cloud_1.BucketEventType.UPDATE
            : cloud_1.BucketEventType.CREATE;
        const hash = this.hashKey(key);
        const filename = (0, path_1.join)(this.fileDir, hash);
        const dirName = (0, path_1.dirname)(filename);
        await fs.promises.mkdir(dirName, { recursive: true });
        await fs.promises.writeFile(filename, value);
        this.objectKeys.add(key);
        await this.notifyListeners(actionType, key);
    }
    hashKey(key) {
        return crypto.createHash("sha512").update(key).digest("hex");
    }
}
exports.Bucket = Bucket;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVja2V0LmluZmxpZ2h0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3RhcmdldC1zaW0vYnVja2V0LmluZmxpZ2h0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0NBQWlDO0FBQ2pDLHVDQUF5QjtBQUN6Qix1Q0FBeUI7QUFDekIsK0JBQXFDO0FBRXJDLG9DQUtrQjtBQU9sQixNQUFhLE1BQU07SUFRakIsWUFBbUIsS0FBNEIsRUFBRSxPQUEwQjtRQUN6RSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUEsV0FBSSxFQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQzlELElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLGNBQWMsSUFBSSxFQUFFLENBQUM7UUFDakQsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxJQUFJLEtBQUssQ0FBQztRQUNyQyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7SUFDcEMsQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJO1FBQ2YsS0FBSyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQzlELE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7Z0JBQzNCLE9BQU8sRUFBRSxxQ0FBcUMsR0FBRyxJQUFJO2dCQUNyRCxRQUFRLEVBQUUsS0FBSyxJQUFJLEVBQUU7b0JBQ25CLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ2xDLENBQUM7YUFDRixDQUFDLENBQUM7U0FDSjtRQUNELE9BQU8sRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVNLEtBQUssQ0FBQyxPQUFPO1FBQ2xCLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVPLEtBQUssQ0FBQyxlQUFlLENBQUMsVUFBMkIsRUFBRSxHQUFXO1FBQ3BFLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ25DLE9BQU87U0FDUjtRQUVELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUMzQyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBRSxDQUNhLENBQUM7UUFFL0MsT0FBTyxXQUFXLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFTyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQVc7UUFDbEMsT0FBTyxFQUFFLENBQUMsUUFBUTthQUNmLE1BQU0sQ0FBQyxJQUFBLFdBQUksRUFBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2FBQy9CLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUM7YUFDaEIsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3hCLENBQUM7SUFFTSxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQVcsRUFBRSxLQUFhO1FBQ3pDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFDNUIsT0FBTyxFQUFFLFlBQVksR0FBRyxJQUFJO1lBQzVCLFFBQVEsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDbkIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNsQyxDQUFDO1NBQ0YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBVyxFQUFFLElBQVU7UUFDMUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUM1QixPQUFPLEVBQUUsaUJBQWlCLEdBQUcsSUFBSTtZQUNqQyxRQUFRLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ25CLE1BQU0sVUFBVSxHQUFvQixDQUFDLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDOUQsQ0FBQyxDQUFDLHVCQUFlLENBQUMsTUFBTTtvQkFDeEIsQ0FBQyxDQUFDLHVCQUFlLENBQUMsTUFBTSxDQUFDO2dCQUUzQixNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2RCxNQUFNLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzlDLENBQUM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFXO1FBQzFCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFDNUIsT0FBTyxFQUFFLFlBQVksR0FBRyxJQUFJO1lBQzVCLFFBQVEsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDbkIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDL0IsTUFBTSxRQUFRLEdBQUcsSUFBQSxXQUFJLEVBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUMsSUFBSTtvQkFDRixPQUFPLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2lCQUNyRDtnQkFBQyxPQUFPLENBQUMsRUFBRTtvQkFDVixNQUFNLElBQUksS0FBSyxDQUNiLDhCQUE4QixHQUFHLE1BQU8sQ0FBVyxDQUFDLEtBQUssRUFBRSxDQUM1RCxDQUFDO2lCQUNIO1lBQ0gsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQVc7UUFDOUIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUM1QixPQUFPLEVBQUUsaUJBQWlCLEdBQUcsSUFBSTtZQUNqQyxRQUFRLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ25CLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQy9CLE1BQU0sUUFBUSxHQUFHLElBQUEsV0FBSSxFQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzFDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2xFLENBQUM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFlO1FBQy9CLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFDNUIsT0FBTyxFQUFFLGdCQUFnQixNQUFNLElBQUksTUFBTSxJQUFJO1lBQzdDLFFBQVEsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDbkIsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRTtvQkFDekQsSUFBSSxNQUFNLEVBQUU7d0JBQ1YsT0FBTyxHQUFHLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUMvQjt5QkFBTTt3QkFDTCxPQUFPLElBQUksQ0FBQztxQkFDYjtnQkFDSCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFXO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2pCLE1BQU0sSUFBSSxLQUFLLENBQUMsbURBQW1ELENBQUMsQ0FBQztTQUN0RTtRQUNELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFDNUIsT0FBTyxFQUFFLG1CQUFtQixHQUFHLElBQUk7WUFDbkMsUUFBUSxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUNuQixNQUFNLFFBQVEsR0FBRyxJQUFBLFdBQUksRUFBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUV6QyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQzdCLE1BQU0sSUFBSSxLQUFLLENBQ2IsMERBQTBELEdBQUcsR0FBRyxDQUNqRSxDQUFDO2lCQUNIO2dCQUVELE9BQU8sUUFBUSxDQUFDO1lBQ2xCLENBQUM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFXLEVBQUUsSUFBMEI7UUFDekQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUM1QixPQUFPLEVBQUUsZUFBZSxHQUFHLElBQUk7WUFDL0IsUUFBUSxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUNuQixNQUFNLFNBQVMsR0FBRyxJQUFJLEVBQUUsU0FBUyxJQUFJLEtBQUssQ0FBQztnQkFFM0MsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLFNBQVMsRUFBRTtvQkFDMUMsTUFBTSxJQUFJLEtBQUssQ0FBQyw4QkFBOEIsR0FBRyxJQUFJLENBQUMsQ0FBQztpQkFDeEQ7Z0JBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUM3QixPQUFPO2lCQUNSO2dCQUVELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQy9CLE1BQU0sUUFBUSxHQUFHLElBQUEsV0FBSSxFQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUM1QixNQUFNLElBQUksQ0FBQyxlQUFlLENBQUMsdUJBQWUsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDMUQsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQVcsRUFBRSxLQUFhO1FBQzlDLE1BQU0sVUFBVSxHQUFvQixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7WUFDMUQsQ0FBQyxDQUFDLHVCQUFlLENBQUMsTUFBTTtZQUN4QixDQUFDLENBQUMsdUJBQWUsQ0FBQyxNQUFNLENBQUM7UUFDM0IsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMvQixNQUFNLFFBQVEsR0FBRyxJQUFBLFdBQUksRUFBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFDLE1BQU0sT0FBTyxHQUFHLElBQUEsY0FBTyxFQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7UUFDdEQsTUFBTSxFQUFFLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDekIsTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRU8sT0FBTyxDQUFDLEdBQVc7UUFDekIsT0FBTyxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDL0QsQ0FBQztDQUNGO0FBakxELHdCQWlMQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGNyeXB0byBmcm9tIFwiY3J5cHRvXCI7XG5pbXBvcnQgKiBhcyBmcyBmcm9tIFwiZnNcIjtcbmltcG9ydCAqIGFzIG9zIGZyb20gXCJvc1wiO1xuaW1wb3J0IHsgZGlybmFtZSwgam9pbiB9IGZyb20gXCJwYXRoXCI7XG5pbXBvcnQgeyBCdWNrZXRBdHRyaWJ1dGVzLCBCdWNrZXRTY2hlbWEgfSBmcm9tIFwiLi9zY2hlbWEtcmVzb3VyY2VzXCI7XG5pbXBvcnQge1xuICBCdWNrZXREZWxldGVPcHRpb25zLFxuICBCdWNrZXRFdmVudFR5cGUsXG4gIElCdWNrZXRDbGllbnQsXG4gIElUb3BpY0NsaWVudCxcbn0gZnJvbSBcIi4uL2Nsb3VkXCI7XG5pbXBvcnQgeyBKc29uIH0gZnJvbSBcIi4uL3N0ZFwiO1xuaW1wb3J0IHtcbiAgSVNpbXVsYXRvckNvbnRleHQsXG4gIElTaW11bGF0b3JSZXNvdXJjZUluc3RhbmNlLFxufSBmcm9tIFwiLi4vdGVzdGluZy9zaW11bGF0b3JcIjtcblxuZXhwb3J0IGNsYXNzIEJ1Y2tldCBpbXBsZW1lbnRzIElCdWNrZXRDbGllbnQsIElTaW11bGF0b3JSZXNvdXJjZUluc3RhbmNlIHtcbiAgcHJpdmF0ZSByZWFkb25seSBvYmplY3RLZXlzOiBTZXQ8c3RyaW5nPjtcbiAgcHJpdmF0ZSByZWFkb25seSBmaWxlRGlyOiBzdHJpbmc7XG4gIHByaXZhdGUgcmVhZG9ubHkgY29udGV4dDogSVNpbXVsYXRvckNvbnRleHQ7XG4gIHByaXZhdGUgcmVhZG9ubHkgaW5pdGlhbE9iamVjdHM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG4gIHByaXZhdGUgcmVhZG9ubHkgX3B1YmxpYzogYm9vbGVhbjtcbiAgcHJpdmF0ZSByZWFkb25seSB0b3BpY0hhbmRsZXJzOiBQYXJ0aWFsPFJlY29yZDxCdWNrZXRFdmVudFR5cGUsIHN0cmluZz4+O1xuXG4gIHB1YmxpYyBjb25zdHJ1Y3Rvcihwcm9wczogQnVja2V0U2NoZW1hW1wicHJvcHNcIl0sIGNvbnRleHQ6IElTaW11bGF0b3JDb250ZXh0KSB7XG4gICAgdGhpcy5vYmplY3RLZXlzID0gbmV3IFNldCgpO1xuICAgIHRoaXMuZmlsZURpciA9IGZzLm1rZHRlbXBTeW5jKGpvaW4ob3MudG1wZGlyKCksIFwid2luZy1zaW0tXCIpKTtcbiAgICB0aGlzLmNvbnRleHQgPSBjb250ZXh0O1xuICAgIHRoaXMuaW5pdGlhbE9iamVjdHMgPSBwcm9wcy5pbml0aWFsT2JqZWN0cyA/PyB7fTtcbiAgICB0aGlzLl9wdWJsaWMgPSBwcm9wcy5wdWJsaWMgPz8gZmFsc2U7XG4gICAgdGhpcy50b3BpY0hhbmRsZXJzID0gcHJvcHMudG9waWNzO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGluaXQoKTogUHJvbWlzZTxCdWNrZXRBdHRyaWJ1dGVzPiB7XG4gICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXModGhpcy5pbml0aWFsT2JqZWN0cykpIHtcbiAgICAgIGF3YWl0IHRoaXMuY29udGV4dC53aXRoVHJhY2Uoe1xuICAgICAgICBtZXNzYWdlOiBgQWRkaW5nIG9iamVjdCBmcm9tIHByZWZsaWdodCAoa2V5PSR7a2V5fSkuYCxcbiAgICAgICAgYWN0aXZpdHk6IGFzeW5jICgpID0+IHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5hZGRGaWxlKGtleSwgdmFsdWUpO1xuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiB7fTtcbiAgfVxuXG4gIHB1YmxpYyBhc3luYyBjbGVhbnVwKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGZzLnByb21pc2VzLnJtKHRoaXMuZmlsZURpciwgeyByZWN1cnNpdmU6IHRydWUsIGZvcmNlOiB0cnVlIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBub3RpZnlMaXN0ZW5lcnMoYWN0aW9uVHlwZTogQnVja2V0RXZlbnRUeXBlLCBrZXk6IHN0cmluZykge1xuICAgIGlmICghdGhpcy50b3BpY0hhbmRsZXJzW2FjdGlvblR5cGVdKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdG9waWNDbGllbnQgPSB0aGlzLmNvbnRleHQuZmluZEluc3RhbmNlKFxuICAgICAgdGhpcy50b3BpY0hhbmRsZXJzW2FjdGlvblR5cGVdIVxuICAgICkgYXMgSVRvcGljQ2xpZW50ICYgSVNpbXVsYXRvclJlc291cmNlSW5zdGFuY2U7XG5cbiAgICByZXR1cm4gdG9waWNDbGllbnQucHVibGlzaChrZXkpO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmaWxlRXhpc3RzKGtleTogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgcmV0dXJuIGZzLnByb21pc2VzXG4gICAgICAuYWNjZXNzKGpvaW4odGhpcy5maWxlRGlyLCBrZXkpKVxuICAgICAgLnRoZW4oKCkgPT4gdHJ1ZSlcbiAgICAgIC5jYXRjaCgoKSA9PiBmYWxzZSk7XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgcHV0KGtleTogc3RyaW5nLCB2YWx1ZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMuY29udGV4dC53aXRoVHJhY2Uoe1xuICAgICAgbWVzc2FnZTogYFB1dCAoa2V5PSR7a2V5fSkuYCxcbiAgICAgIGFjdGl2aXR5OiBhc3luYyAoKSA9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmFkZEZpbGUoa2V5LCB2YWx1ZSk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIHB1dEpzb24oa2V5OiBzdHJpbmcsIGJvZHk6IEpzb24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy5jb250ZXh0LndpdGhUcmFjZSh7XG4gICAgICBtZXNzYWdlOiBgUHV0IEpzb24gKGtleT0ke2tleX0pLmAsXG4gICAgICBhY3Rpdml0eTogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBhY3Rpb25UeXBlOiBCdWNrZXRFdmVudFR5cGUgPSAoYXdhaXQgdGhpcy5maWxlRXhpc3RzKGtleSkpXG4gICAgICAgICAgPyBCdWNrZXRFdmVudFR5cGUuVVBEQVRFXG4gICAgICAgICAgOiBCdWNrZXRFdmVudFR5cGUuQ1JFQVRFO1xuXG4gICAgICAgIGF3YWl0IHRoaXMuYWRkRmlsZShrZXksIEpTT04uc3RyaW5naWZ5KGJvZHksIG51bGwsIDIpKTtcbiAgICAgICAgYXdhaXQgdGhpcy5ub3RpZnlMaXN0ZW5lcnMoYWN0aW9uVHlwZSwga2V5KTtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgZ2V0KGtleTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICByZXR1cm4gdGhpcy5jb250ZXh0LndpdGhUcmFjZSh7XG4gICAgICBtZXNzYWdlOiBgR2V0IChrZXk9JHtrZXl9KS5gLFxuICAgICAgYWN0aXZpdHk6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgaGFzaCA9IHRoaXMuaGFzaEtleShrZXkpO1xuICAgICAgICBjb25zdCBmaWxlbmFtZSA9IGpvaW4odGhpcy5maWxlRGlyLCBoYXNoKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gYXdhaXQgZnMucHJvbWlzZXMucmVhZEZpbGUoZmlsZW5hbWUsIFwidXRmOFwiKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIGBPYmplY3QgZG9lcyBub3QgZXhpc3QgKGtleT0ke2tleX0pOiAkeyhlIGFzIEVycm9yKS5zdGFja31gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBhc3luYyBnZXRKc29uKGtleTogc3RyaW5nKTogUHJvbWlzZTxKc29uPiB7XG4gICAgcmV0dXJuIHRoaXMuY29udGV4dC53aXRoVHJhY2Uoe1xuICAgICAgbWVzc2FnZTogYEdldCBKc29uIChrZXk9JHtrZXl9KS5gLFxuICAgICAgYWN0aXZpdHk6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgaGFzaCA9IHRoaXMuaGFzaEtleShrZXkpO1xuICAgICAgICBjb25zdCBmaWxlbmFtZSA9IGpvaW4odGhpcy5maWxlRGlyLCBoYXNoKTtcbiAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoYXdhaXQgZnMucHJvbWlzZXMucmVhZEZpbGUoZmlsZW5hbWUsIFwidXRmOFwiKSk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGxpc3QocHJlZml4Pzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmdbXT4ge1xuICAgIHJldHVybiB0aGlzLmNvbnRleHQud2l0aFRyYWNlKHtcbiAgICAgIG1lc3NhZ2U6IGBMaXN0IChwcmVmaXg9JHtwcmVmaXggPz8gXCJudWxsXCJ9KS5gLFxuICAgICAgYWN0aXZpdHk6IGFzeW5jICgpID0+IHtcbiAgICAgICAgcmV0dXJuIEFycmF5LmZyb20odGhpcy5vYmplY3RLZXlzLnZhbHVlcygpKS5maWx0ZXIoKGtleSkgPT4ge1xuICAgICAgICAgIGlmIChwcmVmaXgpIHtcbiAgICAgICAgICAgIHJldHVybiBrZXkuc3RhcnRzV2l0aChwcmVmaXgpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBhc3luYyBwdWJsaWNVcmwoa2V5OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGlmICghdGhpcy5fcHVibGljKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgcHJvdmlkZSBwdWJsaWMgdXJsIGZvciBhIG5vbi1wdWJsaWMgYnVja2V0XCIpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5jb250ZXh0LndpdGhUcmFjZSh7XG4gICAgICBtZXNzYWdlOiBgUHVibGljIFVSTCAoa2V5PSR7a2V5fSkuYCxcbiAgICAgIGFjdGl2aXR5OiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpbGVQYXRoID0gam9pbih0aGlzLmZpbGVEaXIsIGtleSk7XG5cbiAgICAgICAgaWYgKCF0aGlzLm9iamVjdEtleXMuaGFzKGtleSkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICBgQ2Fubm90IHByb3ZpZGUgcHVibGljIHVybCBmb3IgYW4gbm9uLWV4aXN0ZW50IGtleSAoa2V5PSR7a2V5fSlgXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBmaWxlUGF0aDtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgZGVsZXRlKGtleTogc3RyaW5nLCBvcHRzPzogQnVja2V0RGVsZXRlT3B0aW9ucyk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybiB0aGlzLmNvbnRleHQud2l0aFRyYWNlKHtcbiAgICAgIG1lc3NhZ2U6IGBEZWxldGUgKGtleT0ke2tleX0pLmAsXG4gICAgICBhY3Rpdml0eTogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBtdXN0RXhpc3QgPSBvcHRzPy5tdXN0RXhpc3QgPz8gZmFsc2U7XG5cbiAgICAgICAgaWYgKCF0aGlzLm9iamVjdEtleXMuaGFzKGtleSkgJiYgbXVzdEV4aXN0KSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBPYmplY3QgZG9lcyBub3QgZXhpc3QgKGtleT0ke2tleX0pLmApO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCF0aGlzLm9iamVjdEtleXMuaGFzKGtleSkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBoYXNoID0gdGhpcy5oYXNoS2V5KGtleSk7XG4gICAgICAgIGNvbnN0IGZpbGVuYW1lID0gam9pbih0aGlzLmZpbGVEaXIsIGhhc2gpO1xuICAgICAgICBhd2FpdCBmcy5wcm9taXNlcy51bmxpbmsoZmlsZW5hbWUpO1xuICAgICAgICB0aGlzLm9iamVjdEtleXMuZGVsZXRlKGtleSk7XG4gICAgICAgIGF3YWl0IHRoaXMubm90aWZ5TGlzdGVuZXJzKEJ1Y2tldEV2ZW50VHlwZS5ERUxFVEUsIGtleSk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBhZGRGaWxlKGtleTogc3RyaW5nLCB2YWx1ZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgYWN0aW9uVHlwZTogQnVja2V0RXZlbnRUeXBlID0gdGhpcy5vYmplY3RLZXlzLmhhcyhrZXkpXG4gICAgICA/IEJ1Y2tldEV2ZW50VHlwZS5VUERBVEVcbiAgICAgIDogQnVja2V0RXZlbnRUeXBlLkNSRUFURTtcbiAgICBjb25zdCBoYXNoID0gdGhpcy5oYXNoS2V5KGtleSk7XG4gICAgY29uc3QgZmlsZW5hbWUgPSBqb2luKHRoaXMuZmlsZURpciwgaGFzaCk7XG4gICAgY29uc3QgZGlyTmFtZSA9IGRpcm5hbWUoZmlsZW5hbWUpO1xuICAgIGF3YWl0IGZzLnByb21pc2VzLm1rZGlyKGRpck5hbWUsIHsgcmVjdXJzaXZlOiB0cnVlIH0pO1xuICAgIGF3YWl0IGZzLnByb21pc2VzLndyaXRlRmlsZShmaWxlbmFtZSwgdmFsdWUpO1xuICAgIHRoaXMub2JqZWN0S2V5cy5hZGQoa2V5KTtcbiAgICBhd2FpdCB0aGlzLm5vdGlmeUxpc3RlbmVycyhhY3Rpb25UeXBlLCBrZXkpO1xuICB9XG5cbiAgcHJpdmF0ZSBoYXNoS2V5KGtleTogc3RyaW5nKTogc3RyaW5nIHtcbiAgICByZXR1cm4gY3J5cHRvLmNyZWF0ZUhhc2goXCJzaGE1MTJcIikudXBkYXRlKGtleSkuZGlnZXN0KFwiaGV4XCIpO1xuICB9XG59XG4iXX0=