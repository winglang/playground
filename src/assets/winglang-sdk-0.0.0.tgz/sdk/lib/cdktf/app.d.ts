import { App, AppProps } from "../core/app";
/**
 * An app that knows how to synthesize constructs into Terraform configuration
 * using cdktf. No polycon factory or Terraform providers are included.
 */
export declare abstract class CdktfApp extends App {
    /**
     * Directory where artifacts are synthesized to.
     */
    readonly outdir: string;
    /**
     * Path to the Terraform manifest file.
     */
    readonly terraformManifestPath: string;
    private readonly cdktfApp;
    private readonly cdktfStack;
    private readonly pluginManager;
    private synthed;
    private synthedOutput;
    constructor(props: AppProps);
    /**
     * Synthesize the app into Terraform configuration in a `cdktf.out` directory.
     *
     * This method returns a cleaned snapshot of the resulting Terraform manifest
     * for unit testing.
     */
    synth(): string;
    /**
     * Move files from `outdir/cdktf.out/stacks/root` to `outdir`.
     */
    private moveCdktfArtifactsToOutdir;
}
