import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * GCP implementation of `cloud.Bucket`.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare class Bucket extends cloud.Bucket {
    private readonly bucket;
    constructor(scope: Construct, id: string, props?: cloud.BucketProps);
    addObject(key: string, body: string): void;
    /** @internal */
    _bind(_inflightHost: core.IInflightHost, _ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
