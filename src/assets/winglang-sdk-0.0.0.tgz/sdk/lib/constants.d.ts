export declare const SDK_VERSION: any;
export declare const SDK_PACKAGE_NAME: any;
export declare function fqnForType(type: string): string;
