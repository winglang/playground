/**
 * Immutable Json
 */
export declare class Json {
    /**
     * Returns a specified element from the Json.
     *
     * @macro ($self$)[$args$]
     *
     * @param key The key of the element to return
     * @returns The element associated with the specified key, or undefined if the key can't be found
     */
    get(key: string): Json;
    /**
     * Returns a specified element at a given index from Json Array
     *
     * @macro ($self$)[$args$]
     *
     * @param index The index of the element in the Json Array to return
     * @returns The element at given index in Json Array, or undefined if index is not valid
     */
    getAt(index: number): Json;
}
/**
 * Mutable Json
 */
export declare class MutJson {
    /**
     * Returns a specified element from the Json.
     *
     * @macro ($self$)[$args$]
     *
     * @param key The key of the element to return
     * @returns The element associated with the specified key, or undefined if the key can't be found
     */
    get(key: string): MutJson;
    /**
     * Returns a specified element at a given index from MutJson Array
     *
     * @macro ($self$)[$args$]
     *
     * @param index The index of the element in the MutJson Array to return
     * @returns The element at given index in MutJson Array, or undefined if index is not valid
     */
    getAt(index: number): MutJson;
    /**
     * Adds or updates an element in MutJson with a specific key and value
     *
     * @macro ((obj, args) => { obj[args[0]] = args[1]; })($self$, [$args$])
     *
     * @param key The key of the element to add
     * @param value The value of the element to add
     */
    set(key: string, value: any): void;
    /**
     * Set element in MutJson Array with a specific key and value
     *
     * @macro ((obj, args)) => { obj[args[0]] = args[1]; })($self$, [$args$])
     *
     * @param value The value of the element to set
     */
    setAt(index: number, value: any): void;
}
