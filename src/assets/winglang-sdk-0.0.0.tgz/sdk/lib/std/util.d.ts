/**
 * Generic type argument. This type is replaced at compile time.
 *
 * @hidden
 */
export declare class T1 {
}
