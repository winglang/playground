import { T1 } from "./util";
/**
 * Immutable Set
 *
 * @typeparam T1
 */
export declare class ImmutableSet {
    /**
     * The length of the set
     * @returns the length of the set
     */
    get size(): number;
    /**
     * Returns a boolean indicating whether an element with the specified value exists in the set.
     * @param value The value to test for presence in the Set object.
     * @returns `true` if an element with the specified value exists in the set; otherwise `false`.
     */
    has(value: T1): boolean;
    /**
     * Create a mutable shallow copy of this set
     *
     * @macro new Set($self$)
     *
     * @returns a MutableSet with the same values as this set
     */
    copyMut(): MutableSet;
    /**
     * Create an immutable shallow copy of this set
     *
     * @macro Object.freeze(new Set($self$))
     *
     * @returns an ImmutableSet with the same values as this set
     */
    copy(): ImmutableSet;
}
/**
 * Mutable Set
 *
 * @typeparam T1
 */
export declare class MutableSet extends ImmutableSet {
    /**
     * Add value to set
     * @param value value to add
     * @returns true if the value was added, false if it was already in the set
     */
    add(value: T1): MutableSet;
    /**
     * The clear() method removes all elements from a set.
     */
    clear(): void;
    /**
     * Removes a specified value from a set, if it is in the set.
     * @param value The value to remove from the set.
     * @returns Returns `true` if `value` was already in the set; otherwise `false`.
     */
    delete(value: T1): boolean;
}
