/**
 * String
 */
export declare class String {
    /**
     * The length of the string.
     */
    get length(): number;
    /**
     * Returns the character at the specified index.
     *
     * @param index position of the character.
     * @returns string at the specified index.
     */
    at(index: number): string;
    /**
     * Combines the text of two (or more) strings and returns a new string.
     *
     * @param strN one or more strings to concatenate to this string.
     * @returns a new combined string.
     */
    concat(strN: string): string;
    /**
     * Checks if string includes substring.
     *
     * @macro $self$.includes($args$)
     *
     * @param searchString substring to search for.
     * @returns true if string includes substring.
     */
    contains(searchString: string): boolean;
    /**
     * Does this string end with the given searchString?
     *
     * @macro $self$.endsWith($args$)
     *
     * @param searchString substring to search for.
     * @returns true if string ends with searchString.
     */
    ends(searchString: string): boolean;
    /**
     * Returns the index of the first occurrence of searchString found.
     *
     * @macro $self$.indexOf($args$)
     *
     * @param searchString substring to search for.
     * @returns the index of the first occurrence of searchString found, or -1 if not found.
     */
    indexOf(searchString: string): number;
    /**
     * Returns this string in lower case.
     *
     * @macro $self$.toLocaleLowerCase()
     *
     * @returns a new lower case string.
     */
    lowercase(): string;
    /**
     * Splits string by separator.
     *
     * @param separator separator to split by.
     * @returns array of strings.
     */
    split(separator: string): string[];
    /**
     * Does this string start with the given searchString?
     *
     * @macro $self$.startsWith($args$)
     *
     * @param searchString substring to search for.
     * @returns true if string starts with searchString.
     */
    starts(searchString: string): boolean;
    /**
     * Returns a string between indexStart, indexEnd.
     *
     * @param indexStart index of the character we slice at.
     * @param indexEnd optional - index of the character we end slicing at.
     * @returns the string contained from indexStart to indexEnd.
     */
    substring(indexStart: number, indexEnd?: number): string;
    /**
     * Removes white spaces from start and end of this string.
     *
     * @returns a new string with white spaces removed from start and end.
     */
    trim(): string;
    /**
     * Returns this string in upper case.
     *
     * @macro $self$.toLocaleUpperCase()
     *
     * @returns a new upper case string.
     */
    uppercase(): string;
}
