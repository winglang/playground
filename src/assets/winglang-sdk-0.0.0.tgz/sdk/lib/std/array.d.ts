import { T1 } from "./util";
/**
 * Immutable Array
 *
 * @typeparam T1
 */
export declare class ImmutableArray {
    /**
     * The length of the array
     * @returns the length of the array
     */
    get length(): number;
    /**
     * Get the value at the given index
     * @param index index of the value to get
     * @returns the value at the given index
     */
    at(index: number): T1;
    /**
     * Create a mutable shallow copy of this array
     *
     * @macro [...($self$)]
     *
     * @returns a MutableArray with the same values as this array
     */
    copyMut(): MutableArray;
    /**
     * Create an immutable shallow copy of this array
     *
     * @macro Object.freeze([...($self$)])
     *
     * @returns an ImmutableArray with the same values as this array
     */
    copy(): ImmutableArray;
}
/**
 * Mutable Array
 *
 * @typeparam T1
 */
export declare class MutableArray extends ImmutableArray {
    /**
     * Add value to end of array
     * @param value value to add
     */
    push(value: T1): void;
    /**
     * Remove value from end of array
     * @returns the value removed
     */
    pop(): T1;
}
