import type { IFunctionHandlerClient, IScheduleOnTickHandlerClient } from "../cloud";
export declare class ScheduleOnTickHandlerClient implements IScheduleOnTickHandlerClient {
    private readonly handler;
    constructor({ handler }: {
        handler: IFunctionHandlerClient;
    });
    handle(): Promise<void>;
}
