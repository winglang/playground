import type { IFunctionHandlerClient, ITopicOnMessageHandlerClient } from "../cloud";
export declare class TopicOnMessageHandlerClient implements ITopicOnMessageHandlerClient {
    private readonly handler;
    constructor({ handler }: {
        handler: IFunctionHandlerClient;
    });
    handle(event: any): Promise<void>;
}
