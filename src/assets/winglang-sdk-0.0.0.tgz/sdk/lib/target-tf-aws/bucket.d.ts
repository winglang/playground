import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
import { NameOptions } from "../utils/resource-names";
/**
 * Bucket prefix provided to Terraform must be between 3 and 37 characters.
 *
 * Bucket names are allowed to contain lowercase alphanumeric characters and
 * dashes (-). We generate names without dots (.) to avoid some partial
 * restrictions on bucket names with dots.
 */
export declare const BUCKET_PREFIX_OPTS: NameOptions;
/**
 * AWS implementation of `cloud.Bucket`.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare class Bucket extends cloud.Bucket {
    private readonly bucket;
    private readonly public;
    constructor(scope: Construct, id: string, props?: cloud.BucketProps);
    addObject(key: string, body: string): void;
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
}
