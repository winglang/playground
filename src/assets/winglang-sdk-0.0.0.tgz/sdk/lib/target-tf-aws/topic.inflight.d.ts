import { SNSClient } from "@aws-sdk/client-sns";
import { ITopicClient } from "../cloud";
export declare class TopicClient implements ITopicClient {
    private readonly topicArn;
    private readonly client;
    constructor(topicArn: string, client?: SNSClient);
    publish(message: string): Promise<void>;
}
