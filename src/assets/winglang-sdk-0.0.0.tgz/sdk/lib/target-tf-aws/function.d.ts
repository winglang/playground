import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * AWS implementation of `cloud.Function`.
 *
 * @inflight `@winglang/sdk.cloud.IFunctionClient`
 */
export declare class Function extends cloud.Function {
    private readonly function;
    private readonly role;
    private policyStatements?;
    /**
     * Unqualified Function ARN
     * @returns Unqualified ARN of the function
     */
    readonly arn: string;
    /**
     * Qualified Function ARN
     * @returns Qualified ARN of the function
     */
    readonly qualifiedArn: string;
    constructor(scope: Construct, id: string, inflight: cloud.IFunctionHandler, props?: cloud.FunctionProps);
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    /**
     * Add a policy statement to the Lambda role.
     */
    addPolicyStatements(...statements: PolicyStatement[]): void;
    /**
     * Grants the given identity permissions to invoke this function.
     * @param principal The AWS principal to grant invoke permissions to (e.g. "s3.amazonaws.com", "events.amazonaws.com", "sns.amazonaws.com")
     */
    addPermissionToInvoke(source: core.Resource, principal: string, sourceArn: string): void;
    /** @internal */
    get _functionName(): string;
    private envName;
}
/**
 * AWS IAM Policy Statement.
 */
export interface PolicyStatement {
    /** Actions */
    readonly action?: string[];
    /** Resources */
    readonly resource?: string[] | string;
    /** Effect ("Allow" or "Deny") */
    readonly effect?: string;
}
