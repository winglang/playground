import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
export declare const HASH_KEY = "id";
/**
 * AWS implementation of `cloud.Counter`.
 *
 * @inflight `@winglang/sdk.cloud.ICounterClient`
 */
export declare class Counter extends cloud.Counter {
    private readonly table;
    constructor(scope: Construct, id: string, props?: cloud.CounterProps);
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
}
