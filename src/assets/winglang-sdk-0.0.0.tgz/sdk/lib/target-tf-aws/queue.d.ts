import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * AWS implementation of `cloud.Queue`.
 *
 * @inflight `@winglang/sdk.cloud.IQueueClient`
 */
export declare class Queue extends cloud.Queue {
    private readonly queue;
    constructor(scope: Construct, id: string, props?: cloud.QueueProps);
    onMessage(inflight: core.Inflight, // cloud.IQueueOnMessageHandler
    props?: cloud.QueueOnMessageProps): cloud.Function;
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
}
