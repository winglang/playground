import { S3Client } from "@aws-sdk/client-s3";
import { BucketDeleteOptions, IBucketClient } from "../cloud";
import { Json } from "../std";
export declare class BucketClient implements IBucketClient {
    private readonly bucketName;
    private readonly s3Client;
    constructor(bucketName: string, s3Client?: S3Client);
    put(key: string, body: string): Promise<void>;
    putJson(key: string, body: Json): Promise<void>;
    get(key: string): Promise<string>;
    getJson(key: string): Promise<Json>;
    /**
     * List all keys in the bucket.
     * @param prefix Limits the response to keys that begin with the specified prefix
     * TODO - add pagination support, currently returns all existing keys in the bucket
     */
    list(prefix?: string): Promise<string[]>;
    /**
     * Delete an existing object using a key from the bucket
     * @param key Key of the object.
     * @param opts Option object supporting additional strategies to delete an item from a bucket
     */
    delete(key: string, opts?: BucketDeleteOptions): Promise<void>;
}
