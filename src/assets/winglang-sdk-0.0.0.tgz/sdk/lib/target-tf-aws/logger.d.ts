import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * AWS implementation of `cloud.Logger`.
 *
 * @inflight `@winglang/sdk.cloud.ILoggerClient`
 */
export declare class Logger extends cloud.Logger {
    constructor(scope: Construct, id: string);
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
