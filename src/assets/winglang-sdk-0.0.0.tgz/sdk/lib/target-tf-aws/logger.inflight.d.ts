import { ILoggerClient } from "../cloud";
export declare class LoggerClient implements ILoggerClient {
    constructor();
    print(message: string): void;
}
