import { Construct } from "constructs";
import { CdktfApp } from "../cdktf/app";
import { AppProps } from "../core";
/**
 * An app that knows how to synthesize constructs into a Terraform configuration
 * for AWS resources.
 */
export declare class App extends CdktfApp {
    constructor(props?: AppProps);
    protected tryNew(fqn: string, scope: Construct, id: string, ...args: any[]): any;
}
