import { LambdaClient } from "@aws-sdk/client-lambda";
import { IFunctionClient } from "../cloud";
export declare class FunctionClient implements IFunctionClient {
    private readonly functionArn;
    private readonly lambdaClient;
    constructor(functionArn: string, lambdaClient?: LambdaClient);
    /**
     * Invoke the function, passing the given payload as an argument.
     */
    invoke(payload: string): Promise<string>;
}
