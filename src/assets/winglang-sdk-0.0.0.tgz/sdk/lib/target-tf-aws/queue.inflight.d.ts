import { SQSClient } from "@aws-sdk/client-sqs";
import { IQueueClient } from "../cloud";
export declare class QueueClient implements IQueueClient {
    private readonly queueUrl;
    private readonly client;
    constructor(queueUrl: string, client?: SQSClient);
    push(message: string): Promise<void>;
    purge(): Promise<void>;
    approxSize(): Promise<number>;
}
