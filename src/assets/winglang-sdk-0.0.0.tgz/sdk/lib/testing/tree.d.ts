import { ConstructTree } from "../core";
/**
 * Tree metadata associated with a Wing application. Provides information
 * about resources and their relationships.
 */
export declare class Tree {
    private data;
    constructor(data: ConstructTree);
    /**
     * Returns the raw tree data.
     */
    rawData(): ConstructTree;
}
