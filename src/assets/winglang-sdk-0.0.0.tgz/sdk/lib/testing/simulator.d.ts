import { Tree } from "./tree";
import { ISimulatorResourceInstance } from "../target-sim";
import { BaseResourceSchema } from "../target-sim/schema";
/**
 * Props for `Simulator`.
 */
export interface SimulatorProps {
    /**
     * Path to a Wing simulator file (.wsim).
     */
    readonly simfile: string;
    /**
     * The factory that produces resource simulations.
     *
     * @default - a factory that produces simulations for built-in Wing SDK
     * resources
     */
    readonly factory?: ISimulatorFactory;
}
/**
 * A collection of callbacks that are invoked at key lifecycle events of the
 * simulator.
 */
export interface ISimulatorLifecycleHooks {
    /**
     * A function to run whenever a trace is emitted.
     */
    onTrace?(event: Trace): void;
}
/**
 * Props for `ISimulatorContext.withTrace`.
 */
export interface IWithTraceProps {
    /**
     * The trace message.
     */
    readonly message: any;
    /**
     * A function to run as part of the trace.
     */
    activity(): Promise<any>;
}
/**
 * Represents an trace emitted during simulation.
 */
export interface Trace {
    /**
     * A JSON blob with structured data.
     */
    readonly data: any;
    /**
     * The type of the source that emitted the trace.
     */
    readonly sourceType: string;
    /**
     * The path of the resource that emitted the trace.
     */
    readonly sourcePath: string;
    /**
     * The type of a trace.
     */
    readonly type: TraceType;
    /**
     * The timestamp of the event, in ISO 8601 format.
     * @example 2020-01-01T00:00:00.000Z
     */
    readonly timestamp: string;
}
/**
 * The type of a trace.
 */
export declare enum TraceType {
    /**
     * A trace representing a resource activity.
     */
    RESOURCE = "resource",
    /**
     * A trace representing information emitted by the logger.
     */
    LOG = "log"
}
/**
 * Context that is passed to individual resource simulations.
 */
export interface ISimulatorContext {
    /**
     * The directory where all assets extracted from `.wsim` file are stored
     * during the simulation run.
     */
    readonly assetsDir: string;
    /**
     * The path of the resource that is being simulated.
     */
    readonly resourcePath: string;
    /**
     * Find a resource simulation by its handle. Throws if the handle isn't valid.
     */
    findInstance(handle: string): ISimulatorResourceInstance;
    /**
     * Add a trace. Traces are breadcrumbs of information about resource
     * operations that occurred during simulation, useful for understanding how
     * resources interact or debugging an application.
     */
    addTrace(trace: Trace): void;
    /**
     * Register a trace associated with a resource activity. The activity will be
     * run, and the trace will be populated with the result's success or failure.
     */
    withTrace(trace: IWithTraceProps): Promise<any>;
}
/**
 * A subscriber that can listen for traces emitted by the simulator.
 */
export interface ITraceSubscriber {
    /**
     * Called when a trace is emitted.
     */
    callback(event: Trace): void;
}
/**
 * A simulator that can be used to test your application locally.
 */
export declare class Simulator {
    private readonly _factory;
    private _config;
    private readonly _simfile;
    private _assetsDir;
    private _running;
    private readonly _handles;
    private _traces;
    private readonly _traceSubscribers;
    private _tree;
    constructor(props: SimulatorProps);
    private _loadApp;
    /**
     * Start the simulator.
     */
    start(): Promise<void>;
    /**
     * Stop the simulation and clean up all resources.
     */
    stop(): Promise<void>;
    /**
     * Stop the simulation, reload the simulation tree from the latest version of
     * the app file, and restart the simulation.
     */
    reload(): Promise<void>;
    /**
     * Get a list of all resource paths.
     */
    listResources(): string[];
    /**
     * Get a list of all traces from the most recent simulation run.
     */
    listTraces(): Trace[];
    /**
     * Get a simulated resource instance.
     * @returns the resource
     */
    getResource(path: string): any;
    /**
     * Get a simulated resource instance.
     * @returns The resource of undefined if not found
     */
    tryGetResource(path: string): any | undefined;
    /**
     * Obtain a resource's configuration, including its type, props, and attrs.
     * @returns The resource configuration or undefined if not found
     */
    tryGetResourceConfig(path: string): BaseResourceSchema | undefined;
    /**
     * Obtain a resource's configuration, including its type, props, and attrs.
     * @param path The resource path
     * @returns The resource configuration
     */
    getResourceConfig(path: string): BaseResourceSchema;
    /**
     * Register a subscriber that will be notified when a trace is emitted by
     * the simulator.
     */
    onTrace(subscriber: ITraceSubscriber): void;
    /**
     * Lists all resource with identifier "test" or that start with "test:*".
     * @returns A list of resource paths
     */
    listTests(): string[];
    /**
     * Run all tests in the simulation tree.
     *
     * A test is a `cloud.Function` resource with an identifier that starts with "test." or is "test".
     * @returns A list of test results.
     */
    runAllTests(): Promise<TestResult[]>;
    /**
     * Runs a single test.
     * @param path The path to a cloud.Function resource that repersents the test
     * @returns The result of the test
     */
    runTest(path: string): Promise<TestResult>;
    /**
     * Obtain information about the application's resource tree.
     */
    tree(): Tree;
    private _addTrace;
    /**
     * Return an object with all tokens in it resolved to their appropriate
     * values.
     *
     * A token can be a string like "${app/my_bucket#attrs.handle}". This token
     * would be resolved to the "handle" attribute of the resource at path
     * "app/my_bucket". If that attribute does not exist at the time of resolution
     * (for example, if my_bucket is not being simulated yet), an error will be
     * thrown.
     *
     * Tokens can also be nested, like "${app/my_bucket#attrs.handle}/foo/bar".
     *
     * @param obj The object to resolve tokens in.
     * @param source The path of the resource that requested the token to be resolved.
     */
    private resolveTokens;
}
/**
 * A factory that can turn resource descriptions into (inflight) resource simulations.
 */
export interface ISimulatorFactory {
    /**
     * Resolve the parameters needed for creating a specific resource simulation.
     */
    resolve(type: string, props: any, context: ISimulatorContext): ISimulatorResourceInstance;
}
/**
 * A result of a single test.
 */
export interface TestResult {
    /**
     * The path to the test function.
     */
    readonly path: string;
    /**
     * Whether the test passed.
     */
    readonly pass: boolean;
    /**
     * The error message if the test failed.
     */
    readonly error?: string;
    /**
     * List of traces emitted during the test.
     */
    readonly traces: Trace[];
}
