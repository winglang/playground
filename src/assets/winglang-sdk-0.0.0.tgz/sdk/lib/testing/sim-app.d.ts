import { Simulator } from ".";
import * as sim from "../target-sim";
/**
 * A simulated app.
 *
 * A great way to write unit tests for the cloud. Just use this as your base app
 * and then call `app.startSimulator()` to start an instance of this app inside
 * a cloud simulator.
 */
export declare class SimApp extends sim.App {
    private _synthesized;
    constructor();
    /**
     * Creates a simulator and starts it.
     *
     * @returns A started `Simulator` instance. No need to call `start()` again.
     */
    startSimulator(): Promise<Simulator>;
    /**
     * Takes a snapshot of the output directory, returning a map of filenames to
     * their contents.
     */
    snapshot(): Record<string, any>;
    private synthIfNeeded;
}
