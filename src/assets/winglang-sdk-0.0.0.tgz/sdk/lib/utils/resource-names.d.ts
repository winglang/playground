import { Construct } from "constructs";
export declare enum CaseConventions {
    LOWERCASE = "lowercase",
    UPPERCASE = "uppercase"
}
/**
 * Options for `ResourceNames.generateName`
 */
export interface NameOptions {
    /**
     * Maximum length for the generated name. The length must at least the length
     * of the hash (8 characters).
     * @default - no maximum length
     */
    readonly maxLen?: number;
    /**
     * Regular expression that indicates which characters are invalid. Each group
     * of characters will be replaced with `sep`.
     */
    readonly disallowedRegex: RegExp;
    /**
     * Word breaker
     * @default "-"
     */
    readonly sep?: string;
    /**
     * Convert the generated name to all uppercase or all lowercase.
     * @default - apply no case conversion
     */
    readonly case?: CaseConventions;
    /**
     * Apply a predefined prefix to the generated name
     * @default - no prefix
     */
    readonly prefix?: string;
    /**
     * Apply a predefined suffix to the generated name
     * @default - no suffix
     */
    readonly suffix?: string;
    /**
     * Include a hash of the resource's address in the generated name.
     *
     * This should only be disabled if the resource's name is guaranteed to be
     * app-unique, or if some other source of randomness will be appended to the
     * name.
     *
     * @default true
     */
    readonly includeHash?: boolean;
}
export declare class ResourceNames {
    static generateName(resource: Construct, props: NameOptions): string;
}
