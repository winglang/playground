import { Construct } from "constructs";
import { FileBase } from "../core";
/**
 * Props for `TextFile`.
 */
export interface TextFileProps {
    /**
     * The lines of text that will be serialized into the file during synthesis.
     * They will be joined with newline characters.
     *
     * @default []
     */
    readonly lines?: string[];
}
/**
 * Represents a text file that should be synthesized in the app's outdir.
 */
export declare class TextFile extends FileBase {
    private readonly lines;
    constructor(scope: Construct, id: string, filePath: string, props?: TextFileProps);
    /**
     * Append a line to the text file's contents.
     */
    addLine(line: string): void;
    protected render(): string;
}
