import { Construct } from "constructs";
import { FileBase } from "../core";
/**
 * Props for `JsonFile`.
 */
export interface JsonFileProps {
    /**
     * The object that will be serialized into the file during synthesis.
     */
    readonly obj: any;
}
/**
 * Represents a text file that should be synthesized in the app's outdir.
 */
export declare class JsonFile extends FileBase {
    private readonly obj;
    constructor(scope: Construct, id: string, filePath: string, props: JsonFileProps);
    protected render(): string;
}
