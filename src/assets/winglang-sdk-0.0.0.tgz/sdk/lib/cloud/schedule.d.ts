import { Construct } from "constructs";
import { Function, FunctionProps } from "./function";
import { IResource, Inflight, Resource } from "../core";
import { Duration } from "../std";
/**
 * Global identifier for `Schedule`.
 */
export declare const SCHEDULE_FQN: string;
/**
 * Properties for `Schedule`.
 */
export interface ScheduleProps {
    /**
     * Trigger events at a periodic rate.
     * @example 1m
     * @default undefined
     */
    readonly rate?: Duration;
    /**
     * Trigger events according to a cron schedule using the UNIX cron format.
     * [minute] [hour] [day of month] [month] [day of week]
     * @example "0/1 * ? * *"
     * @default undefined
     */
    readonly cron?: string;
}
/**
 * Represents a schedule.
 *
 * @inflight `@winglang/sdk.cloud.IScheduleClient`
 */
export declare abstract class Schedule extends Resource {
    /**
     * Create a new schedule.
     * @internal
     */
    static _newSchedule(scope: Construct, id: string, props?: ScheduleProps): Schedule;
    readonly stateful = true;
    constructor(scope: Construct, id: string, props?: ScheduleProps);
    /**
     * Create a function that runs when receiving the scheduled event.
     */
    abstract onTick(inflight: Inflight, props?: ScheduleOnTickProps): Function;
}
/**
 * Options for Schedule.onTick.
 */
export interface ScheduleOnTickProps extends FunctionProps {
}
/**
 * Represents a resource with an inflight "handle" method that can be passed to
 * `Schedule.on_tick`.
 *
 * @inflight `wingsdk.cloud.IScheduleOnTickHandlerClient`
 */
export interface IScheduleOnTickHandler extends IResource {
}
/**
 * Inflight client for `IScheduleOnTickHandler`.
 */
export interface IScheduleOnTickHandlerClient {
    /**
     * Function that will be called when a message is received from the schedule.
     * @inflight
     */
    handle(): Promise<void>;
}
