import { Construct, IConstruct } from "constructs";
import { Resource } from "../core/resource";
export declare const LOGGER_FQN: string;
/**
 * A cloud logging facility.
 *
 * @inflight `@winglang/sdk.cloud.ILoggerClient`
 */
export declare abstract class Logger extends Resource {
    /**
     * Returns the logger registered to the given scope, throwing an error if
     * there is none.
     */
    static of(scope: IConstruct): Logger;
    /**
     * Create a logger and register it to the given scope.
     */
    static register(scope: IConstruct): void;
    readonly stateful = true;
    constructor(scope: Construct, id: string);
}
/**
 * Inflight interface for `Logger`.
 */
export interface ILoggerClient {
    /**
     * Logs a message. The log will be associated with whichever resource is
     * running the inflight code.
     *
     * NOTICE: this is not an async function because it is wrapped by `console.log()`.
     *
     * @param message The message to print
     * @inflight
     */
    print(message: string): void;
}
/**
 * List of inflight operations available for `Logger`.
 * @internal
 */
export declare enum LoggerInflightMethods {
    /** `Logger.print` */
    PRINT = "print"
}
