import { Construct } from "constructs";
import { Resource } from "../core";
import { Json } from "../std";
/**
 * Global identifier for `Bucket`.
 */
export declare const BUCKET_FQN: string;
/**
 * Properties for `Bucket`.
 */
export interface BucketProps {
    /**
     * Whether the bucket's objects should be publicly accessible.
     * @default false
     */
    readonly public?: boolean;
}
/**
 * Represents a cloud object store.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare abstract class Bucket extends Resource {
    /**
     * Create a new bucket.
     * @internal
     */
    static _newBucket(scope: Construct, id: string, props?: BucketProps): Bucket;
    readonly stateful = true;
    constructor(scope: Construct, id: string, props?: BucketProps);
    /**
     * Add a file to the bucket that is uploaded when the app is deployed.
     *
     * TODO: In the future this will support uploading any `Blob` type or
     * referencing a file from the local filesystem.
     */
    abstract addObject(key: string, body: string): void;
}
/** Interface for delete method inside `Bucket` */
export interface BucketDeleteOptions {
    /**
     * Check failures on the method and retrieve errors if any
     * @Throws if this is `true`, an error is thrown if the file is not found (or any error case).
     * @default false
     */
    readonly mustExist?: boolean;
}
/**
 * Inflight interface for `Bucket`.
 */
export interface IBucketClient {
    /**
     * Put an object in the bucket.
     * @param key Key of the object.
     * @param body Content of the object we want to store into the bucket.
     * @inflight
     */
    put(key: string, body: string): Promise<void>;
    /**
     * Put a Json object in the bucket.
     * @param key Key of the object.
     * @param body Json object that we want to store into the bucket.
     * @inflight
     */
    putJson(key: string, body: Json): Promise<void>;
    /**
     * Retrieve an object from the bucket.
     * @param key Key of the object.
     * @Throws if no object with the given key exists.
     * @Returns the object's body.
     * @inflight
     */
    get(key: string): Promise<string>;
    /**
     * Retrieve a Json object from the bucket.
     * @param key Key of the object.
     * @Throws if no object with the given key exists.
     * @Returns the object's parsed Json.
     * @inflight
     */
    getJson(key: string): Promise<Json>;
    /**
     * Retrieve existing objects keys from the bucket.
     * @param prefix Limits the response to keys that begin with the specified prefix.
     * @returns a list of keys or an empty array if the bucket is empty.
     * @inflight
     */
    list(prefix?: string): Promise<string[]>;
    /**
     * Delete an existing object using a key from the bucket
     * @param key Key of the object.
     * @param opts Options available for delete an item from a bucket.
     * @inflight
     */
    delete(key: string, opts?: BucketDeleteOptions): Promise<void>;
}
/**
 * List of inflight operations available for `Bucket`.
 * @internal
 */
export declare enum BucketInflightMethods {
    /** `Bucket.put` */
    PUT = "put",
    /** `Bucket.get` */
    GET = "get",
    /** `Bucket.list` */
    LIST = "list",
    /** `Bucket.delete` */
    DELETE = "delete",
    /** `Bucket.putJson */
    PUT_JSON = "putJson",
    /** `Bucket.getJson */
    GET_JSON = "getJson"
}
