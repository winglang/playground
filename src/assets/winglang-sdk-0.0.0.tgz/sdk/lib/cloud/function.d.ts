import { Construct } from "constructs";
import { IInflightHost, IResource, Inflight, Resource } from "../core";
import { Duration } from "../std";
/**
 * Global identifier for `Function`.
 */
export declare const FUNCTION_FQN: string;
/**
 * Properties for `Function`.
 *
 * This is the type users see when constructing a cloud.Function instance.
 */
export interface FunctionProps {
    /**
     * Environment variables to pass to the function.
     * @default - No environment variables.
     */
    readonly env?: {
        [key: string]: string;
    };
    /**
     * The maximum amount of time the function can run.
     * @default 1m
     */
    readonly timeout?: Duration;
    /**
     * The amount of memory to allocate to the function, in MB.
     * @default 128
     */
    readonly memory?: number;
}
/**
 * Represents a function.
 *
 * @inflight `@winglang/sdk.cloud.IFunctionClient`
 */
export declare abstract class Function extends Resource implements IInflightHost {
    /**
     * Creates a new cloud.Function instance through the app.
     * @internal
     */
    static _newFunction(scope: Construct, id: string, inflight: Inflight, props?: FunctionProps): Function;
    private readonly _env;
    readonly stateful = false;
    /**
     * The path to the file asset that contains the handler code.
     */
    protected readonly assetPath: string;
    constructor(scope: Construct, id: string, inflight: Inflight, props?: FunctionProps);
    /**
     * Add an environment variable to the function.
     */
    addEnvironment(name: string, value: string): void;
    /**
     * Returns the set of environment variables for this function.
     */
    get env(): Record<string, string>;
}
/**
 * Inflight interface for `Function`.
 */
export interface IFunctionClient {
    /**
     * Invoke the function asynchronously with a given payload.
     * @inflight
     */
    invoke(payload: string): Promise<string>;
}
/**
 * Represents a resource with an inflight "handle" method that can be used to
 * create a `cloud.Function`.
 *
 * @inflight `wingsdk.cloud.IFunctionHandlerClient`
 */
export interface IFunctionHandler extends IResource {
}
/**
 * Inflight client for `IFunctionHandler`.
 */
export interface IFunctionHandlerClient {
    /**
     * Entrypoint function that will be called when the cloud function is invoked.
     * @inflight
     */
    handle(event: string): Promise<void>;
}
/**
 * List of inflight operations available for `Function`.
 * @internal
 */
export declare enum FunctionInflightMethods {
    /** `Function.invoke` */
    INVOKE = "invoke"
}
