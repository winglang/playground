import { Construct } from "constructs";
import { Function } from "./function";
import { IResource, Inflight, Resource } from "../core";
export declare const TOPIC_FQN: string;
/**
 * Properties for `Topic`.
 */
export interface TopicProps {
}
/**
 * Represents a topic.
 *
 * @inflight `@winglang/sdk.cloud.ITopicClient`
 */
export declare abstract class Topic extends Resource {
    /**
     * Create a new topic.
     * @internal
     */
    static _newTopic(scope: Construct, id: string, props?: TopicProps): Topic;
    readonly stateful = true;
    constructor(scope: Construct, id: string, props?: TopicProps);
    /**
     * Run an inflight whenever an message is published to the topic.
     */
    abstract onMessage(inflight: Inflight, props?: TopicOnMessageProps): Function;
}
/**
 * Options for `Topic.onMessage`.
 */
export interface TopicOnMessageProps {
}
/**
 * Inflight interface for `Topic`.
 */
export interface ITopicClient {
    /**
     * Publish message to topic
     * @param message Payload to publish to Topic
     * @inflight
     */
    publish(message: string): Promise<void>;
}
/**
 * Represents a resource with an inflight "handle" method that can be passed to
 * `Topic.on_message`.
 *
 * @inflight `wingsdk.cloud.ITopicOnMessageHandlerClient`
 */
export interface ITopicOnMessageHandler extends IResource {
}
/**
 * Inflight client for `ITopicOnMessageHandler`.
 */
export interface ITopicOnMessageHandlerClient {
    /**
     * Function that will be called when a message is received from the topic.
     * @inflight
     */
    handle(event: string): Promise<void>;
}
/**
 * List of inflight operations available for `Topic`.
 * @internal
 */
export declare enum TopicInflightMethods {
    /** `Topic.publish` */
    PUBLISH = "publish"
}
