import { Construct } from "constructs";
import { IResource } from "./core";
/**
 * Convert a resource with a single method into a resource with a different
 * single method. This is useful for converting between types like
 * IFunctionHandler and IQueueOnMessageHandler.
 *
 * Both the input and return values of this function are expected to be
 * resources with a single method named "handle".
 */
export declare function convertBetweenHandlers(scope: Construct, id: string, baseHandler: IResource, newHandlerClientPath: string, newHandlerClientClassName: string): IResource;
