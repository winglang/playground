import { Code } from "./core";
/**
 * Path of the simulator configuration file in every .wsim tarball.
 */
export declare const SIMULATOR_FILE_PATH = "simulator.json";
export declare const log: import("debug").Debugger;
export declare function mkdtemp(): string;
export declare function readJsonSync(file: string): any;
export interface SanitizeOptions {
    /**
     * Do not include empty objects (no keys).
     * @default false
     */
    readonly filterEmptyObjects?: boolean;
    /**
     * Do not include arrays with no items.
     * @default false
     */
    readonly filterEmptyArrays?: boolean;
    /**
     * Sort dictionary keys.
     * @default true
     */
    readonly sortKeys?: boolean;
}
export declare function sanitizeValue(obj: any, options?: SanitizeOptions): any;
export declare function directorySnapshot(initialRoot: string): Record<string, any>;
/**
 * Normalize windows paths to be posix-like.
 */
export declare function normalPath(path: string): string;
/**
 * Sanitize the text of a code bundle to remove path references that are system-specific.
 */
export declare function sanitizeCodeText(code: string): string;
export declare function sanitizeCode(code: Code): string;
