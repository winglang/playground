import { StorageContainer } from "@cdktf/provider-azurerm/lib/storage-container";
import { Construct } from "constructs";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * Azure bult-in storage account permissions.
 */
export declare enum StorageAccountPermissions {
    /** Read only permission */
    READ = "Storage Blob Data Reader",
    /** Read write permission */
    READ_WRITE = "Storage Blob Data Contributor"
}
/**
 * Azure implementation of `cloud.Bucket`.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare class Bucket extends cloud.Bucket {
    /** Storage container */
    readonly storageContainer: StorageContainer;
    private readonly public;
    private readonly storageAccount;
    constructor(scope: Construct, id: string, props?: cloud.BucketProps);
    addObject(key: string, body: string): void;
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    private envName;
    private envStorageAccountName;
}
