import { ResourceGroup } from "@cdktf/provider-azurerm/lib/resource-group";
import { ServicePlan } from "@cdktf/provider-azurerm/lib/service-plan";
import { StorageAccount } from "@cdktf/provider-azurerm/lib/storage-account";
import { Construct } from "constructs";
import { CdktfApp } from "../cdktf";
import { AppProps } from "../core";
/**
 * Azure app props
 */
export interface AzureAppProps extends AppProps {
    /** Location for resources to be deployed to */
    readonly location: string;
}
/**
 * An app that knows how to synthesize constructs into a Terraform configuration
 * for Azure resources.
 */
export declare class App extends CdktfApp {
    /**
     * The location context of the App
     * @link https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group#location
     * */
    readonly location: string;
    private _resourceGroup?;
    private _storageAccount?;
    private _servicePlan?;
    constructor(props: AzureAppProps);
    /**
     * Get resource group using lazy initialization
     */
    get resourceGroup(): ResourceGroup;
    /**
     * Get storage account using lazy initialization
     */
    get storageAccount(): StorageAccount;
    /**
     * Get service plan using lazy initialization
     */
    get servicePlan(): ServicePlan;
    protected tryNew(fqn: string, scope: Construct, id: string, ...args: any[]): any;
}
