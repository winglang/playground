import * as cloud from "../cloud";
import * as core from "../core";
/**
 * Azure implementation of `cloud.Logger`
 *
 * @inflight `@winglang/sdk.cloud.ILoggerClient`
 */
export declare class Logger extends cloud.Logger {
    /** @internal */
    _toInflight(): core.Code;
}
