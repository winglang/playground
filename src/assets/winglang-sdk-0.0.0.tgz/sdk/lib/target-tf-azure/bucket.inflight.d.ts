import { BlobServiceClient } from "@azure/storage-blob";
import { BucketDeleteOptions, IBucketClient } from "../cloud";
import { Json } from "../std";
export declare class BucketClient implements IBucketClient {
    private readonly bucketName;
    private readonly blobServiceClient;
    private readonly containerClient;
    private readonly defaultAzureCredential;
    constructor(bucketName: string, storageAccount: string, blobServiceClient?: BlobServiceClient);
    /**
     * Put object into bucket with given body contents
     *
     * @param key Key of the object
     * @param body string contents of the object
     */
    put(key: string, body: string): Promise<void>;
    /**
     * Put Json object into bucket with given body contents
     *
     * @param key Key of the object
     * @param body Json object
     */
    putJson(key: string, body: Json): Promise<void>;
    /**
     * Get object content from bucket
     *
     * @param key Key of the object
     * @returns string content of the object as string
     */
    get(key: string): Promise<string>;
    /**
     * Get object content from bucket as Json
     *
     * @param key Key of the object
     * @returns Json content of the object
     */
    getJson(key: string): Promise<Json>;
    /**
     * List all keys in the bucket
     *
     * @param prefix Limits the response to keys that begin with the specified prefix
     * TODO - add pagination support
     */
    list(prefix?: string): Promise<string[]>;
    /**
     * Delete an existing object using a key from the bucket
     *
     * @param key Key of the object
     * @param opts Option object supporting additional strategies to delete item from a bucket
     */
    delete(key: string, opts?: BucketDeleteOptions): Promise<void>;
    /**
     * Required helper function for node js only.
     *
     * See https://github.com/Azure/azure-sdk-for-js/tree/main/sdk/storage/storage-blob
     */
    private streamToBuffer;
}
