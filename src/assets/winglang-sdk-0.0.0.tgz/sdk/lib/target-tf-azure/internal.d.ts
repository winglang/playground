export declare const APP_AZURE_TF_SYMBOL: unique symbol;
