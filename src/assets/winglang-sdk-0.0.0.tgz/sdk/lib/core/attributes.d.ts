export declare const WING_ATTRIBUTE_RESOURCE_STATEFUL = "wing:resource:stateful";
export declare const WING_ATTRIBUTE_RESOURCE_CONNECTIONS = "wing:resource:connections";
