import { IConstruct } from "constructs";
import { InflightBindings } from "./inflight";
import { DisplayProps, Resource } from "./resource";
export declare function makeHandler(scope: IConstruct, id: string, code: string, bindings?: InflightBindings, display?: DisplayProps): Resource;
export declare function serializeImmutableData(obj: any): string;
