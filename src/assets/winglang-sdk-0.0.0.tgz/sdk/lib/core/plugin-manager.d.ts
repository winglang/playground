import { IConstruct } from "constructs";
/**
 * Behavioral interface of a plugin hook.
 */
export interface ICompilationHook {
    /**
     *  name of plugin can be set by plugin as export
     *
     * @default - absolute path to plugin file
     */
    name: string;
    /** preSynth hook */
    preSynth?(app: IConstruct): void;
    /** postSynth hook */
    postSynth?(config: any): any;
    /** validate hook */
    validate?(config: any): void;
}
/**
 * Plugin manager is responsible for loading hooks from plugins and
 * managing their execution during compilation process.
 */
export declare class PluginManager {
    private hooks;
    constructor(plugins: string[]);
    /**
     * Add plugins to the plugin manager based on the plugin type.
     *
     * @param pluginAbsolutePath the plugin to add
     */
    add(pluginAbsolutePath: string): void;
    /**
     * Call all preSynth hooks
     *
     * This phase is mutable, allowing plugins to modify the app construct
     * before any synthesis takes place.
     *
     * @param app app construct to be passed to the preSynth hooks
     */
    preSynth(app: IConstruct): void;
    /**
     * Call all postSynth hooks
     *
     * This hook is mutable, allowing plugins to modify the Terraform config
     * after synthesis has occurred then overwrite the config file on disk
     * with the modified one.
     *
     * @param config Terraform config to be passed to the postSyth hooks
     * @param synthesizedStackPath path to the synthesized stack json file
     */
    postSynth(config: any, synthesizedStackPath: string): any;
    /**
     * Call all validate hooks
     *
     * This hook is immutable, allowing plugins to perform validations
     * on the Terraform config after all modifications have been made.
     *
     * @param config Terraform config to be passed to the validate hooks
     */
    validate(config: any): void;
    private callAllHooks;
}
