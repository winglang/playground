import { Construct } from "constructs";
/**
 * Represents a file to be synthesized in the app's output directory.
 */
export declare abstract class FileBase extends Construct {
    /**
     * The file's relative path to the output directory.
     */
    readonly filePath: string;
    /**
     * Defines a file
     * @param scope construct scope
     * @param id construct id
     * @param filePath relative file path
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, filePath: string);
    /**
     * Render the contents of the file and save it to the user's file system.
     */
    save(outdir: string): void;
    /**
     * Returns the contents of the file to save.
     */
    protected abstract render(): string;
}
