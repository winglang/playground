import { App } from "./app";
/**
 * Props for `Files`.
 */
export interface FilesProps {
    /**
     * The app with files to synthesize.
     */
    readonly app: App;
    /**
     * The path to a state file which will track all synthesized files. If a
     * statefile is not specified, we won't be able to remove extrenous files.
     * @default - no state file
     */
    readonly stateFile?: string;
}
/**
 * Handles the synthesis of files.
 */
export declare class Files {
    /**
     * The path to a state file which will track all synthesized files.
     */
    readonly stateFile?: string;
    private readonly app;
    constructor(props: FilesProps);
    /**
     * Synthesize the app into the output directory. The artifact produced
     * depends on what synthesizer was used.
     *
     * @param outdir The output directory, if not specified, the app's outdir will be used.
     */
    synth(outdir?: string): void;
    /**
     * If a state file is defined, reads it and returns the list of files that
     * this app manages.
     */
    private readStateFile;
    /**
     * If a state file is defined, stores the list of files under management in that file.
     * @param files List of file paths (relative)
     */
    private saveStateFile;
}
