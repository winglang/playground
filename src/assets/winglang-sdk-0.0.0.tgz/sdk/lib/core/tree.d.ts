import { App } from "./app";
/**
 * A node in the construct tree.
 */
export interface ConstructTreeNode {
    /**
     * The ID of the node. Is part of the `path`.
     */
    readonly id: string;
    /**
     * The path of the node.
     */
    readonly path: string;
    /**
     * The child nodes.
     */
    readonly children?: {
        [key: string]: ConstructTreeNode;
    };
    /**
     * The node attributes.
     */
    readonly attributes?: {
        [key: string]: any;
    };
    /**
     * Information on the construct class that led to this node, if available.
     */
    readonly constructInfo?: ConstructInfo;
    /**
     * Information on how to display this node in the UI.
     */
    readonly display?: DisplayInfo;
}
/**
 * Information on how to display a construct in the UI.
 */
export interface DisplayInfo {
    /**
     * Title of the resource.
     * @default - The type and/or identifier of the resource
     */
    readonly title?: string;
    /**
     * Description of the resource.
     * @default - No description
     */
    readonly description?: string;
    /**
     * Whether the resource should be hidden from the UI.
     * @default false (visible)
     */
    readonly hidden?: boolean;
}
/**
 * The construct tree.
 */
export interface ConstructTree {
    /**
     * The construct tree version.
     */
    readonly version: string;
    /**
     * The root node.
     */
    readonly tree: ConstructTreeNode;
}
/**
 * Source information on a construct (class fqn and version).
 */
export interface ConstructInfo {
    /**
     * Fully qualified class name.
     */
    readonly fqn: string;
    /**
     * Version of the module.
     */
    readonly version: string;
}
export declare function synthesizeTree(app: App, outdir: string): void;
/**
 * Inspector that maintains an attribute bag
 */
export declare class TreeInspector {
    /**
     * Represents the bag of attributes as key-value pairs.
     */
    readonly attributes: {
        [key: string]: any;
    };
    /**
     * Adds attribute to bag.
     *
     * @param key - key for metadata
     * @param value - value of metadata.
     */
    addAttribute(key: string, value: any): void;
}
/**
 * Interface for examining a construct and exposing metadata.
 */
export interface IInspectable {
    /**
     * Examines construct
     *
     * @param inspector - tree inspector to collect and process attributes
     *
     * @internal
     */
    _inspect(inspector: TreeInspector): void;
}
