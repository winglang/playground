import { ISimulatorResourceInstance } from "./resource";
import { TopicSchema } from "./schema-resources";
import { ITopicClient } from "../cloud";
import { ISimulatorContext } from "../testing/simulator";
export declare class Topic implements ITopicClient, ISimulatorResourceInstance {
    private readonly subscribers;
    private readonly context;
    constructor(props: TopicSchema["props"], context: ISimulatorContext);
    private publishMessage;
    publish(message: string): Promise<void>;
    init(): Promise<void>;
    cleanup(): Promise<void>;
}
