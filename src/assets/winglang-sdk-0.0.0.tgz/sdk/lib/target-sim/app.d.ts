import { Construct } from "constructs";
import * as core from "../core";
/**
 * A construct that knows how to synthesize simulator resources into a
 * Wing simulator (.wsim) file.
 */
export declare class App extends core.App {
    /**
     * Directory where artifacts are synthesized to.
     */
    readonly outdir: string;
    private readonly files;
    private readonly name;
    private readonly simfile;
    private synthed;
    constructor(props: core.AppProps);
    protected tryNew(fqn: string, scope: Construct, id: string, ...args: any[]): any;
    /**
     * Synthesize the app. This creates a tree.json file and a .wsim file in the
     * app's outdir, and returns a path to the .wsim file.
     */
    synth(): string;
    private synthSimulatorFile;
}
