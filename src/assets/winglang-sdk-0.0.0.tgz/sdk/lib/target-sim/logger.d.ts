import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import { BaseResourceSchema } from "./schema";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * Simulator implementation of `cloud.Logger`.
 *
 * @inflight `@winglang/sdk.cloud.ILoggerClient`
 */
export declare class Logger extends cloud.Logger implements ISimulatorResource {
    constructor(scope: Construct, id: string);
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
