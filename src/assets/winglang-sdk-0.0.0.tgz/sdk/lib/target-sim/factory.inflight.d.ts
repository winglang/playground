import { ISimulatorResourceInstance } from "./resource";
import { ISimulatorFactory, ISimulatorContext } from "../testing/simulator";
export declare class DefaultSimulatorFactory implements ISimulatorFactory {
    /**
     * Creates a new simulator runtime resource
     * @param type type id
     * @param props resource properties
     * @param context simulator context
     * @returns a new instance
     */
    resolve(type: string, props: any, context: ISimulatorContext): ISimulatorResourceInstance;
}
