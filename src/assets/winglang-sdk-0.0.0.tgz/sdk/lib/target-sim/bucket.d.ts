import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import { BaseResourceSchema } from "./schema";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * Simulator implementation of `cloud.Bucket`.
 *
 * @inflight `@winglang/sdk.cloud.IBucketClient`
 */
export declare class Bucket extends cloud.Bucket implements ISimulatorResource {
    private readonly public;
    private readonly initialObjects;
    constructor(scope: Construct, id: string, props?: cloud.BucketProps);
    addObject(key: string, body: string): void;
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
