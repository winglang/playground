import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import { BaseResourceSchema } from "./schema";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * Simulator implementation of `cloud.Queue`.
 *
 * @inflight `@winglang/sdk.cloud.IQueueClient`
 */
export declare class Queue extends cloud.Queue implements ISimulatorResource {
    private readonly timeout;
    private readonly subscribers;
    private readonly initialMessages;
    constructor(scope: Construct, id: string, props?: cloud.QueueProps);
    onMessage(inflight: core.Inflight, // cloud.IQueueOnMessageHandler
    props?: cloud.QueueOnMessageProps): cloud.Function;
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
