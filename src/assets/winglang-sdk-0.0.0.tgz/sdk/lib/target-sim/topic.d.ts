import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import { BaseResourceSchema } from "./schema";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * Simulator implementation of `cloud.Topic`
 *
 * @inflight `@winglang/sdk.cloud.ITopicClient`
 */
export declare class Topic extends cloud.Topic implements ISimulatorResource {
    private readonly subscribers;
    constructor(scope: Construct, id: string, props?: cloud.TopicProps);
    onMessage(inflight: core.Inflight, // cloud.ITopicOnMessageHandler
    props?: cloud.TopicOnMessageProps): cloud.Function;
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
    toSimulator(): BaseResourceSchema;
}
