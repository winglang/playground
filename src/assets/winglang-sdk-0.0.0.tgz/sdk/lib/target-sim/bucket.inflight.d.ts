import { ISimulatorResourceInstance } from "./resource";
import { BucketSchema } from "./schema-resources";
import { BucketDeleteOptions, IBucketClient } from "../cloud";
import { Json } from "../std";
import { ISimulatorContext } from "../testing/simulator";
export declare class Bucket implements IBucketClient, ISimulatorResourceInstance {
    private readonly objectKeys;
    private readonly fileDir;
    private readonly context;
    private readonly initialObjects;
    constructor(props: BucketSchema["props"], context: ISimulatorContext);
    init(): Promise<void>;
    cleanup(): Promise<void>;
    put(key: string, value: string): Promise<void>;
    putJson(key: string, body: Json): Promise<void>;
    get(key: string): Promise<string>;
    getJson(key: string): Promise<Json>;
    list(prefix?: string): Promise<string[]>;
    delete(key: string, opts?: BucketDeleteOptions): Promise<void>;
    private addFile;
    private hashKey;
}
