import { ISimulatorResourceInstance } from "./resource";
import { QueueSchema } from "./schema-resources";
import { IQueueClient } from "../cloud";
import { ISimulatorContext } from "../testing/simulator";
export declare class Queue implements IQueueClient, ISimulatorResourceInstance {
    private readonly messages;
    private readonly subscribers;
    private readonly intervalId;
    private readonly context;
    constructor(props: QueueSchema["props"], context: ISimulatorContext);
    init(): Promise<void>;
    cleanup(): Promise<void>;
    push(message: string): Promise<void>;
    purge(): Promise<void>;
    approxSize(): Promise<number>;
    private processMessages;
}
