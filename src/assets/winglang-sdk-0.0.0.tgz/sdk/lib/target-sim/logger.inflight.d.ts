import { ISimulatorResourceInstance } from "./resource";
import { LoggerSchema } from "./schema-resources";
import { ILoggerClient } from "../cloud";
import { ISimulatorContext } from "../testing";
export declare class Logger implements ILoggerClient, ISimulatorResourceInstance {
    private readonly logsDir;
    private readonly context;
    constructor(_props: LoggerSchema["props"], context: ISimulatorContext);
    init(): Promise<void>;
    cleanup(): Promise<void>;
    print(message: string): Promise<void>;
}
