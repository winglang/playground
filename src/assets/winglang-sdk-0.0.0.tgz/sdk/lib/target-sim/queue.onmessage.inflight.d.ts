import type { IFunctionHandlerClient, IQueueOnMessageHandlerClient } from "../cloud";
export declare class QueueOnMessageHandlerClient implements IQueueOnMessageHandlerClient {
    private readonly handler;
    constructor({ handler }: {
        handler: IFunctionHandlerClient;
    });
    handle(event: string): Promise<void>;
}
