import { IInflightHost, NodeJsCode, Resource } from "../core";
/**
 * Check if a file exists for an specific path
 * @param filePath
 * @Returns Return `true` if the file exists, `false` otherwise.
 */
export declare function exists(filePath: string): Promise<boolean>;
export declare function bindSimulatorResource(type: string, resource: Resource, host: IInflightHost): void;
export declare function makeSimulatorJsClient(type: string, resource: Resource): NodeJsCode;
