import { Construct } from "constructs";
import { ISimulatorResource } from "./resource";
import { BaseResourceSchema } from "./schema";
import * as cloud from "../cloud";
import * as core from "../core";
/**
 * Simulator implementation of `cloud.Counter`.
 *
 * @inflight `@winglang/sdk.cloud.ICounterClient`
 */
export declare class Counter extends cloud.Counter implements ISimulatorResource {
    readonly initial: number;
    constructor(scope: Construct, id: string, props?: cloud.CounterProps);
    toSimulator(): BaseResourceSchema;
    /** @internal */
    _bind(host: core.IInflightHost, ops: string[]): void;
    /** @internal */
    _toInflight(): core.Code;
}
