{
  "author": {
    "name": "Amazon Web Services",
    "organization": true,
    "roles": [
      "author"
    ],
    "url": "https://aws.amazon.com"
  },
  "description": "A programming model for software-defined state",
  "docs": {
    "stability": "stable"
  },
  "homepage": "https://github.com/aws/constructs",
  "jsiiVersion": "5.0.6 (build 7f26494)",
  "keywords": [
    "aws",
    "cdk",
    "constructs",
    "jsii"
  ],
  "license": "Apache-2.0",
  "metadata": {
    "jsii": {
      "pacmak": {
        "hasDefaultInterfaces": true
      }
    },
    "tscRootDir": "src"
  },
  "name": "constructs",
  "readme": {
    "markdown": "# Constructs\n\n> Software-defined persistent state\n\n![Release](https://github.com/aws/constructs/workflows/Release/badge.svg)\n[![npm version](https://badge.fury.io/js/constructs.svg)](https://badge.fury.io/js/constructs)\n[![PyPI version](https://badge.fury.io/py/constructs.svg)](https://badge.fury.io/py/constructs)\n[![NuGet version](https://badge.fury.io/nu/Constructs.svg)](https://badge.fury.io/nu/Constructs)\n[![Maven Central](https://maven-badges.herokuapp.com/maven-central/software.constructs/constructs/badge.svg?style=plastic)](https://maven-badges.herokuapp.com/maven-central/software.constructs/constructs)\n\n## What are constructs?\n\nConstructs are classes which define a \"piece of system state\". Constructs can be composed together to form higher-level building blocks which represent more complex state.\n\nConstructs are often used to represent the _desired state_ of cloud applications. For example, in the AWS CDK, which is used to define the desired state for AWS infrastructure using CloudFormation, the lowest-level construct represents a _resource definition_ in a CloudFormation template. These resources are composed to represent higher-level logical units of a cloud application, etc.\n\n## Contributing\n\nThis project has adopted the [Amazon Open Source Code of\nConduct](https://aws.github.io/code-of-conduct).\n\nWe welcome community contributions and pull requests. See our [contribution\nguide](./CONTRIBUTING.md) for more information on how to report issues, set up a\ndevelopment environment and submit code.\n\n## License\n\nThis project is distributed under the [Apache License, Version 2.0](./LICENSE).\n"
  },
  "repository": {
    "type": "git",
    "url": "https://github.com/aws/constructs.git"
  },
  "schema": "jsii/0.10.0",
  "targets": {
    "dotnet": {
      "namespace": "Constructs",
      "packageId": "Constructs"
    },
    "go": {
      "moduleName": "github.com/aws/constructs-go"
    },
    "java": {
      "maven": {
        "artifactId": "constructs",
        "groupId": "software.constructs"
      },
      "package": "software.constructs"
    },
    "js": {
      "npm": "constructs"
    },
    "python": {
      "distName": "constructs",
      "module": "constructs"
    }
  },
  "types": {
    "constructs.Construct": {
      "assembly": "constructs",
      "docs": {
        "remarks": "All constructs besides the root construct must be created within the scope of\nanother construct.",
        "stability": "stable",
        "summary": "Represents the building block of the construct graph."
      },
      "fqn": "constructs.Construct",
      "initializer": {
        "docs": {
          "stability": "stable",
          "summary": "Creates a new construct node."
        },
        "locationInModule": {
          "filename": "src/construct.ts",
          "line": 462
        },
        "parameters": [
          {
            "docs": {
              "summary": "The scope in which to define this construct."
            },
            "name": "scope",
            "type": {
              "fqn": "constructs.Construct"
            }
          },
          {
            "docs": {
              "remarks": "Must be unique amongst siblings. If\nthe ID includes a path separator (`/`), then it will be replaced by double\ndash `--`.",
              "summary": "The scoped construct ID."
            },
            "name": "id",
            "type": {
              "primitive": "string"
            }
          }
        ]
      },
      "interfaces": [
        "constructs.IConstruct"
      ],
      "kind": "class",
      "locationInModule": {
        "filename": "src/construct.ts",
        "line": 424
      },
      "methods": [
        {
          "docs": {
            "remarks": "Use this method instead of `instanceof` to properly detect `Construct`\ninstances, even when the construct library is symlinked.\n\nExplanation: in JavaScript, multiple copies of the `constructs` library on\ndisk are seen as independent, completely different libraries. As a\nconsequence, the class `Construct` in each copy of the `constructs` library\nis seen as a different class, and an instance of one class will not test as\n`instanceof` the other class. `npm install` will not create installations\nlike this, but users may manually symlink construct libraries together or\nuse a monorepo tool: in those cases, multiple copies of the `constructs`\nlibrary can be accidentally installed, and `instanceof` will behave\nunpredictably. It is safest to avoid using `instanceof`, and using\nthis type-testing method instead.",
            "returns": "true if `x` is an object created from a class which extends `Construct`.",
            "stability": "stable",
            "summary": "Checks if `x` is a construct."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 445
          },
          "name": "isConstruct",
          "parameters": [
            {
              "docs": {
                "summary": "Any object."
              },
              "name": "x",
              "type": {
                "primitive": "any"
              }
            }
          ],
          "returns": {
            "type": {
              "primitive": "boolean"
            }
          },
          "static": true
        },
        {
          "docs": {
            "stability": "stable",
            "summary": "Returns a string representation of this construct."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 474
          },
          "name": "toString",
          "returns": {
            "type": {
              "primitive": "string"
            }
          }
        }
      ],
      "name": "Construct",
      "properties": [
        {
          "docs": {
            "stability": "stable",
            "summary": "The tree node."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 452
          },
          "name": "node",
          "overrides": "constructs.IConstruct",
          "type": {
            "fqn": "constructs.Node"
          }
        }
      ],
      "symbolId": "src/construct:Construct"
    },
    "constructs.ConstructOrder": {
      "assembly": "constructs",
      "docs": {
        "stability": "stable",
        "summary": "In what order to return constructs."
      },
      "fqn": "constructs.ConstructOrder",
      "kind": "enum",
      "locationInModule": {
        "filename": "src/construct.ts",
        "line": 497
      },
      "members": [
        {
          "docs": {
            "stability": "stable",
            "summary": "Depth-first, pre-order."
          },
          "name": "PREORDER"
        },
        {
          "docs": {
            "stability": "stable",
            "summary": "Depth-first, post-order (leaf nodes first)."
          },
          "name": "POSTORDER"
        }
      ],
      "name": "ConstructOrder",
      "symbolId": "src/construct:ConstructOrder"
    },
    "constructs.Dependable": {
      "abstract": true,
      "assembly": "constructs",
      "docs": {
        "example": "// Usage\nconst roots = Dependable.of(construct).dependencyRoots;\n\n// Definition\nDependable.implement(construct, {\n      dependencyRoots: [construct],\n});",
        "remarks": "Traits are interfaces that are privately implemented by objects. Instead of\nshowing up in the public interface of a class, they need to be queried\nexplicitly. This is used to implement certain framework features that are\nnot intended to be used by Construct consumers, and so should be hidden\nfrom accidental use.",
        "stability": "experimental",
        "summary": "Trait for IDependable."
      },
      "fqn": "constructs.Dependable",
      "initializer": {
        "docs": {
          "stability": "stable"
        }
      },
      "kind": "class",
      "locationInModule": {
        "filename": "src/dependency.ts",
        "line": 76
      },
      "methods": [
        {
          "docs": {
            "deprecated": "use `of`",
            "stability": "deprecated",
            "summary": "Return the matching Dependable for the given class instance."
          },
          "locationInModule": {
            "filename": "src/dependency.ts",
            "line": 102
          },
          "name": "get",
          "parameters": [
            {
              "name": "instance",
              "type": {
                "fqn": "constructs.IDependable"
              }
            }
          ],
          "returns": {
            "type": {
              "fqn": "constructs.Dependable"
            }
          },
          "static": true
        },
        {
          "docs": {
            "stability": "experimental",
            "summary": "Turn any object into an IDependable."
          },
          "locationInModule": {
            "filename": "src/dependency.ts",
            "line": 80
          },
          "name": "implement",
          "parameters": [
            {
              "name": "instance",
              "type": {
                "fqn": "constructs.IDependable"
              }
            },
            {
              "name": "trait",
              "type": {
                "fqn": "constructs.Dependable"
              }
            }
          ],
          "static": true
        },
        {
          "docs": {
            "stability": "experimental",
            "summary": "Return the matching Dependable for the given class instance."
          },
          "locationInModule": {
            "filename": "src/dependency.ts",
            "line": 90
          },
          "name": "of",
          "parameters": [
            {
              "name": "instance",
              "type": {
                "fqn": "constructs.IDependable"
              }
            }
          ],
          "returns": {
            "type": {
              "fqn": "constructs.Dependable"
            }
          },
          "static": true
        }
      ],
      "name": "Dependable",
      "properties": [
        {
          "abstract": true,
          "docs": {
            "remarks": "All resources under all returned constructs are included in the ordering\ndependency.",
            "stability": "experimental",
            "summary": "The set of constructs that form the root of this dependable."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/dependency.ts",
            "line": 112
          },
          "name": "dependencyRoots",
          "type": {
            "collection": {
              "elementtype": {
                "fqn": "constructs.IConstruct"
              },
              "kind": "array"
            }
          }
        }
      ],
      "symbolId": "src/dependency:Dependable"
    },
    "constructs.DependencyGroup": {
      "assembly": "constructs",
      "docs": {
        "remarks": "This class can be used when a set of constructs which are disjoint in the\nconstruct tree needs to be combined to be used as a single dependable.",
        "stability": "experimental",
        "summary": "A set of constructs to be used as a dependable."
      },
      "fqn": "constructs.DependencyGroup",
      "initializer": {
        "docs": {
          "stability": "experimental"
        },
        "locationInModule": {
          "filename": "src/dependency.ts",
          "line": 29
        },
        "parameters": [
          {
            "name": "deps",
            "type": {
              "fqn": "constructs.IDependable"
            },
            "variadic": true
          }
        ],
        "variadic": true
      },
      "interfaces": [
        "constructs.IDependable"
      ],
      "kind": "class",
      "locationInModule": {
        "filename": "src/dependency.ts",
        "line": 26
      },
      "methods": [
        {
          "docs": {
            "stability": "experimental",
            "summary": "Add a construct to the dependency roots."
          },
          "locationInModule": {
            "filename": "src/dependency.ts",
            "line": 48
          },
          "name": "add",
          "parameters": [
            {
              "name": "scopes",
              "type": {
                "fqn": "constructs.IDependable"
              },
              "variadic": true
            }
          ],
          "variadic": true
        }
      ],
      "name": "DependencyGroup",
      "symbolId": "src/dependency:DependencyGroup"
    },
    "constructs.IConstruct": {
      "assembly": "constructs",
      "docs": {
        "stability": "stable",
        "summary": "Represents a construct."
      },
      "fqn": "constructs.IConstruct",
      "interfaces": [
        "constructs.IDependable"
      ],
      "kind": "interface",
      "locationInModule": {
        "filename": "src/construct.ts",
        "line": 11
      },
      "name": "IConstruct",
      "properties": [
        {
          "abstract": true,
          "docs": {
            "stability": "stable",
            "summary": "The tree node."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 15
          },
          "name": "node",
          "type": {
            "fqn": "constructs.Node"
          }
        }
      ],
      "symbolId": "src/construct:IConstruct"
    },
    "constructs.IDependable": {
      "assembly": "constructs",
      "docs": {
        "remarks": "The presence of this interface indicates that an object has\nan `IDependable` implementation.\n\nThis interface can be used to take an (ordering) dependency on a set of\nconstructs. An ordering dependency implies that the resources represented by\nthose constructs are deployed before the resources depending ON them are\ndeployed.",
        "stability": "stable",
        "summary": "Trait marker for classes that can be depended upon."
      },
      "fqn": "constructs.IDependable",
      "kind": "interface",
      "locationInModule": {
        "filename": "src/dependency.ts",
        "line": 14
      },
      "name": "IDependable",
      "symbolId": "src/dependency:IDependable"
    },
    "constructs.IValidation": {
      "assembly": "constructs",
      "docs": {
        "stability": "stable",
        "summary": "Implement this interface in order for the construct to be able to validate itself."
      },
      "fqn": "constructs.IValidation",
      "kind": "interface",
      "locationInModule": {
        "filename": "src/construct.ts",
        "line": 482
      },
      "methods": [
        {
          "abstract": true,
          "docs": {
            "remarks": "This method can be implemented by derived constructs in order to perform\nvalidation logic. It is called on all constructs before synthesis.",
            "returns": "An array of validation error messages, or an empty array if there the construct is valid.",
            "stability": "stable",
            "summary": "Validate the current construct."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 491
          },
          "name": "validate",
          "returns": {
            "type": {
              "collection": {
                "elementtype": {
                  "primitive": "string"
                },
                "kind": "array"
              }
            }
          }
        }
      ],
      "name": "IValidation",
      "symbolId": "src/construct:IValidation"
    },
    "constructs.MetadataEntry": {
      "assembly": "constructs",
      "datatype": true,
      "docs": {
        "stability": "stable",
        "summary": "An entry in the construct metadata table."
      },
      "fqn": "constructs.MetadataEntry",
      "kind": "interface",
      "locationInModule": {
        "filename": "src/metadata.ts",
        "line": 4
      },
      "name": "MetadataEntry",
      "properties": [
        {
          "abstract": true,
          "docs": {
            "stability": "stable",
            "summary": "The data."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/metadata.ts",
            "line": 13
          },
          "name": "data",
          "type": {
            "primitive": "any"
          }
        },
        {
          "abstract": true,
          "docs": {
            "stability": "stable",
            "summary": "The metadata entry type."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/metadata.ts",
            "line": 8
          },
          "name": "type",
          "type": {
            "primitive": "string"
          }
        },
        {
          "abstract": true,
          "docs": {
            "default": "- no trace information",
            "remarks": "Only available if `addMetadata()` is called with `stackTrace: true`.",
            "stability": "stable",
            "summary": "Stack trace at the point of adding the metadata."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/metadata.ts",
            "line": 22
          },
          "name": "trace",
          "optional": true,
          "type": {
            "collection": {
              "elementtype": {
                "primitive": "string"
              },
              "kind": "array"
            }
          }
        }
      ],
      "symbolId": "src/metadata:MetadataEntry"
    },
    "constructs.MetadataOptions": {
      "assembly": "constructs",
      "datatype": true,
      "docs": {
        "stability": "stable",
        "summary": "Options for `construct.addMetadata()`."
      },
      "fqn": "constructs.MetadataOptions",
      "kind": "interface",
      "locationInModule": {
        "filename": "src/construct.ts",
        "line": 522
      },
      "name": "MetadataOptions",
      "properties": [
        {
          "abstract": true,
          "docs": {
            "default": "false",
            "stability": "stable",
            "summary": "Include stack trace with metadata entry."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 527
          },
          "name": "stackTrace",
          "optional": true,
          "type": {
            "primitive": "boolean"
          }
        },
        {
          "abstract": true,
          "docs": {
            "default": "addMetadata()",
            "remarks": "This option is ignored unless `stackTrace` is `true`.",
            "stability": "stable",
            "summary": "A JavaScript function to begin tracing from."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 536
          },
          "name": "traceFromFunction",
          "optional": true,
          "type": {
            "primitive": "any"
          }
        }
      ],
      "symbolId": "src/construct:MetadataOptions"
    },
    "constructs.Node": {
      "assembly": "constructs",
      "docs": {
        "stability": "stable",
        "summary": "Represents the construct node in the scope tree."
      },
      "fqn": "constructs.Node",
      "initializer": {
        "docs": {
          "stability": "stable"
        },
        "locationInModule": {
          "filename": "src/construct.ts",
          "line": 60
        },
        "parameters": [
          {
            "name": "host",
            "type": {
              "fqn": "constructs.Construct"
            }
          },
          {
            "name": "scope",
            "type": {
              "fqn": "constructs.IConstruct"
            }
          },
          {
            "name": "id",
            "type": {
              "primitive": "string"
            }
          }
        ]
      },
      "kind": "class",
      "locationInModule": {
        "filename": "src/construct.ts",
        "line": 21
      },
      "methods": [
        {
          "docs": {
            "deprecated": "use `construct.node` instead",
            "stability": "deprecated",
            "summary": "Returns the node associated with a construct."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 33
          },
          "name": "of",
          "parameters": [
            {
              "docs": {
                "summary": "the construct."
              },
              "name": "construct",
              "type": {
                "fqn": "constructs.IConstruct"
              }
            }
          ],
          "returns": {
            "type": {
              "fqn": "constructs.Node"
            }
          },
          "static": true
        },
        {
          "docs": {
            "remarks": "An `IDependable`",
            "stability": "stable",
            "summary": "Add an ordering dependency on another construct."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 305
          },
          "name": "addDependency",
          "parameters": [
            {
              "name": "deps",
              "type": {
                "fqn": "constructs.IDependable"
              },
              "variadic": true
            }
          ],
          "variadic": true
        },
        {
          "docs": {
            "remarks": "Entries are arbitrary values and will also include a stack trace to allow tracing back to\nthe code location for when the entry was added. It can be used, for example, to include source\nmapping in CloudFormation templates to improve diagnostics.",
            "stability": "stable",
            "summary": "Adds a metadata entry to this construct."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 247
          },
          "name": "addMetadata",
          "parameters": [
            {
              "docs": {
                "summary": "a string denoting the type of metadata."
              },
              "name": "type",
              "type": {
                "primitive": "string"
              }
            },
            {
              "docs": {
                "remarks": "If null/undefined, metadata will not be added.",
                "summary": "the value of the metadata (can be a Token)."
              },
              "name": "data",
              "type": {
                "primitive": "any"
              }
            },
            {
              "docs": {
                "summary": "options."
              },
              "name": "options",
              "optional": true,
              "type": {
                "fqn": "constructs.MetadataOptions"
              }
            }
          ]
        },
        {
          "docs": {
            "remarks": "When `node.validate()` is called, the `validate()` method will be called on\nall validations and all errors will be returned.",
            "stability": "stable",
            "summary": "Adds a validation to this construct."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 345
          },
          "name": "addValidation",
          "parameters": [
            {
              "docs": {
                "summary": "The validation object."
              },
              "name": "validation",
              "type": {
                "fqn": "constructs.IValidation"
              }
            }
          ]
        },
        {
          "docs": {
            "stability": "stable",
            "summary": "Return this construct and all of its children in the given order."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 179
          },
          "name": "findAll",
          "parameters": [
            {
              "name": "order",
              "optional": true,
              "type": {
                "fqn": "constructs.ConstructOrder"
              }
            }
          ],
          "returns": {
            "type": {
              "collection": {
                "elementtype": {
                  "fqn": "constructs.IConstruct"
                },
                "kind": "array"
              }
            }
          }
        },
        {
          "docs": {
            "remarks": "Throws an error if the child is not found.",
            "returns": "Child with the given id.",
            "stability": "stable",
            "summary": "Return a direct child by id."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 125
          },
          "name": "findChild",
          "parameters": [
            {
              "docs": {
                "summary": "Identifier of direct child."
              },
              "name": "id",
              "type": {
                "primitive": "string"
              }
            }
          ],
          "returns": {
            "type": {
              "fqn": "constructs.IConstruct"
            }
          }
        },
        {
          "docs": {
            "remarks": "After this\ncall, no more children can be added to this construct or to any children.",
            "stability": "stable",
            "summary": "Locks this construct from allowing more children to be added."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 378
          },
          "name": "lock"
        },
        {
          "docs": {
            "remarks": "Context must be set before any children are added, since children may consult context info during construction.\nIf the key already exists, it will be overridden.",
            "stability": "stable",
            "summary": "This can be used to set contextual values."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 206
          },
          "name": "setContext",
          "parameters": [
            {
              "docs": {
                "summary": "The context key."
              },
              "name": "key",
              "type": {
                "primitive": "string"
              }
            },
            {
              "docs": {
                "summary": "The context value."
              },
              "name": "value",
              "type": {
                "primitive": "any"
              }
            }
          ]
        },
        {
          "docs": {
            "returns": "the child if found, or undefined",
            "stability": "stable",
            "summary": "Return a direct child by id, or undefined."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 113
          },
          "name": "tryFindChild",
          "parameters": [
            {
              "docs": {
                "summary": "Identifier of direct child."
              },
              "name": "id",
              "type": {
                "primitive": "string"
              }
            }
          ],
          "returns": {
            "optional": true,
            "type": {
              "fqn": "constructs.IConstruct"
            }
          }
        },
        {
          "docs": {
            "remarks": "Context is usually initialized at the root, but can be overridden at any point in the tree.",
            "returns": "The context value or `undefined` if there is no context value for thie key.",
            "stability": "stable",
            "summary": "Retrieves a value from tree context."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 222
          },
          "name": "tryGetContext",
          "parameters": [
            {
              "docs": {
                "summary": "The context key."
              },
              "name": "key",
              "type": {
                "primitive": "string"
              }
            }
          ],
          "returns": {
            "type": {
              "primitive": "any"
            }
          }
        },
        {
          "docs": {
            "returns": "Whether a child with the given name was deleted.",
            "stability": "experimental",
            "summary": "Remove the child with the given name, if present."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 331
          },
          "name": "tryRemoveChild",
          "parameters": [
            {
              "name": "childName",
              "type": {
                "primitive": "string"
              }
            }
          ],
          "returns": {
            "type": {
              "primitive": "boolean"
            }
          }
        },
        {
          "docs": {
            "remarks": "Invokes the `validate()` method on all validations added through\n`addValidation()`.",
            "returns": "an array of validation error messages associated with this\nconstruct.",
            "stability": "stable",
            "summary": "Validates this construct."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 358
          },
          "name": "validate",
          "returns": {
            "type": {
              "collection": {
                "elementtype": {
                  "primitive": "string"
                },
                "kind": "array"
              }
            }
          }
        }
      ],
      "name": "Node",
      "properties": [
        {
          "const": true,
          "docs": {
            "stability": "stable",
            "summary": "Separator used to delimit construct path components."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 25
          },
          "name": "PATH_SEP",
          "static": true,
          "type": {
            "primitive": "string"
          }
        },
        {
          "docs": {
            "example": "c83a2846e506bcc5f10682b564084bca2d275709ee",
            "remarks": "Addresses are 42 characters hexadecimal strings. They begin with \"c8\"\nfollowed by 40 lowercase hexadecimal characters (0-9a-f).\n\nAddresses are calculated using a SHA-1 of the components of the construct\npath.\n\nTo enable refactorings of construct trees, constructs with the ID `Default`\nwill be excluded from the calculation. In those cases constructs in the\nsame tree may have the same addreess.",
            "stability": "stable",
            "summary": "Returns an opaque tree-unique address for this construct."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 99
          },
          "name": "addr",
          "type": {
            "primitive": "string"
          }
        },
        {
          "docs": {
            "stability": "stable",
            "summary": "All direct children of this construct."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 172
          },
          "name": "children",
          "type": {
            "collection": {
              "elementtype": {
                "fqn": "constructs.IConstruct"
              },
              "kind": "array"
            }
          }
        },
        {
          "docs": {
            "stability": "stable",
            "summary": "Return all dependencies registered on this node (non-recursive)."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 314
          },
          "name": "dependencies",
          "type": {
            "collection": {
              "elementtype": {
                "fqn": "constructs.IConstruct"
              },
              "kind": "array"
            }
          }
        },
        {
          "docs": {
            "remarks": "This is a a scope-unique id. To obtain an app-unique id for this construct, use `addr`.",
            "stability": "stable",
            "summary": "The id of this construct within the current scope."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 49
          },
          "name": "id",
          "type": {
            "primitive": "string"
          }
        },
        {
          "docs": {
            "stability": "stable",
            "summary": "Returns true if this construct or the scopes in which it is defined are locked."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 288
          },
          "name": "locked",
          "type": {
            "primitive": "boolean"
          }
        },
        {
          "docs": {
            "remarks": "This can be used, for example, to implement support for deprecation notices, source mapping, etc.",
            "stability": "stable",
            "summary": "An immutable array of metadata objects associated with this construct."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 233
          },
          "name": "metadata",
          "type": {
            "collection": {
              "elementtype": {
                "fqn": "constructs.MetadataEntry"
              },
              "kind": "array"
            }
          }
        },
        {
          "docs": {
            "remarks": "Components are separated by '/'.",
            "stability": "stable",
            "summary": "The full, absolute path of this construct in the tree."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 79
          },
          "name": "path",
          "type": {
            "primitive": "string"
          }
        },
        {
          "docs": {
            "returns": "The root of the construct tree.",
            "stability": "stable",
            "summary": "Returns the root of the construct tree."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 280
          },
          "name": "root",
          "type": {
            "fqn": "constructs.IConstruct"
          }
        },
        {
          "docs": {
            "returns": "a list of parent scopes. The last element in the list will always\nbe the current construct and the first element will be the root of the\ntree.",
            "stability": "stable",
            "summary": "All parent scopes of this construct."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 264
          },
          "name": "scopes",
          "type": {
            "collection": {
              "elementtype": {
                "fqn": "constructs.IConstruct"
              },
              "kind": "array"
            }
          }
        },
        {
          "docs": {
            "remarks": "The value is `undefined` at the root of the construct scope tree.",
            "stability": "stable",
            "summary": "Returns the scope in which this construct is defined."
          },
          "immutable": true,
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 42
          },
          "name": "scope",
          "optional": true,
          "type": {
            "fqn": "constructs.IConstruct"
          }
        },
        {
          "docs": {
            "custom": {
              "throws": "if there is more than one child"
            },
            "remarks": "This is usually the construct that provides the bulk of the underlying functionality.\nUseful for modifications of the underlying construct that are not available at the higher levels.\nOverride the defaultChild property.\n\nThis should only be used in the cases where the correct\ndefault child is not named 'Resource' or 'Default' as it\nshould be.\n\nIf you set this to undefined, the default behavior of finding\nthe child named 'Resource' or 'Default' will be used.",
            "returns": "a construct or undefined if there is no default child",
            "stability": "stable",
            "summary": "Returns the child construct that has the id `Default` or `Resource\"`."
          },
          "locationInModule": {
            "filename": "src/construct.ts",
            "line": 141
          },
          "name": "defaultChild",
          "optional": true,
          "type": {
            "fqn": "constructs.IConstruct"
          }
        }
      ],
      "symbolId": "src/construct:Node"
    }
  },
  "version": "10.1.314",
  "fingerprint": "dhu3SWGxHiUi7vY+py3GKQ2B++E3Bb0E0KzRDT6PrsA="
}